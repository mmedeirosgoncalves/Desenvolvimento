---
id: roadmap
version: 0.8.3
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: true
depends_on: []
used_by: []
supersedes: null
---

# Roadmap

## Completed

- v0.8.1 — Devin AI Discovery Adapter
- v0.8.2 — Devin CLI Provider Integration
- v0.8.3 — Adaptive Multi-Agent Pipeline

## Next

### v0.8.4 — Provider Registry Activation

Wire adaptive routing decisions into ProviderRegistry and execute consensus only with preflight-passing providers.

### v0.8.5 — Codegen Worktree Execution

Run codegen in isolated worktrees and merge only after gates pass.
