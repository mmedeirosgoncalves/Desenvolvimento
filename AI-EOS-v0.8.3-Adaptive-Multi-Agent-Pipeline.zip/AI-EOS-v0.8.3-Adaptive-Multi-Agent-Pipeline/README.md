---
id: readme
version: 0.8.3
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: true
depends_on: [adr-0037]
used_by: []
supersedes: null
---

# AI-EOS v0.8.3 — Adaptive Multi-Agent Pipeline

This release absorbs useful MONSTRO-style multi-agent patterns into AI-EOS without importing MONSTRO as a dependency.

## Added

- Adaptive routing.
- Role-based agent profiles.
- Task profiles with difficulty and risk.
- Isolated workspaces per agent.
- Advisory learning registry.
- MONSTRO audit.
- ADR-0037.
- QG-019, QG-020 and QG-021.

## Pipeline

```text
TaskProfile
  -> AdaptiveRouting
  -> ProviderRegistry
  -> isolated workspaces
  -> ConsensusEngine
  -> HumanReviewGate
  -> Codegen
  -> QualityGates
  -> LearningRegistry
```

## Boundary

MONSTRO contributes patterns. AI-EOS keeps contracts, gates, validation and audit trail.
