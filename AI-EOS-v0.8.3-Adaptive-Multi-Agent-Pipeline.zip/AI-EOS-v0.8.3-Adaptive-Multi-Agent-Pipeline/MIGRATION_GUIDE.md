---
id: migration-guide
version: 0.8.3
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: true
depends_on: [adr-0037]
used_by: []
supersedes: null
---

# Migration Guide — v0.8.2 to v0.8.3

Existing ProviderContract integrations continue to work. v0.8.3 adds adaptive routing and isolation primitives. ProviderRegistry activation is v0.8.4.
