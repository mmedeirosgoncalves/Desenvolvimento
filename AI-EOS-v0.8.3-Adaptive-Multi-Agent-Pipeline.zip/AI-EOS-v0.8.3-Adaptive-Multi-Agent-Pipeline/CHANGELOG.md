---
id: changelog
version: 0.8.3
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: true
depends_on: []
used_by: []
supersedes: null
---

# Changelog

## v0.8.3 — Adaptive Multi-Agent Pipeline

- Added MONSTRO audit.
- Added adaptive routing.
- Added workspace isolation.
- Added learning registry.
- Added ADR-0037.
- Added QG-019/QG-020/QG-021.
- Added adaptive roster example and runtime tests.
