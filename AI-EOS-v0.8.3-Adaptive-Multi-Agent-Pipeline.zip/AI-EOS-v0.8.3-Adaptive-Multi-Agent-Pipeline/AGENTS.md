---
id: agents
version: 0.8.3
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: true
depends_on: []
used_by: []
supersedes: null
---

# AGENTS

## Release

AI-EOS v0.8.3 — Adaptive Multi-Agent Pipeline.

## Required Validation Flow

```bash
python runtime/validation/reference/python/tests/runtime_integration/test_adaptive_routing.py
python runtime/validation/reference/python/tests/runtime_integration/test_workspace_isolation.py
python runtime/validation/reference/python/tests/runtime_integration/test_learning_registry.py
```

## Agent Rule

Do not import MONSTRO as a dependency. Absorb only audited patterns into AI-EOS modules.
