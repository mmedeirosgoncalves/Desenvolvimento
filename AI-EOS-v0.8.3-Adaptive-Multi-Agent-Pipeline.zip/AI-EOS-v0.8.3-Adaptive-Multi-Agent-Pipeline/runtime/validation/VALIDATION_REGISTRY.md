---
id: validator-registry
version: 0.7.3
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-07
review_date: 2026-10-06
depends_on: [validator-model, validation-automation-levels]
used_by: []
supersedes: null
---

# Validation Registry

## Purpose

Map Validators to Quality Gates and automation levels.

## Registry

| Validator | Level | Quality Gates | Purpose |
|---|---|---|---|
| frontmatter-validator | L2 | QG-009, QG-004 | Validate ids, required metadata and dependency references |
| dependency-graph-validator | L2 | QG-009 | Validate `depends_on` and `supersedes` |
| bootstrap-validator | L2 | QG-009 | Validate files referenced by `AGENTS.md` |
| manifest-validator | L2 | QG-009 | Validate package manifest counts and structure |
| markdown-render-validator | L1 | QG-004 | Detect render issues such as literal escaped newlines |
| content-duplication-validator | L1 | QG-004 | Detect duplicated or near-duplicated documentation |
| canon-structure-validator | L1 | QG-004, QG-001 | Validate Canon structure and SSOT rules |
| version-consistency-validator | L1 | QG-004 | Detect stale version metadata |
| consensus-execution-entrypoint-validator | L2 | QG-015 | Verify the consensus CLI and benchmark entrypoints exist |
| strict-json-validator | L2 | QG-015, QG-006 | Verify generated reports use strict JSON |
| cli-input-validator | L2 | QG-015 | Verify malformed payloads fail with structured errors |
| test-runner-validator | L2 | QG-015, QG-003 | Verify runtime tests are part of the release gate |

## Extension Rule

New validators must be registered here before they are used by release validation.

## v0.5.1 Hardening

Additional validator coverage:

- near-duplicate content detection;
- line-level literal newline detection;
- manifest top-level area validation;
- metadata status/version/date validation;
- negative fixture checks.

## v0.5.2 Cross-Platform Validation

Validators must use the path normalization utilities before matching, hashing or reporting path-sensitive evidence.

## v0.6 Knowledge Validators

- package-metadata-validator
- capability-integrity-validator
- knowledge-dependency-graph-validator
- lifecycle-consistency-validator
- registry-consistency-validator

Initial automation level: L1.

| multi-ai-runtime-validator | L2 | QG-016 | Verify multi-ai runtime artifacts and entrypoint exist |
| multi-ai-smoke-test-validator | L2 | QG-016 | Verify mock multi-ai execution produces an audit trail |

| devin-discovery-validator | L2 | QG-017 | Verify Devin discovery artifacts and report generation |
| devin-access-policy-validator | L2 | QG-017 | Verify UI-only Devin models are not executable providers |

| devin-cli-provider-validator | L2 | QG-018 | Verify Devin CLI provider artifacts and command contract |
| devin-cli-fail-closed-validator | L2 | QG-018 | Verify Devin CLI provider fails closed without programmatic access |

| adaptive-routing-validator | L2 | QG-019 | Verify adaptive role/risk routing behavior |
| workspace-isolation-validator | L2 | QG-020 | Verify unique isolated workspaces for agents |
| learning-registry-validator | L2 | QG-021 | Verify strict JSONL provider outcome registry |