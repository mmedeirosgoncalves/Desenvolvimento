---
id: agents-entry-point
version: 0.8.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: true
depends_on: []
used_by: []
supersedes: null
---

# AGENTS

## Release

AI-EOS v0.8.0 — Multi-AI Runtime Foundation.

## Required Validation Flow

```bash
python runtime/validation/reference/python/run_tests.py
python runtime/validation/reference/python/ai_eos_validate.py . --output validation-report.json
python -m runtime.consensus consensus --input examples/consensus/sample_execution.json --output reports/sample-consensus-report.json
python -m runtime.consensus benchmark --suite experiments/benchmark_suite/mvp_cases.json --output-dir reports/benchmark
python -m runtime.multi_ai --input examples/multi_ai/sample_multi_ai_execution.json --output reports/multi-ai/sample-multi-ai-run.json
```

## Agent Rule

When multiple AI outputs diverge materially, the system must route the result through the Human Review Gate instead of silently accepting a majority.
