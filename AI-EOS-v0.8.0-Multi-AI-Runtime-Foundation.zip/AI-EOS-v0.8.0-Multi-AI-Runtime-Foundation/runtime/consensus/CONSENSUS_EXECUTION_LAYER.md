---
id: consensus-execution-layer
version: 0.8.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: true
depends_on: [adr-0032]
used_by: []
supersedes: null
---

# Consensus Execution Layer

The execution layer exposes the v0.7.1 Consensus Engine as an operational capability.

## Commands

```bash
python -m runtime.consensus consensus --input examples/consensus/sample_execution.json --output reports/sample-consensus-report.json
python -m runtime.consensus benchmark --suite experiments/benchmark_suite/mvp_cases.json --output-dir reports/benchmark
```

## Contract

The input artifact must include `task_id` and either `responses` or `mock_providers`. The output is a deterministic JSON report containing individual responses, consensus result, metrics and warnings.

## Scope

This layer does not call external model APIs. It consumes model artifacts or deterministic mock providers.

