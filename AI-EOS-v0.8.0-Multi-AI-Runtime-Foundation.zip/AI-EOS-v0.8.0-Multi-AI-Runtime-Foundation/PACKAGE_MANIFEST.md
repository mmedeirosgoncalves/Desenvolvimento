---
id: package-manifest
version: 0.8.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: true
depends_on: []
used_by: []
supersedes: null
---

# Package Manifest

## Release

AI-EOS v0.8.0 Multi-AI Runtime Foundation

## Baseline

AI-EOS v0.7.3 Execution Layer Hardening.

## Entry Point

`AGENTS.md`

## Version Source

`VERSION`

## Markdown Files

311

## YAML Files

5

## Python Files

38

## JSON Files

11

## Top-Level Areas

- adapters/
- agents/
- architecture/
- canon/
- constitution/
- decision-trees/
- docs/
- evaluation/
- examples/
- experiments/
- governance/
- harness/
- heuristics/
- knowledge/
- labs/
- multi-agent/
- playbooks/
- reports/
- runtime/
- skills/
- templates/
- vision/

## v0.8.0 Added/Changed Focus

- Multi-AI provider contract.
- Provider registry.
- Deterministic mock adapters.
- MultiAIOrchestrator.
- Consensus round integration.
- Human review gate.
- Audit trail.
- QG-016.

## File Inventory

- AGENTS.md
- CHANGELOG.md
- GOVERNANCE.md
- MIGRATION_GUIDE.md
- PACKAGE_MANIFEST.md
- README.md
- RELEASE_VALIDATION.md
- ROADMAP.md
- VERSION
- adapters/devin/DEVIN_BOOTSTRAP_PROMPT.md
- adapters/devin/DEVIN_USAGE.md
- agents/AGENT_CONTRACT_MODEL.md
- architecture/ARCHITECTURE_MODEL_RECONCILIATION.md
- architecture/DEPENDENCY_GRAPH.md
- architecture/DEPENDENCY_RULES.md
- architecture/LAYER_RESPONSIBILITIES.md
- architecture/MODULE_MAP.md
- architecture/MODULE_MODEL.md
- architecture/SYSTEM_ARCHITECTURE.md
- architecture/TARGET_ARCHITECTURE.md
- architecture/adr/ADR-0001-vendor-agnostic-adapter-based.md
- architecture/adr/ADR-0002-runtime-transition.md
- architecture/adr/ADR-0003-knowledge-execution-separation.md
- architecture/adr/ADR-0004-restore-process-assets.md
- architecture/adr/ADR-0005-layered-product-architecture.md
- architecture/adr/ADR-0006-introduce-engineering-canon.md
- architecture/adr/ADR-0007-release-review-mandatory-gate.md
- architecture/adr/ADR-0008-incremental-evolution-policy.md
- architecture/adr/ADR-0009-baseline-release-policy.md
- architecture/adr/ADR-0010-architecture-model-reconciliation.md
- architecture/adr/ADR-0011-engineering-canon-phase.md
- architecture/adr/ADR-0012-canonical-documentation-policy.md
- architecture/adr/ADR-0013-validation-engine-reference-implementation.md
- architecture/adr/ADR-0014-quality-gates-vs-validators.md
- architecture/adr/ADR-0015-validation-automation-levels.md
- architecture/adr/ADR-0016-validator-hardening-strategy.md
- architecture/adr/ADR-0017-cross-platform-determinism.md
- architecture/adr/ADR-0018-canonical-metadata-format.md
- architecture/adr/ADR-0019-knowledge-pack-architecture.md
- architecture/adr/ADR-0020-knowledge-dependency-graph.md
- architecture/adr/ADR-0021-capability-resolution.md
- architecture/adr/ADR-0022-knowledge-runtime-contract.md
- architecture/adr/ADR-0023-runtime-integration-validation.md
- architecture/adr/ADR-0024-test-safety-net-and-audit-remediation.md
- architecture/adr/ADR-0025-validation-hygiene.md
- architecture/adr/ADR-0026-release-document-classification.md
- architecture/adr/ADR-0027-multi-ai-experiment-framework.md
- architecture/adr/ADR-0028-consensus-is-evidence.md
- architecture/adr/ADR-0029-independent-execution-protocol.md
- architecture/adr/ADR-0030-human-review-protocol.md
- architecture/adr/ADR-0031-evidence-driven-engineering.md
- architecture/adr/ADR-0032-consensus-execution-layer.md
- architecture/adr/ADR-0033-multi-ai-runtime-foundation.md
- architecture/adr/ADR-0034-human-review-gate.md
- canon/CANON_INCLUSION_CRITERIA.md
- canon/CANON_MAP.md
- canon/CANON_STRATEGY.md
- canon/DECISION_RULES.md
- canon/README.md
- canon/ROADMAP.md
- canon/api/ANTI_PATTERNS.md
- canon/api/CHECKLIST.md
- canon/api/DECISION_RULES.md
- canon/api/PATTERNS.md
- canon/api/PRINCIPLES.md
- canon/api/README.md
- canon/api/ROADMAP.md
- canon/architecture/ANTI_PATTERNS.md
- canon/architecture/CHECKLIST.md
- canon/architecture/DECISION_RULES.md
- canon/architecture/PATTERNS.md
- canon/architecture/PRINCIPLES.md
- canon/architecture/README.md
- canon/architecture/ROADMAP.md
- canon/cloud/ANTI_PATTERNS.md
- canon/cloud/CHECKLIST.md
- canon/cloud/DECISION_RULES.md
- canon/cloud/PATTERNS.md
- canon/cloud/PRINCIPLES.md
- canon/cloud/README.md
- canon/cloud/ROADMAP.md
- canon/data/ANTI_PATTERNS.md
- canon/data/CHECKLIST.md
- canon/data/DECISION_RULES.md
- canon/data/PATTERNS.md
- canon/data/PRINCIPLES.md
- canon/data/README.md
- canon/data/ROADMAP.md
- canon/database/ANTI_PATTERNS.md
- canon/database/CHECKLIST.md
- canon/database/DECISION_RULES.md
- canon/database/PATTERNS.md
- canon/database/PRINCIPLES.md
- canon/database/README.md
- canon/database/ROADMAP.md
- canon/databricks/ANTI_PATTERNS.md
- canon/databricks/CHECKLIST.md
- canon/databricks/DECISION_RULES.md
- canon/databricks/PATTERNS.md
- canon/databricks/PRINCIPLES.md
- canon/databricks/README.md
- canon/databricks/ROADMAP.md
- canon/devops/ANTI_PATTERNS.md
- canon/devops/CHECKLIST.md
- canon/devops/DECISION_RULES.md
- canon/devops/PATTERNS.md
- canon/devops/PRINCIPLES.md
- canon/devops/README.md
- canon/devops/ROADMAP.md
- canon/legacy/ANTI_PATTERNS.md
- canon/legacy/CHECKLIST.md
- canon/legacy/DECISION_RULES.md
- canon/legacy/PATTERNS.md
- canon/legacy/PRINCIPLES.md
- canon/legacy/README.md
- canon/legacy/ROADMAP.md
- canon/security/ANTI_PATTERNS.md
- canon/security/CHECKLIST.md
- canon/security/DECISION_RULES.md
- canon/security/PATTERNS.md
- canon/security/PRINCIPLES.md
- canon/security/README.md
- canon/security/ROADMAP.md
- canon/testing/ANTI_PATTERNS.md
- canon/testing/CHECKLIST.md
- canon/testing/DECISION_RULES.md
- canon/testing/PATTERNS.md
- canon/testing/PRINCIPLES.md
- canon/testing/README.md
- canon/testing/ROADMAP.md
- constitution/AI_EOS_CONSTITUTION.md
- constitution/ENGINEERING_PRINCIPLES.md
- constitution/FIRST_PRINCIPLES.md
- decision-trees/ARCHITECTURE_DECISION_TREE.md
- decision-trees/DATABASE_CHANGE_RISK.md
- decision-trees/MONOLITH_OR_MICROSERVICES.md
- decision-trees/MULTI_AGENT_TRIGGER_TREE.md
- decision-trees/REFACTOR_OR_REWRITE.md
- docs/GETTING_STARTED.md
- docs/GLOSSARY.md
- docs/PROJECT_CHARTER.md
- evaluation/AUDIT_REMEDIATION_DECISION_RULES.md
- evaluation/AUDIT_REMEDIATION_PROPOSAL_TEMPLATE.md
- evaluation/BASELINE_POLICY.md
- evaluation/FRAMEWORK_HEALTH_MODEL.md
- evaluation/QUALITY_MODEL.md
- evaluation/REGRESSION_POLICY.md
- evaluation/REVIEW_LOOP.md
- evaluation/content/CANON_STRUCTURE_CHECK.md
- evaluation/content/CONTENT_DUPLICATION_CHECK.md
- evaluation/content/DOCUMENT_QUALITY_CHECK.md
- evaluation/content/MARKDOWN_RENDER_CHECK.md
- examples/consensus/sample_execution.json
- examples/multi_ai/sample_multi_ai_execution.json
- experiments/EXPERIMENT_LIFECYCLE.md
- experiments/EXPERIMENT_REGISTRY.md
- experiments/EXPERIMENT_RESULT_SCHEMA.md
- experiments/MULTI_AI_CONSENSUS_EXPERIMENT.md
- experiments/README.md
- experiments/benchmark_suite/CONSENSUS_ENGINE_MVP_BENCHMARK.md
- experiments/benchmark_suite/mvp_cases.json
- experiments/templates/CONSENSUS_REPORT_TEMPLATE.md
- experiments/templates/HUMAN_REVIEW_TEMPLATE.md
- experiments/templates/MODEL_RESPONSE_TEMPLATE.md
- experiments/templates/MODEL_TASK_TEMPLATE.md
- experiments/templates/experiment.yaml
- governance/ADR_POLICY.md
- governance/AUDIT_REMEDIATION_POLICY.md
- governance/CANON_DOCUMENT_POLICY.md
- governance/ENGINEERING_EVOLUTION_POLICY.md
- governance/MAINTENANCE_QUEUE.md
- governance/MIGRATION_POLICY.md
- governance/RELEASE_DOCUMENT_POLICY.md
- governance/RELEASE_POLICY.md
- governance/RELEASE_REVIEW_PROTOCOL.md
- harness/CONTEXT_ASSEMBLY_PROTOCOL.md
- harness/HARNESS_MODEL.md
- heuristics/ARCHITECTURAL_HEURISTICS.md
- heuristics/CODING_HEURISTICS.md
- heuristics/DATA_HEURISTICS.md
- heuristics/LEGACY_HEURISTICS.md
- heuristics/SECURITY_HEURISTICS.md
- knowledge/KNOWLEDGE_BOUNDARIES.md
- knowledge/KNOWLEDGE_CORE.md
- knowledge/KNOWLEDGE_LIFECYCLE.md
- knowledge/KNOWLEDGE_MAP.md
- knowledge/KNOWLEDGE_PACK_SPEC.md
- knowledge/KNOWLEDGE_STRATEGY.md
- knowledge/PACKAGE_NAMESPACE_POLICY.md
- knowledge/README.md
- knowledge/failures/FAILURE_KNOWLEDGE_BASE.md
- knowledge/package-identities/KP-ARCHITECTURE.md
- knowledge/package-identities/KP-DATABRICKS.md
- knowledge/package-identities/KP-SECURITY-PRINCIPLES.md
- knowledge/package-identities/KP-SECURITY.md
- knowledge/packs/api/README.md
- knowledge/packs/architecture/README.md
- knowledge/packs/architecture/package.yaml
- knowledge/packs/cloud/README.md
- knowledge/packs/data/README.md
- knowledge/packs/database/README.md
- knowledge/packs/databricks/README.md
- knowledge/packs/databricks/package.yaml
- knowledge/packs/devops/README.md
- knowledge/packs/legacy/README.md
- knowledge/packs/security/OWASP_TOP_10.md
- knowledge/packs/security/README.md
- knowledge/packs/security/SECURITY_PRINCIPLES.md
- knowledge/packs/security/package.yaml
- knowledge/packs/testing/README.md
- labs/LABS_POLICY.md
- multi-agent/CONSENSUS_PROTOCOL.md
- multi-agent/CONSOLIDATOR.md
- multi-agent/ORCHESTRATOR.md
- multi-agent/agents/ARCHITECT_AGENT.md
- multi-agent/agents/DATA_AGENT.md
- multi-agent/agents/DEVOPS_AGENT.md
- multi-agent/agents/IMPLEMENTATION_AGENT.md
- multi-agent/agents/LEGACY_AGENT.md
- multi-agent/agents/PRODUCT_AGENT.md
- multi-agent/agents/QA_AGENT.md
- multi-agent/agents/SECURITY_AGENT.md
- playbooks/README.md
- playbooks/api-change.md
- playbooks/bug-fix.md
- playbooks/database-change.md
- playbooks/incident.md
- playbooks/migration.md
- playbooks/new-feature.md
- playbooks/performance-issue.md
- playbooks/refactoring.md
- reports/benchmark/T-001.consensus-report.json
- reports/benchmark/T-072-CLI.consensus-report.json
- reports/benchmark/benchmark-summary.json
- reports/multi-ai/audit/MULTI-AI-001.multi-ai-audit.json
- reports/multi-ai/sample-multi-ai-run.json
- reports/sample-consensus-report.json
- runtime/EXTENSIBILITY_GUIDE.md
- runtime/RUNTIME_OVERVIEW.md
- runtime/RUNTIME_VISION.md
- runtime/capability/CAPABILITY_MODEL.md
- runtime/consensus/BENCHMARK_RUNNER.md
- runtime/consensus/CONSENSUS_ANALYZER.md
- runtime/consensus/CONSENSUS_ENGINE_MVP.md
- runtime/consensus/CONSENSUS_EXECUTION_LAYER.md
- runtime/consensus/CONSENSUS_INPUT_SCHEMA.json
- runtime/consensus/CONSENSUS_INPUT_SCHEMA.md
- runtime/consensus/CONSENSUS_METRICS.md
- runtime/consensus/CONSENSUS_REGISTRY.md
- runtime/consensus/CONSENSUS_REPORT_SCHEMA.md
- runtime/consensus/DEVILS_ADVOCATE_PROTOCOL.md
- runtime/consensus/DIVERGENCE_REPORT.md
- runtime/consensus/HUMAN_REVIEW_PROTOCOL.md
- runtime/consensus/INDEPENDENT_EXECUTION_PROTOCOL.md
- runtime/consensus/MULTI_AI_AGENT_PROTOCOL.md
- runtime/consensus/PROVIDER_INTERFACE.md
- runtime/consensus/__init__.py
- runtime/consensus/__main__.py
- runtime/consensus/__pycache__/__init__.cpython-313.pyc
- runtime/consensus/__pycache__/__main__.cpython-313.pyc
- runtime/consensus/__pycache__/cli.cpython-313.pyc
- runtime/consensus/__pycache__/engine.cpython-313.pyc
- runtime/consensus/__pycache__/metrics.cpython-313.pyc
- runtime/consensus/__pycache__/provider_interface.cpython-313.pyc
- runtime/consensus/__pycache__/reporting.cpython-313.pyc
- runtime/consensus/cli.py
- runtime/consensus/engine.py
- runtime/consensus/metrics.py
- runtime/consensus/provider_interface.py
- runtime/consensus/reporting.py
- runtime/context/CONTEXT_BUILDER.md
- runtime/context/CONTEXT_MODEL.md
- runtime/contracts/CONTEXT_CONTRACT.md
- runtime/contracts/KNOWLEDGE_RUNTIME_CONTRACT.md
- runtime/contracts/PACKAGE_CONTRACT.md
- runtime/dependency/KNOWLEDGE_DEPENDENCY_GRAPH.md
- runtime/multi_ai/AUDIT_TRAIL.md
- runtime/multi_ai/HUMAN_REVIEW_GATE.md
- runtime/multi_ai/MULTI_AI_RUNTIME.md
- runtime/multi_ai/PROVIDER_ADAPTER_CONTRACT.md
- runtime/multi_ai/PROVIDER_REGISTRY.md
- runtime/multi_ai/__init__.py
- runtime/multi_ai/__main__.py
- runtime/multi_ai/__pycache__/__init__.cpython-313.pyc
- runtime/multi_ai/__pycache__/__main__.cpython-313.pyc
- runtime/multi_ai/__pycache__/audit_trail.cpython-313.pyc
- runtime/multi_ai/__pycache__/cli.cpython-313.pyc
- runtime/multi_ai/__pycache__/consensus_round.cpython-313.pyc
- runtime/multi_ai/__pycache__/human_review_gate.cpython-313.pyc
- runtime/multi_ai/__pycache__/mock_adapter.cpython-313.pyc
- runtime/multi_ai/__pycache__/orchestrator.cpython-313.pyc
- runtime/multi_ai/__pycache__/provider_contract.cpython-313.pyc
- runtime/multi_ai/__pycache__/provider_registry.cpython-313.pyc
- runtime/multi_ai/audit_trail.py
- runtime/multi_ai/cli.py
- runtime/multi_ai/consensus_round.py
- runtime/multi_ai/human_review_gate.py
- runtime/multi_ai/mock_adapter.py
- runtime/multi_ai/orchestrator.py
- runtime/multi_ai/provider_contract.py
- runtime/multi_ai/provider_registry.py
- runtime/quality-gates/QG-001-ARCHITECTURE.md
- runtime/quality-gates/QG-002-SECURITY.md
- runtime/quality-gates/QG-003-TESTS.md
- runtime/quality-gates/QG-004-DOCUMENTATION.md
- runtime/quality-gates/QG-005-OBSERVABILITY.md
- runtime/quality-gates/QG-006-DATA-INTEGRITY.md
- runtime/quality-gates/QG-007-LEGACY-COMPATIBILITY.md
- runtime/quality-gates/QG-008-DEPLOYMENT-ROLLBACK.md
- runtime/quality-gates/QG-009-DEPENDENCY-INTEGRITY.md
- runtime/quality-gates/QG-010-independent-execution.md
- runtime/quality-gates/QG-011-consensus-metrics.md
- runtime/quality-gates/QG-012-experiment-reproducibility.md
- runtime/quality-gates/QG-013-human-decision-required.md
- runtime/quality-gates/QG-014-evidence-completeness.md
- runtime/quality-gates/QG-015-consensus-execution-entrypoint.md
- runtime/quality-gates/QG-016-multi-ai-runtime-foundation.md
- runtime/quality-gates/QUALITY_GATES.md
- runtime/registry/KNOWLEDGE_REGISTRY.md
- runtime/registry/knowledge_registry.yaml
- runtime/routing/MULTI_AGENT_TRIGGER_POLICY.md
- runtime/validation/AUTOMATION_LEVELS.md
- runtime/validation/COMPARISON_CONTRACT.md
- runtime/validation/KNOWLEDGE_VALIDATORS.md
- runtime/validation/PATH_CONTRACT.md
- runtime/validation/QUALITY_GATE_MAPPING.md
- runtime/validation/REPORT_SCHEMA.md
- runtime/validation/SPECIFICATION_COVERAGE_VALIDATOR.md
- runtime/validation/TEST_GATE_POLICY.md
- runtime/validation/VALIDATION_ENGINE.md
- runtime/validation/VALIDATION_ENGINE_CONTRACT.md
- runtime/validation/VALIDATION_REGISTRY.md
- runtime/validation/VALIDATOR_DETERMINISM.md
- runtime/validation/VALIDATOR_HARDENING.md
- runtime/validation/VALIDATOR_MODEL.md
- runtime/validation/YAML_VALIDATION.md
- runtime/validation/reference/python/README.md
- runtime/validation/reference/python/__pycache__/ai_eos_validate.cpython-313.pyc
- runtime/validation/reference/python/__pycache__/path_utils.cpython-313.pyc
- runtime/validation/reference/python/ai_eos_validate.py
- runtime/validation/reference/python/core/__init__.py
- runtime/validation/reference/python/core/__pycache__/__init__.cpython-313.pyc
- runtime/validation/reference/python/core/__pycache__/comparators.cpython-313.pyc
- runtime/validation/reference/python/core/comparators.py
- runtime/validation/reference/python/path_utils.py
- runtime/validation/reference/python/run_tests.py
- runtime/validation/reference/python/tests/README.md
- runtime/validation/reference/python/tests/fixtures/broken-dependency/A.md
- runtime/validation/reference/python/tests/fixtures/duplicate-id/A.md
- runtime/validation/reference/python/tests/fixtures/duplicate-id/B.md
- runtime/validation/reference/python/tests/fixtures/literal-newline/A.md
- runtime/validation/reference/python/tests/fixtures/manifest-inconsistent/A.md
- runtime/validation/reference/python/tests/fixtures/manifest-inconsistent/PACKAGE_MANIFEST.md
- runtime/validation/reference/python/tests/fixtures/near-duplicate/A.md
- runtime/validation/reference/python/tests/fixtures/near-duplicate/B.md
- runtime/validation/reference/python/tests/fixtures/stale-version/A.md
- runtime/validation/reference/python/tests/reproducibility/README.md
- runtime/validation/reference/python/tests/reproducibility/test_path_normalization.py
- runtime/validation/reference/python/tests/runtime_integration/test_allowed_duplicate_group_api.py
- runtime/validation/reference/python/tests/runtime_integration/test_comparators_integration.py
- runtime/validation/reference/python/tests/runtime_integration/test_consensus_cli_hardening.py
- runtime/validation/reference/python/tests/runtime_integration/test_consensus_engine_mvp.py
- runtime/validation/reference/python/tests/runtime_integration/test_consensus_execution_layer.py
- runtime/validation/reference/python/tests/runtime_integration/test_manifest_path_normalization.py
- runtime/validation/reference/python/tests/runtime_integration/test_multi_ai_consensus_artifacts.py
- runtime/validation/reference/python/tests/runtime_integration/test_multi_ai_negative_inputs.py
- runtime/validation/reference/python/tests/runtime_integration/test_multi_ai_runtime_foundation.py
- runtime/validation/reference/python/tests/runtime_integration/test_qg015_integration.py
- runtime/validation/reference/python/tests/runtime_integration/test_release_document_policy.py
- runtime/validation/reference/python/tests/runtime_integration/test_strict_json_reports.py
- runtime/validation/reference/python/tests/runtime_integration/test_version_consistency_validator.py
- runtime/validation/reference/python/tests/runtime_integration/test_yaml_validation.py
- runtime/validation/reference/python/tests/test_negative_fixtures.py
- skills/README.md
- skills/SKILL_MODEL.md
- skills/api-design/skill.md
- skills/architecture-review/checklist.md
- skills/architecture-review/skill.md
- skills/database-design/skill.md
- skills/databricks-engineering/skill.md
- skills/legacy-modernization/skill.md
- skills/security-review/checklist.md
- skills/security-review/output-template.md
- skills/security-review/skill.md
- skills/testing-strategy/skill.md
- templates/ADR_TEMPLATE.md
- templates/DESIGN_DOC_TEMPLATE.md
- templates/RELEASE_NOTES_TEMPLATE.md
- templates/REVIEW_TEMPLATE.md
- templates/RFC_TEMPLATE.md
- templates/RISK_ASSESSMENT_TEMPLATE.md
- templates/SPEC_TEMPLATE.md
- validation-report.json
- vision/AI_EOS_VISION.md
- vision/MATURITY_MODEL.md
- vision/SCOPE.md
