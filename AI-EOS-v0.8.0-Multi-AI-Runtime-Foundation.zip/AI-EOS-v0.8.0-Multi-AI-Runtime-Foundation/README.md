---
id: readme
version: 0.8.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: true
depends_on: [adr-0033, adr-0034]
used_by: []
supersedes: null
---

# AI-EOS v0.8.0 — Multi-AI Runtime Foundation

AI-EOS v0.8.0 introduces the first auditable Multi-AI runtime foundation.

## Release Objective

Create the operational seam for sending the same scope to multiple AI providers, collecting normalized responses, running a consensus round, applying a human review gate and writing an audit trail.

## Scope

v0.8.0 uses deterministic mock adapters only. Real provider integrations are intentionally out of scope.

## Main Commands

```bash
python -m runtime.multi_ai --input examples/multi_ai/sample_multi_ai_execution.json --output reports/multi-ai/sample-multi-ai-run.json
python runtime/validation/reference/python/run_tests.py
python runtime/validation/reference/python/ai_eos_validate.py . --output validation-report.json
```

## Components

- Provider Adapter Contract
- Provider Registry
- MultiAIOrchestrator
- ConsensusRound
- HumanReviewGate
- AuditTrail
