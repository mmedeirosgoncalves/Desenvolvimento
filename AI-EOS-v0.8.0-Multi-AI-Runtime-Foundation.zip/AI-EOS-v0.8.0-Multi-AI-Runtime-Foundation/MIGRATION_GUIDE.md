---
id: migration-guide
version: 0.8.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: true
depends_on: [adr-0033]
used_by: []
supersedes: null
---

# Migration Guide — v0.7.3 to v0.8.0

## Summary

v0.8.0 adds the Multi-AI Runtime Foundation without changing the existing v0.7.3 consensus CLI.

## New Runtime

Use:

```bash
python -m runtime.multi_ai --input examples/multi_ai/sample_multi_ai_execution.json --output reports/multi-ai/sample-multi-ai-run.json
```

## Provider Scope

Only mock providers are supported in v0.8.0. Real provider adapters are planned for a future release.
