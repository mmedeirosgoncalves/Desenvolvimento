---
id: roadmap
version: 0.8.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: true
depends_on: []
used_by: []
supersedes: null
---

# Roadmap

## Completed

### v0.7.0 — Multi-AI Consensus Experiment

Defined the concept.

### v0.7.1 — Consensus Engine MVP

Introduced the deterministic consensus engine library.

### v0.7.2 — Consensus Execution Layer

Exposed consensus through operational CLI and benchmark runner.

### v0.7.3 — Execution Layer Hardening

Hardened JSON, CLI, QG-015 and release governance.

### v0.8.0 — Multi-AI Runtime Foundation

Introduces provider adapters, registry, orchestrator, consensus round, human review gate and audit trail using deterministic mock providers.

## Next

### v0.8.1 — Real Provider Adapter Pilot

Add the first real provider adapter behind the v0.8.0 contract, keeping mocks as the validation baseline.
