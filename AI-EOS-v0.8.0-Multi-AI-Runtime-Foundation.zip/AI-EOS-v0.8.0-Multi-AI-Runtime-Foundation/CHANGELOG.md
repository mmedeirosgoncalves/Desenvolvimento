---
id: changelog
version: 0.8.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: true
depends_on: []
used_by: []
supersedes: null
---

# Changelog

## v0.8.0 — Multi-AI Runtime Foundation

- Added Provider Adapter Contract.
- Added Provider Registry.
- Added deterministic MockProviderAdapter.
- Added MultiAIOrchestrator.
- Added ConsensusRound wrapper.
- Added HumanReviewGate.
- Added AuditTrail writer.
- Added Multi-AI CLI entrypoint.
- Added QG-016 Multi-AI Runtime Foundation.
- Added ADR-0033 and ADR-0034.
- Added positive and negative Multi-AI runtime tests.
- Preserved v0.7.3 Execution Layer Hardening baseline.

## v0.7.3 — Execution Layer Hardening

- Enforced strict JSON reporting.
- Integrated QG-015.
- Hardened consensus CLI input validation.
