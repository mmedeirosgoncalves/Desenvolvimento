---
id: release-validation
version: 0.8.5
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: true
depends_on: []
used_by: []
supersedes: null
---

# Release Validation — v0.8.5

Validation must be generated, not hand-authored.

```bash
python runtime/validation/runtime_selftest.py
python runtime/validation/build_validation_report.py . validation-report.json
python runtime/graph/runtime_callgraph.py reports/runtime-callgraph.json .
python runtime/coverage/runtime_coverage.py reports/runtime-coverage.json .
```
