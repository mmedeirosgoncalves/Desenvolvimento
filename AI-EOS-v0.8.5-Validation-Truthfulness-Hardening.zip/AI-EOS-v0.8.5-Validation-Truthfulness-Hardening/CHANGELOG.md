---
id: changelog
version: 0.8.5
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: true
depends_on: []
used_by: []
supersedes: null
---

# Changelog

## v0.8.5 — Validation Truthfulness Hardening

- Replaced hardcoded runtime callgraph with AST import graph.
- Replaced import-only runtime coverage with definition-and-usage coverage.
- Added generated validation report builder.
- Added ADR-0041 for provider layer consolidation.
