---
id: migration-guide
version: 0.8.5
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: true
depends_on: [adr-0041]
used_by: []
supersedes: null
---

# Migration Guide — v0.8.4 to v0.8.5

Use:

```bash
python runtime/validation/build_validation_report.py . validation-report.json
```

Provider-layer rule:
- new provider code must live in `runtime/providers/`;
- legacy provider surfaces should delegate to `runtime/providers/`.
