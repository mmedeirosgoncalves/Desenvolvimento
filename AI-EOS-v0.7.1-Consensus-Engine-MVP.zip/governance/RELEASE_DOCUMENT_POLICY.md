---
id: release-document-policy
version: 0.7.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-07
review_date: 2026-10-06
release_document: true
depends_on: [adr-0026, adr-0025]
used_by: []
supersedes: null
---

# Release Document Policy

## Purpose

Define which documents participate in release-level version validation.

## Document Classes

AI-EOS distinguishes two classes of Markdown documents:

1. Release documents.
2. Informational documents.

A release document is a document whose front matter declares:

```yaml
release_document: true
```

A document without this field, or with `release_document: false`, is treated as informational for release-version validation.

## Rules

Release documents must declare:

- `id`
- `version`
- `status`
- `updated`
- `review_date`
- `release_document: true`

Release documents must have `version` equal to the framework version declared in `VERSION`.

Informational documents may contain a version field, but they are not checked for release-level version consistency unless explicitly marked as release documents.

## README.md

The root `README.md` is considered a release document because it is the distribution entry point.

Domain-level README files are informational unless explicitly marked otherwise.

## Rationale

The policy avoids two anti-patterns:

- hardcoded allow-lists in validators;
- treating all Markdown documents as release documents based only on file location.
