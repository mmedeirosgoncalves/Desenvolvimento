"""Executable Consensus Engine MVP.

This module intentionally implements a small deterministic consensus algorithm.
It is not the final Divergence Engine, Judge Engine or Adaptive Orchestrator.
Its purpose is to convert the v0.7.0 consensus protocol into auditable software.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Iterable, Sequence
import re
import time
from .provider_interface import ProviderResponse
from .metrics import consensus_agreement_rate

_SENTENCE_SPLIT = re.compile(r"(?<=[.!?])\s+|\n+")
_WORD = re.compile(r"[a-z0-9_]+", re.IGNORECASE)

@dataclass(frozen=True)
class ConsensusInput:
    task_id: str
    responses: Sequence[ProviderResponse]

@dataclass(frozen=True)
class ConsensusResult:
    task_id: str
    consensus_response: str
    shared_claims: list[str]
    unique_claims: dict[str, list[str]]
    conflicts: list[str]
    agreement_rate: float
    provider_count: int
    latency_ms: int
    warnings: list[str]

    def to_dict(self) -> dict:
        data = asdict(self)
        data["engine"] = "consensus-engine-mvp"
        data["version"] = "0.7.1"
        return data

class ConsensusEngine:
    """Deterministic consensus engine for independent model responses."""
    def build(self, data: ConsensusInput) -> ConsensusResult:
        start = time.perf_counter()
        if not data.responses:
            raise ValueError("ConsensusInput.responses must not be empty")
        warnings: list[str] = []
        if len(data.responses) < 2:
            warnings.append("single_response_consensus_has_no_cross_model_evidence")

        claims_by_provider = {r.provider_id: self._claims(r.content) for r in data.responses}
        normalized_counts: dict[str, int] = {}
        normalized_original: dict[str, str] = {}
        for claims in claims_by_provider.values():
            seen = set()
            for claim in claims:
                key = self._normalize_claim(claim)
                if not key or key in seen:
                    continue
                seen.add(key)
                normalized_counts[key] = normalized_counts.get(key, 0) + 1
                normalized_original.setdefault(key, claim)
        threshold = 2 if len(data.responses) >= 2 else 1
        shared = [normalized_original[k] for k, c in normalized_counts.items() if c >= threshold]
        unique: dict[str, list[str]] = {}
        for pid, claims in claims_by_provider.items():
            unique[pid] = [c for c in claims if normalized_counts.get(self._normalize_claim(c), 0) == 1]
        conflicts = self._detect_conflicts(claims_by_provider)
        total_claims = len(normalized_counts)
        agreement = consensus_agreement_rate(len(shared), total_claims)
        response = self._render(shared, unique, conflicts, warnings)
        latency_ms = int((time.perf_counter() - start) * 1000)
        return ConsensusResult(
            task_id=data.task_id,
            consensus_response=response,
            shared_claims=shared,
            unique_claims=unique,
            conflicts=conflicts,
            agreement_rate=agreement,
            provider_count=len(data.responses),
            latency_ms=latency_ms,
            warnings=warnings,
        )

    def _claims(self, text: str) -> list[str]:
        parts = [x.strip(" -	") for x in _SENTENCE_SPLIT.split(text.strip())]
        return [x for x in parts if x]

    def _normalize_claim(self, claim: str) -> str:
        return " ".join(w.lower() for w in _WORD.findall(claim))

    def _detect_conflicts(self, claims_by_provider: dict[str, list[str]]) -> list[str]:
        all_claims = [(pid, c, self._normalize_claim(c)) for pid, claims in claims_by_provider.items() for c in claims]
        conflicts: list[str] = []
        for i, (pa, ca, na) in enumerate(all_claims):
            words_a = set(na.split())
            neg_a = {"not", "no", "never", "cannot", "can't"} & words_a
            for pb, cb, nb in all_claims[i+1:]:
                if pa == pb:
                    continue
                words_b = set(nb.split())
                overlap = len(words_a & words_b)
                if overlap >= 3:
                    neg_b = {"not", "no", "never", "cannot", "can't"} & words_b
                    if bool(neg_a) != bool(neg_b):
                        conflicts.append(f"{pa} vs {pb}: {ca} / {cb}")
        return conflicts

    def _render(self, shared: list[str], unique: dict[str, list[str]], conflicts: list[str], warnings: list[str]) -> str:
        lines = ["Consensus Engine MVP result."]
        if shared:
            lines.append("Shared findings:")
            lines.extend(f"- {claim}" for claim in shared)
        else:
            lines.append("No shared finding reached the MVP consensus threshold.")
        if conflicts:
            lines.append("Explicit conflicts requiring review:")
            lines.extend(f"- {c}" for c in conflicts)
        if warnings:
            lines.append("Warnings:")
            lines.extend(f"- {w}" for w in warnings)
        return "\n".join(lines)
