"""JSON reporting for consensus executions."""
from __future__ import annotations
from pathlib import Path
import json
from .engine import ConsensusResult
from .provider_interface import ProviderResponse

def build_consensus_report(execution_id: str, responses: list[ProviderResponse], result: ConsensusResult) -> dict:
    return {
        "execution_id": execution_id,
        "engine": "consensus-engine-mvp",
        "version": "0.7.1",
        "providers": [r.provider_id for r in responses],
        "individual_responses": [r.__dict__ for r in responses],
        "consensus_result": result.to_dict(),
        "cost": sum(float(r.cost) for r in responses),
        "token_usage": {
            "input_tokens": sum(int(r.input_tokens) for r in responses),
            "output_tokens": sum(int(r.output_tokens) for r in responses),
        },
        "warnings": result.warnings,
    }

def write_consensus_report(path: str | Path, report: dict) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(report, indent=2, sort_keys=True), encoding="utf-8")
