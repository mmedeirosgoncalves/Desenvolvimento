---
id: package-manifest
version: 0.7.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-07
review_date: 2026-10-06
release_document: true
depends_on: [adr-0027, adr-0028, adr-0029, adr-0030]
used_by: []
supersedes: null
---

# Package Manifest

## Release

AI-EOS v0.7.1 Consensus Engine MVP

## Baseline

AI-EOS v0.7.0 Multi-AI Consensus Experiment.

## Entry Point

`AGENTS.md`

## Version Source

`VERSION`

## Markdown Files

298

## YAML Files

5

## Python Files

20

## Top-Level Areas

- adapters/
- agents/
- architecture/
- canon/
- constitution/
- decision-trees/
- docs/
- evaluation/
- experiments/
- governance/
- harness/
- heuristics/
- knowledge/
- labs/
- multi-agent/
- playbooks/
- runtime/
- skills/
- templates/
- vision/

## Added Files

- architecture/adr/ADR-0031-evidence-driven-engineering.md
- experiments/EXPERIMENT_REGISTRY.md
- experiments/benchmark_suite/CONSENSUS_ENGINE_MVP_BENCHMARK.md
- experiments/benchmark_suite/mvp_cases.json
- knowledge/failures/FAILURE_KNOWLEDGE_BASE.md
- runtime/consensus/CONSENSUS_ENGINE_MVP.md
- runtime/consensus/CONSENSUS_REPORT_SCHEMA.md
- runtime/consensus/PROVIDER_INTERFACE.md
- runtime/consensus/__init__.py
- runtime/consensus/engine.py
- runtime/consensus/metrics.py
- runtime/consensus/provider_interface.py
- runtime/consensus/reporting.py
- runtime/validation/reference/python/tests/runtime_integration/test_consensus_engine_mvp.py

- architecture/adr/ADR-0027-multi-ai-experiment-framework.md
- architecture/adr/ADR-0028-consensus-is-evidence.md
- architecture/adr/ADR-0029-independent-execution-protocol.md
- architecture/adr/ADR-0030-human-review-protocol.md
- experiments/EXPERIMENT_LIFECYCLE.md
- experiments/EXPERIMENT_RESULT_SCHEMA.md
- experiments/MULTI_AI_CONSENSUS_EXPERIMENT.md
- experiments/README.md
- experiments/templates/CONSENSUS_REPORT_TEMPLATE.md
- experiments/templates/HUMAN_REVIEW_TEMPLATE.md
- experiments/templates/MODEL_RESPONSE_TEMPLATE.md
- experiments/templates/MODEL_TASK_TEMPLATE.md
- experiments/templates/experiment.yaml
- runtime/consensus/CONSENSUS_ANALYZER.md
- runtime/consensus/CONSENSUS_METRICS.md
- runtime/consensus/CONSENSUS_REGISTRY.md
- runtime/consensus/DEVILS_ADVOCATE_PROTOCOL.md
- runtime/consensus/DIVERGENCE_REPORT.md
- runtime/consensus/HUMAN_REVIEW_PROTOCOL.md
- runtime/consensus/INDEPENDENT_EXECUTION_PROTOCOL.md
- runtime/consensus/MULTI_AI_AGENT_PROTOCOL.md
- runtime/quality-gates/QG-010-independent-execution.md
- runtime/quality-gates/QG-011-consensus-metrics.md
- runtime/quality-gates/QG-012-experiment-reproducibility.md
- runtime/quality-gates/QG-013-human-decision-required.md
- runtime/quality-gates/QG-014-evidence-completeness.md
- runtime/validation/reference/python/tests/runtime_integration/test_multi_ai_consensus_artifacts.py

## Removed Files

None.
