---
id: changelog
version: 0.7.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-07
release_document: true
review_date: 2026-10-06
depends_on: [adr-0023]
used_by: []
supersedes: null
---

# Changelog

## v0.7.1 — Consensus Engine MVP

- Added executable Consensus Engine MVP.
- Added provider abstraction and deterministic MockProvider.
- Added consensus JSON reporting.
- Added CGI, CCI, CLR and CAR metric functions.
- Added MVP benchmark artifacts and experiment registry.
- Added Failure Knowledge Base.
- Added ADR-0031 Evidence-driven Engineering.
- Added runtime integration test for the executable consensus engine.


## v0.7.0 — Multi-AI Consensus Experiment

- Introduced experimental Multi-AI Consensus framework.
- Added Independent Execution Protocol.
- Added Consensus Analyzer, Consensus Metrics and Divergence Report.
- Added Devil's Advocate Protocol.
- Added Human Review Protocol.
- Added experiment templates.
- Added ADR-0027 through ADR-0030.
- Added QG-010 through QG-014.

## v0.6.1.0 — Validation Governance

- Introduced explicit release-document classification using `release_document: true`.
- Added root `VERSION` file as the single framework-version source.
- Removed hardcoded release-document allow-list from the version validator.
- Marked root `README.md` as a release document and aligned its version.
- Added ADR-0026 and RELEASE_DOCUMENT_POLICY.
- Added runtime integration tests for release-document classification.

## v0.6.0.3 — Validation Hygiene

- Removed external environment traceback noise from release validation records.
- Aligned release-level version metadata.
- Extended `version-consistency-validator` to report stale release-document versions.
- Added ADR-0025 Validation Hygiene.
- Added runtime integration test for version metadata consistency.

## v0.6.0.2 — Safety Net + Audit Remediation Governance

- Restored fixture-root detection in the reference validator.
- Restored render, duplication and version validators.
- Preserved `allowed_duplicate_group` compatibility.
- Added in-package validation test runner.
- Added ARP governance: ADR-0024, audit remediation policy, template and decision rules.
- RELEASE_VALIDATION now treats failing tests as release failure.

## v0.6.0.1 — Runtime Integration

### Added

- YAML validation for Knowledge Pack manifests and Knowledge Registry.
- Specification Coverage Validator.
- Runtime integration tests for comparators, manifest path normalization and YAML validation.
- ADR-0023 — Runtime Integration Validation.

### Changed

- `ai_eos_validate.py` now imports and uses shared comparator utilities.
- Manifest validation now uses consistent normalized path comparison.
- Validation Engine now scans `.yaml` production artifacts.
- `validation-report.json` regenerated after final package changes.
- RELEASE_VALIDATION distinguishes presence from executable validation.

### Fixed

- Dead-code issue for `core/comparators.py`.
- Manifest validator false positives caused by trailing slash normalization.
- Knowledge Pack YAML artifacts being invisible to Validation Engine.
- Stale validation report in v0.6.0.

## v0.6.0 — Knowledge Pack Foundation

- Introduced Knowledge Pack Foundation.
