---
id: readme
version: 0.5.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [validation-engine, adr-0013, adr-0014, adr-0015]
used_by: []
supersedes: null
---

# AI-EOS v0.5.0 Validation Engine

AI-EOS is an Artificial Intelligence Engineering Operating System for AI-assisted software engineering.

This release introduces the Validation Engine.

## Baseline

v0.4.1 Canon Stabilization.

## What This Release Adds

- Validation Engine contract.
- Validator model.
- Automation levels.
- Validation registry.
- Quality Gate mapping.
- Report schema.
- Python reference validator.

## Architectural Decisions

- Validation Engine is vendor-agnostic and language-agnostic by contract.
- Python is a reference implementation for validating AI-EOS itself.
- Quality Gates are separated from Validators.
- Automation levels are formalized as L0, L1 and L2.

## Reference Validator

From the AI-EOS root:

```bash
python runtime/validation/reference/python/ai_eos_validate.py .
```

## Status

v0.5.0 starts the transition from documented gates to executable validation.
