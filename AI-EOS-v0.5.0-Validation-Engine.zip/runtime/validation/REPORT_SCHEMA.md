---
id: validation-report-schema
version: 0.5.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [validation-engine-contract]
used_by: []
supersedes: null
---

# Validation Report Schema

## Human-Readable Report

```text
Release:
Baseline:
Validation Engine:
Validators:
Gate Results:
Findings:
Recommendation:
```

## Machine-Readable Report

```json
{
  "release": "AI-EOS v0.5.0",
  "baseline": "AI-EOS v0.4.1",
  "summary": {
    "status": "PASS",
    "files": 0,
    "ids": 0,
    "findings": 0
  },
  "validators": [],
  "quality_gates": [],
  "recommendation": "ACCEPT"
}
```

## Recommendation Values

- ACCEPT
- ACCEPT_WITH_RECOMMENDATIONS
- REJECT
