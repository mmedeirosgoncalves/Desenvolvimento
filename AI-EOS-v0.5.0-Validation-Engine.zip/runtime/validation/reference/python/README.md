---
id: python-reference-validator
version: 0.5.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [validation-engine-contract]
used_by: []
supersedes: null
---

# Python Reference Validator

## Purpose

This directory contains the Python reference implementation of the AI-EOS Validation Engine.

## Usage

From the AI-EOS root:

```bash
python runtime/validation/reference/python/ai_eos_validate.py .
```

To write a JSON report:

```bash
python runtime/validation/reference/python/ai_eos_validate.py . --json validation-report.json
```

## Scope

This implementation validates the AI-EOS repository itself.

It is not the only valid implementation of the Validation Engine contract.
