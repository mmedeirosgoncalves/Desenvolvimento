#!/usr/bin/env python3
"""
AI-EOS Reference Validator

Reference implementation for validating the AI-EOS repository itself.

This script is intentionally dependency-light and uses only the Python standard library.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import hashlib
from pathlib import Path
from collections import defaultdict


STATUS_PASS = "PASS"
STATUS_FAIL = "FAIL"
STATUS_WARNING = "WARNING"


def parse_front_matter(text: str):
    if not text.startswith("---"):
        return {}, text
    parts = text.split("---", 2)
    if len(parts) < 3:
        return {}, text
    raw = parts[1]
    body = parts[2].lstrip()
    meta = {}
    for line in raw.strip().splitlines():
        if ":" in line:
            key, value = line.split(":", 1)
            meta[key.strip()] = value.strip()
    return meta, body


def parse_list_value(value: str):
    if not value:
        return []
    return re.findall(r"[\w-]+", value)


def markdown_files(root: Path):
    return sorted(root.rglob("*.md"))


def collect_ids(root: Path):
    ids = {}
    duplicates = []
    deps = {}
    supersedes = {}
    missing_frontmatter = []

    for path in markdown_files(root):
        rel = str(path.relative_to(root))
        text = path.read_text(encoding="utf-8")
        meta, _ = parse_front_matter(text)
        artifact_id = meta.get("id")

        if not meta:
            missing_frontmatter.append(rel)
            continue

        if not artifact_id:
            missing_frontmatter.append(rel)
            continue

        if artifact_id in ids:
            duplicates.append({"id": artifact_id, "first": ids[artifact_id], "second": rel})
        ids[artifact_id] = rel

        deps[artifact_id] = parse_list_value(meta.get("depends_on", "[]"))

        sup = meta.get("supersedes", "null")
        if sup and sup != "null":
            supersedes[artifact_id] = sup

    return ids, duplicates, deps, supersedes, missing_frontmatter


def validate_dependency_graph(root: Path):
    ids, duplicates, deps, supersedes, missing_fm = collect_ids(root)

    unresolved = []
    for artifact_id, dep_list in deps.items():
        for dep in dep_list:
            if dep not in ids:
                unresolved.append({"source": artifact_id, "target": dep})

    unresolved_supersedes = []
    for artifact_id, target in supersedes.items():
        if target not in ids:
            unresolved_supersedes.append({"source": artifact_id, "target": target})

    findings = []
    if duplicates:
        findings.append({"severity": "CRITICAL", "message": "Duplicate ids found", "items": duplicates})
    if unresolved:
        findings.append({"severity": "CRITICAL", "message": "Unresolved depends_on references", "items": unresolved})
    if unresolved_supersedes:
        findings.append({"severity": "HIGH", "message": "Unresolved supersedes references", "items": unresolved_supersedes})
    if missing_fm:
        findings.append({"severity": "MEDIUM", "message": "Missing or incomplete front matter", "items": missing_fm})

    return {
        "validator_id": "dependency-graph-validator",
        "status": STATUS_PASS if not duplicates and not unresolved and not unresolved_supersedes else STATUS_FAIL,
        "gates": ["qg-009-dependency-integrity"],
        "evidence": {
            "ids": len(ids),
            "duplicates": len(duplicates),
            "unresolved_dependencies": len(unresolved),
            "unresolved_supersedes": len(unresolved_supersedes),
            "missing_frontmatter": len(missing_fm),
        },
        "findings": findings,
    }


def validate_bootstrap(root: Path):
    agents = root / "AGENTS.md"
    missing = []
    if not agents.exists():
        missing.append("AGENTS.md")
    else:
        text = agents.read_text(encoding="utf-8")
        for match in re.finditer(r"`([^`]+\.md)`", text):
            rel = match.group(1)
            if not (root / rel).exists():
                missing.append(rel)

    return {
        "validator_id": "bootstrap-validator",
        "status": STATUS_PASS if not missing else STATUS_FAIL,
        "gates": ["qg-009-dependency-integrity"],
        "evidence": {"missing_bootstrap_references": len(missing)},
        "findings": [{"severity": "CRITICAL", "message": "Missing bootstrap references", "items": missing}] if missing else [],
    }


def validate_markdown_render(root: Path):
    findings = []
    literal_newlines = []

    for path in markdown_files(root):
        rel = str(path.relative_to(root))
        text = path.read_text(encoding="utf-8")
        # Ignore files that intentionally describe the pattern as a check.
        if "\\n" in text and "literal `\\\\n`" not in text and "literal `\\n`" not in text:
            literal_newlines.append(rel)

        if text.count("```") % 2 != 0:
            findings.append({"severity": "HIGH", "message": "Unclosed code fence", "file": rel})

    if literal_newlines:
        findings.append({"severity": "MEDIUM", "message": "Literal escaped newlines found", "items": literal_newlines})

    return {
        "validator_id": "markdown-render-validator",
        "status": STATUS_PASS if not findings else STATUS_WARNING,
        "gates": ["qg-004-documentation"],
        "evidence": {"literal_newline_files": len(literal_newlines), "findings": len(findings)},
        "findings": findings,
    }


def normalized_body(path: Path):
    text = path.read_text(encoding="utf-8")
    _, body = parse_front_matter(text)
    return re.sub(r"\s+", " ", body.strip())


def validate_content_duplication(root: Path):
    groups = defaultdict(list)
    for path in markdown_files(root):
        rel = str(path.relative_to(root))
        body = normalized_body(path)
        if not body:
            continue
        digest = hashlib.sha256(body.encode("utf-8")).hexdigest()
        groups[digest].append(rel)

    duplicates = [items for items in groups.values() if len(items) > 1]

    # Reference stubs are allowed for Canon domain decision/roadmap files.
    allowed = []
    unexpected = []
    for group in duplicates:
        if all(re.match(r"canon/[^/]+/(DECISION_RULES|ROADMAP)\.md$", item) for item in group):
            allowed.append(group)
        else:
            unexpected.append(group)

    return {
        "validator_id": "content-duplication-validator",
        "status": STATUS_PASS if not unexpected else STATUS_WARNING,
        "gates": ["qg-004-documentation"],
        "evidence": {"duplicate_groups": len(duplicates), "unexpected_duplicate_groups": len(unexpected)},
        "findings": [{"severity": "MEDIUM", "message": "Unexpected duplicate content", "items": unexpected}] if unexpected else [],
    }


def validate_manifest(root: Path):
    manifest = root / "PACKAGE_MANIFEST.md"
    findings = []
    actual_md = len(markdown_files(root))

    declared = None
    if not manifest.exists():
        findings.append({"severity": "HIGH", "message": "PACKAGE_MANIFEST.md missing"})
    else:
        text = manifest.read_text(encoding="utf-8")
        match = re.search(r"## Markdown Files\s+(\d+)", text)
        if match:
            declared = int(match.group(1))
            if declared != actual_md:
                findings.append({
                    "severity": "MEDIUM",
                    "message": "Markdown file count mismatch",
                    "declared": declared,
                    "actual": actual_md,
                })
        else:
            findings.append({"severity": "LOW", "message": "Markdown file count not declared"})

    return {
        "validator_id": "manifest-validator",
        "status": STATUS_PASS if not findings else STATUS_WARNING,
        "gates": ["qg-009-dependency-integrity"],
        "evidence": {"actual_markdown_files": actual_md, "declared_markdown_files": declared},
        "findings": findings,
    }


def run(root: Path):
    validators = [
        validate_dependency_graph(root),
        validate_bootstrap(root),
        validate_markdown_render(root),
        validate_content_duplication(root),
        validate_manifest(root),
    ]

    has_fail = any(v["status"] == STATUS_FAIL for v in validators)
    has_warning = any(v["status"] == STATUS_WARNING for v in validators)

    if has_fail:
        status = "FAIL"
        recommendation = "REJECT"
    elif has_warning:
        status = "WARNING"
        recommendation = "ACCEPT_WITH_RECOMMENDATIONS"
    else:
        status = "PASS"
        recommendation = "ACCEPT"

    return {
        "release": "AI-EOS",
        "validation_engine": "reference-python",
        "summary": {
            "status": status,
            "markdown_files": len(markdown_files(root)),
            "validators": len(validators),
            "findings": sum(len(v["findings"]) for v in validators),
        },
        "validators": validators,
        "recommendation": recommendation,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("root", nargs="?", default=".", help="AI-EOS repository root")
    parser.add_argument("--json", dest="json_path", help="Write JSON report to path")
    args = parser.parse_args()

    root = Path(args.root).resolve()
    report = run(root)

    print(json.dumps(report, indent=2, ensure_ascii=False))

    if args.json_path:
        Path(args.json_path).write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")

    return 0 if report["summary"]["status"] in {"PASS", "WARNING"} else 1


if __name__ == "__main__":
    raise SystemExit(main())
