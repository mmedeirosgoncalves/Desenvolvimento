---
id: package-manifest
version: 0.5.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [validation-engine, qg-009-dependency-integrity]
used_by: []
supersedes: null
---

# Package Manifest

## Release

AI-EOS v0.5.0 Validation Engine

## Baseline

AI-EOS v0.4.1 Canon Stabilization.

## Purpose

This release introduces the Validation Engine and Python reference validator.

## Entry Point

`AGENTS.md`

## Markdown Files

221

## Top-Level Areas

- adapters/
- agents/
- architecture/
- canon/
- constitution/
- decision-trees/
- docs/
- evaluation/
- governance/
- harness/
- heuristics/
- knowledge/
- labs/
- multi-agent/
- playbooks/
- runtime/
- skills/
- templates/
- vision/

## Added Files

- architecture/adr/ADR-0013-validation-engine-reference-implementation.md
- architecture/adr/ADR-0014-quality-gates-vs-validators.md
- architecture/adr/ADR-0015-validation-automation-levels.md
- runtime/validation/AUTOMATION_LEVELS.md
- runtime/validation/QUALITY_GATE_MAPPING.md
- runtime/validation/REPORT_SCHEMA.md
- runtime/validation/VALIDATION_ENGINE.md
- runtime/validation/VALIDATION_ENGINE_CONTRACT.md
- runtime/validation/VALIDATION_REGISTRY.md
- runtime/validation/VALIDATOR_MODEL.md
- runtime/validation/reference/python/README.md
- runtime/validation/reference/python/ai_eos_validate.py
- validation-report.json

## Validation Summary

- Baseline files removed: 0
- Duplicate ids: 0
- Unresolved dependencies: 0
- Missing bootstrap references: 0
- Reference validator status: PASS
- Reference validator recommendation: ACCEPT

## Status

Recommended for independent review.
