---
id: changelog
version: 0.5.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [adr-0013, adr-0014, adr-0015]
used_by: []
supersedes: null
---

# Changelog

## v0.5.0 — Validation Engine

### Added

- `runtime/validation/VALIDATION_ENGINE.md`
- `runtime/validation/VALIDATION_ENGINE_CONTRACT.md`
- `runtime/validation/VALIDATOR_MODEL.md`
- `runtime/validation/AUTOMATION_LEVELS.md`
- `runtime/validation/VALIDATION_REGISTRY.md`
- `runtime/validation/QUALITY_GATE_MAPPING.md`
- `runtime/validation/REPORT_SCHEMA.md`
- Python reference validator:
  - `runtime/validation/reference/python/ai_eos_validate.py`
  - `runtime/validation/reference/python/README.md`
- ADR-0013 — Validation Engine Contract and Python Reference Implementation
- ADR-0014 — Separate Quality Gates from Validators
- ADR-0015 — Validation Automation Levels

### Changed

- QG-009 classified as L2 Automated / Blocking.
- QG-004 classified as L1 Semi-Automated.
- QG-001 classified as L0/L1.
- `AGENTS.md` updated with Validation Engine rule.
- `QUALITY_MODEL.md`, `FRAMEWORK_HEALTH_MODEL.md` and `REVIEW_LOOP.md` updated.

### Preserved

- All v0.4.1 baseline files.
- All Canon content.
- All Knowledge Packs.
- All Skills and Playbooks.
