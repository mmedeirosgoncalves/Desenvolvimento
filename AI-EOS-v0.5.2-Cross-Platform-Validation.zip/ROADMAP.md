---
id: roadmap
version: 0.5.2
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [validation-path-contract]
used_by: []
supersedes: null
---

# AI-EOS Roadmap

## v0.5.2 — Cross-Platform Validation

- Normalize validator paths.
- Add cross-platform path contract.
- Add path reproducibility tests.
- Fix duplicate allow-list portability.

## v0.6 — Knowledge Pack Expansion

- Mature 3 to 5 Knowledge Packs.
- Add examples.
- Add decision trees.
- Add checklists.
- Add anti-patterns.
- Align Knowledge Packs with Canon.

## v0.7 — Skill Refactoring

- Refactor Skills as application mechanisms.
- Remove duplicated domain knowledge from Skills.
- Add skill maturity scoring.

## v0.8 — Review Engine

- Manifest validator.
- Dependency linter.
- Knowledge Coverage scoring.
- Release scoring.

## v0.9 — Multi-Agent Runtime

- Specialist agent orchestration.
- Consensus protocol.
- Conflict resolution.
- Multi-agent reporting.

## v1.0 — Stable AI-EOS

- Stable architecture.
- Mature Canon.
- Mature Knowledge Packs.
- Mature Skills.
- Runtime protocols.
- Review Engine.
- Vendor adapters.
