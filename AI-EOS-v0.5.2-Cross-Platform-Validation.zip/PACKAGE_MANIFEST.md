---
id: package-manifest
version: 0.5.2
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [validation-path-contract, qg-009-dependency-integrity]
used_by: []
supersedes: null
---

# Package Manifest

## Release

AI-EOS v0.5.2 Cross-Platform Validation

## Baseline

AI-EOS v0.5.1 Validator Hardening.

## Purpose

This release makes the Validation Engine path-deterministic across operating systems.

## Entry Point

`AGENTS.md`

## Markdown Files

228

## Test Fixture Markdown Files

9

## Top-Level Areas

- adapters/
- agents/
- architecture/
- canon/
- constitution/
- decision-trees/
- docs/
- evaluation/
- governance/
- harness/
- heuristics/
- knowledge/
- labs/
- multi-agent/
- playbooks/
- runtime/
- skills/
- templates/
- vision/

## Added Files

- architecture/adr/ADR-0017-cross-platform-determinism.md
- runtime/validation/PATH_CONTRACT.md
- runtime/validation/VALIDATOR_DETERMINISM.md
- runtime/validation/reference/python/__pycache__/path_utils.cpython-313.pyc
- runtime/validation/reference/python/path_utils.py
- runtime/validation/reference/python/tests/reproducibility/README.md
- runtime/validation/reference/python/tests/reproducibility/test_path_normalization.py

## Validation Summary

- Baseline files removed: 0
- Duplicate ids: 0
- Unresolved dependencies: 0
- Missing bootstrap references: 0
- Reference validator status: WARNING
- Reference validator recommendation: ACCEPT_WITH_RECOMMENDATIONS
- Negative fixture tests: PASS
- Reproducibility tests: PASS

## Status

Recommended for independent review.
