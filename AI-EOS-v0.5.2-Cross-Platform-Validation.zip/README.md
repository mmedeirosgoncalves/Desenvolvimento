---
id: readme
version: 0.5.2
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [adr-0017, validation-path-contract]
used_by: []
supersedes: null
---

# AI-EOS v0.5.2 Cross-Platform Validation

AI-EOS is an Artificial Intelligence Engineering Operating System for AI-assisted software engineering.

This release stabilizes the Validation Engine for cross-platform determinism.

## Baseline

v0.5.1 Validator Hardening.

## What This Release Adds

- path normalization contract;
- deterministic validator policy;
- Python `path_utils.py`;
- cross-platform duplicate allow-list correction;
- reproducibility tests for Windows, POSIX and mixed separators;
- ADR-0017 Cross-Platform Validation Determinism.

## Validation

From the AI-EOS root:

```bash
python runtime/validation/reference/python/ai_eos_validate.py .
python runtime/validation/reference/python/tests/test_negative_fixtures.py
python runtime/validation/reference/python/tests/reproducibility/test_path_normalization.py
```

## Status

v0.5.2 fixes the cross-platform path defect found in v0.5.1.
