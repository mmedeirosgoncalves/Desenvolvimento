"""
Path utilities for AI-EOS reference validators.

All logical validation paths are normalized to POSIX-style separators so that
Windows, Linux and macOS produce the same validation results.
"""

from __future__ import annotations

from pathlib import Path, PurePosixPath
import re


def normalize_path(path: str | Path) -> str:
    """Return a stable POSIX-style representation for a path-like value."""
    raw = str(path).replace("\\", "/")
    raw = re.sub(r"/+", "/", raw)
    if raw.startswith("./"):
        raw = raw[2:]
    return raw.strip("/")


def relative_path(path: str | Path, root: str | Path) -> str:
    """Return a canonical relative path from root to path."""
    p = Path(path)
    r = Path(root)
    try:
        rel = p.relative_to(r)
        return normalize_path(rel)
    except ValueError:
        # Fall back to string normalization for synthetic path tests.
        p_norm = normalize_path(path)
        r_norm = normalize_path(root)
        if p_norm.startswith(r_norm + "/"):
            return p_norm[len(r_norm) + 1:]
        return p_norm


def canonical_path(path: str | Path) -> str:
    """Alias for normalize_path for readability in validators."""
    return normalize_path(path)


def canonical_match(pattern: str, path: str | Path) -> bool:
    """Match a regex against the canonical representation of a path."""
    return re.match(pattern, normalize_path(path)) is not None


def as_posix_path(path: str | Path) -> PurePosixPath:
    """Return a PurePosixPath created from the canonical representation."""
    return PurePosixPath(normalize_path(path))
