---
id: changelog
version: 0.5.2
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [adr-0017]
used_by: []
supersedes: null
---

# Changelog

## v0.5.2 — Cross-Platform Validation

### Added

- ADR-0017 — Cross-Platform Validation Determinism.
- `runtime/validation/PATH_CONTRACT.md`
- `runtime/validation/VALIDATOR_DETERMINISM.md`
- `runtime/validation/reference/python/path_utils.py`
- `runtime/validation/reference/python/tests/reproducibility/test_path_normalization.py`
- `runtime/validation/reference/python/tests/reproducibility/README.md`

### Fixed

- Duplicate allow-list now normalizes paths before matching.
- Windows, POSIX and mixed separators now produce equivalent path matching results.

### Changed

- Reference validator now reports canonical POSIX-style paths.
- Validator documentation now requires canonical path handling.

### Preserved

- All v0.5.1 baseline files.
- All negative fixtures.
- All existing Quality Gates.
