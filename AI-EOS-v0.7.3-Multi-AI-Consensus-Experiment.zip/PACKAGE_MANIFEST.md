---
id: package-manifest
version: 0.7.3
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
release_document: true
depends_on: [adr-0027, adr-0028, adr-0029, adr-0030]
used_by: []
supersedes: null
---

# Package Manifest

## Release

AI-EOS v0.7.3 Multi-AI Consensus Experiment

## Baseline

AI-EOS v0.7.0 Multi-AI Consensus Experiment.

## Entry Point

`AGENTS.md`

## Version Source

`VERSION`

## Markdown Files

291

## YAML Files

5

## Python Files

14

## Top-Level Areas

- adapters/
- agents/
- architecture/
- canon/
- constitution/
- decision-trees/
- docs/
- evaluation/
- experiments/
- governance/
- harness/
- heuristics/
- knowledge/
- labs/
- multi-agent/
- playbooks/
- runtime/
- skills/
- templates/
- vision/

## Added Files

None.

## Removed Files

None.
