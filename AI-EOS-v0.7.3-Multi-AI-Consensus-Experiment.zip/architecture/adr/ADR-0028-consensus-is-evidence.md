---
id: adr-0028
version: 0.7.3
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
release_document: false
depends_on: [adr-0027]
used_by: []
supersedes: null
---

# ADR-0028 — Consensus Is Evidence

## Status

Accepted

## Decision

AI-EOS adopts the principle:

> Consensus is evidence, not truth.

Consensus output must be interpreted as convergence evidence, not proof of correctness.

## Consequences

- no Winner Agent in v0.7.3;
- human review remains required;
- Devil's Advocate review is part of the experiment model.
