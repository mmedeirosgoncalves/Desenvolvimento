---
id: multi-ai-consensus-experiment
version: 0.7.3
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
release_document: false
depends_on: [adr-0027, adr-0028]
used_by: []
supersedes: null
---

# Multi-AI Consensus Experiment

## Purpose

Measure whether independent AI systems produce better engineering outcomes when their solutions are compared through a formal consensus process.

## Non-Goals

v0.7.3 does not:

- execute agents automatically;
- choose a winner automatically;
- merge code automatically;
- replace human review;
- claim consensus is correctness.

## Flow

```text
Experiment Controller
  -> Prompt Builder
  -> Independent Execution Layer
  -> Evidence Collector
  -> Consensus Analyzer
  -> Devil's Advocate
  -> Human Review
```
