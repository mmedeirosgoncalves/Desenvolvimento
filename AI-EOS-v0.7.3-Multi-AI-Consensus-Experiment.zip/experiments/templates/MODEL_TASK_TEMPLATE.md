---
id: model-task-template
version: 0.7.3
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
release_document: false
depends_on: [multi-ai-consensus-experiment]
used_by: []
supersedes: null
---

# Model Task Template

Provide the same scope and context to every AI system.

Required output: summary, assumptions, architecture, risks, tests, evidence, confidence.
