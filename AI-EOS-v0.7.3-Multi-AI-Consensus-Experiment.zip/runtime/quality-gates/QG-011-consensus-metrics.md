---
id: qg-011-consensus-metrics
version: 0.7.3
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
release_document: false
depends_on: [multi-ai-consensus-experiment]
used_by: []
supersedes: null
---

# QG-011 — Consensus Metrics

Confirms consensus, novelty, diversity and evidence metrics are reported.

Automation Level: L1 in v0.7.3.
