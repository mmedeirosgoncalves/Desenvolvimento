---
id: roadmap
version: 0.8.2
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: true
depends_on: []
used_by: []
supersedes: null
---

# Roadmap

## Completed

### v0.8.1 — Devin AI Discovery Adapter

Classified Devin model candidates by programmatic access evidence.

### v0.8.2 — Devin CLI Provider Integration

Adds a fail-closed provider adapter for Devin CLI non-interactive model execution.

## Next

### v0.8.3 — Devin Provider Registry Activation

Wire configured Devin CLI providers into the Multi-AI ProviderRegistry and allow consensus rounds to include only preflight-passing Devin models.

### v0.8.4 — Codegen Isolation Layer

Run codegen after consensus in disposable worktrees with audit trail and rollback.
