---
id: readme
version: 0.8.2
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: true
depends_on: [adr-0036]
used_by: []
supersedes: null
---

# AI-EOS v0.8.2 — Devin CLI Provider Integration

AI-EOS v0.8.2 integrates the Devin CLI programmatic surface as a fail-closed provider adapter.

## Release Objective

Allow AI-EOS to call Devin-selected models through the Devin CLI contract while preserving safety and ProviderContract boundaries.

## Key Design

```text
AI-EOS
  -> ProviderRegistry
  -> DevinCliProviderAdapter
  -> devin --model <MODEL> --prompt-file prompt.json --export transcript.json
  -> ProviderResponse
  -> ConsensusEngine
```

## What This Release Does

- Adds `DevinCliProviderAdapter`.
- Adds Devin CLI preflight.
- Adds QG-018.
- Adds ADR-0036.
- Adds positive and negative tests for CLI provider behavior.
- Documents why MCP is not the preferred path for Devin-contained LLMs.

## What This Release Does Not Do

- It does not automate the Devin UI.
- It does not assume credentials.
- It does not force Devin providers into consensus when preflight fails.
- It does not make LLM outputs byte-deterministic.
