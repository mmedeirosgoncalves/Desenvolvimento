---
id: agents
version: 0.8.2
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: true
depends_on: []
used_by: []
supersedes: null
---

# AGENTS

## Release

AI-EOS v0.8.2 — Devin CLI Provider Integration.

## Required Validation Flow

```bash
python runtime/validation/reference/python/run_tests.py
python runtime/validation/reference/python/ai_eos_validate.py . --output validation-report.json
python -m runtime.devin --config examples/devin/devin_discovery_config.example.json --output reports/devin/devin-discovery-report.json
```

## Devin CLI Preflight

```bash
where devin
devin auth status
devin --model gpt -p "Return exactly: ping"
```

## Agent Rule

Use Devin CLI as provider only after preflight passes. Do not use MCP to consume Devin-contained LLMs unless Devin exposes an MCP server specifically for model invocation.
