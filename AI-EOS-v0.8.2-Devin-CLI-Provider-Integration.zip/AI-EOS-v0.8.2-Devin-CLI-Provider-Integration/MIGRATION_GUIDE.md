---
id: migration-guide
version: 0.8.2
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: true
depends_on: [adr-0036]
used_by: []
supersedes: null
---

# Migration Guide — v0.8.1 to v0.8.2

## Summary

v0.8.2 moves from discovery-only to a real fail-closed Devin CLI provider adapter.

## New Module

`runtime/devin/cli_provider.py`

## New Preflight

```bash
where devin
devin auth status
devin --model gpt -p "Return exactly: ping"
```

## Important

Do not add Devin CLI providers to consensus unless preflight passes.
