---
id: changelog
version: 0.8.2
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: true
depends_on: []
used_by: []
supersedes: null
---

# Changelog

## v0.8.2 — Devin CLI Provider Integration

- Added `runtime/devin/cli_provider.py`.
- Added fail-closed Devin CLI execution adapter.
- Added Devin CLI preflight.
- Added QG-018 Devin CLI Provider.
- Added ADR-0036.
- Added Devin CLI provider config example.
- Added tests for provider success, fail-closed behavior and preflight.
- Preserved v0.8.1 discovery behavior.
