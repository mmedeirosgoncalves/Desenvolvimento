---
id: roadmap
version: 0.6.0.3
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [knowledge-runtime-contract, adr-0023]
used_by: []
supersedes: null
---

# AI-EOS Roadmap

## v0.6.0.3 — Validation Hygiene

- Removed external environment traceback noise from release validation records.
- Aligned release-level version metadata.
- Extended `version-consistency-validator` to report stale release-document versions.
- Added ADR-0025 Validation Hygiene.
- Added runtime integration test for version metadata consistency.

## v0.6.0.2 — Safety Net + Audit Remediation Governance

- Restored fixture-root detection in the reference validator.
- Restored render, duplication and version validators.
- Preserved `allowed_duplicate_group` compatibility.
- Added in-package validation test runner.
- Added ARP governance: ADR-0024, audit remediation policy, template and decision rules.
- RELEASE_VALIDATION now treats failing tests as release failure.

## v0.6.0.1 — Runtime Integration

- Integrate comparator utilities into executable validator path.
- Validate Knowledge Pack YAML artifacts.
- Validate Knowledge Registry.
- Add Specification Coverage Validator.
- Regenerate validation report.

## v0.6.1 — Knowledge Runtime Validator Expansion

- Add richer negative YAML fixtures.
- Add cycle detection for package dependencies.
- Add capability conflict detection.
- Add registry drift detection.

## v0.7 — Knowledge Pack Expansion

- Populate Knowledge Packs beyond Security.
- Add examples, references and decision trees.

## v0.8 — Skill Runtime

- Refactor Skills as application mechanisms.

## v0.9 — Agent Runtime

- Specialist agent orchestration.

## v1.0 — Stable AI-EOS

- Stable platform.
