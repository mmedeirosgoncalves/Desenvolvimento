---
id: package-manifest
version: 0.6.0.3
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [adr-0025, adr-0024, test-gate-policy]
used_by: []
supersedes: null
---

# Package Manifest

## Release

AI-EOS v0.6.0.3 Validation Hygiene

## Baseline

AI-EOS v0.6.0.2 Safety Net + Audit Remediation Governance.

## Entry Point

`AGENTS.md`

## Markdown Files

264

## YAML Files

4

## Python Files

12

## Top-Level Areas

- adapters/
- agents/
- architecture/
- canon/
- constitution/
- decision-trees/
- docs/
- evaluation/
- governance/
- harness/
- heuristics/
- knowledge/
- labs/
- multi-agent/
- playbooks/
- runtime/
- skills/
- templates/
- vision/

## Added Files

- architecture/adr/ADR-0025-validation-hygiene.md
- runtime/validation/reference/python/tests/runtime_integration/test_version_consistency_validator.py

## Removed Files

None.
