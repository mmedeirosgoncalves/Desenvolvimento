from pathlib import Path
import sys, tempfile, importlib.util
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
spec = importlib.util.spec_from_file_location("ai_eos_validate", ROOT / "ai_eos_validate.py")
v = importlib.util.module_from_spec(spec)
spec.loader.exec_module(v)

with tempfile.TemporaryDirectory() as tmp:
    root = Path(tmp)
    (root / "CHANGELOG.md").write_text("""---
id: changelog
version: 0.0.1
status: active
updated: 2026-07-06
depends_on: []
---

# Changelog
""", encoding="utf-8")
    report = v.run(root)
    assert "stale version" in str(report["findings"]).lower(), report
