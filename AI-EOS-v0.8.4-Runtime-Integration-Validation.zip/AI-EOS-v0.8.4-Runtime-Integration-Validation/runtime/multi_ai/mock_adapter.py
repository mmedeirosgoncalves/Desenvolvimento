"""Deterministic mock adapters for the v0.8.0 runtime foundation."""
from __future__ import annotations

from dataclasses import dataclass
from .provider_contract import ProviderRequest, ProviderResponse

@dataclass
class MockProviderAdapter:
    provider_id: str
    response_template: str
    latency_ms: int = 0
    cost: float = 0.0

    def execute(self, request: ProviderRequest) -> ProviderResponse:
        content = self.response_template.format(
            task_id=request.task_id,
            scope=request.scope,
            prompt=request.prompt,
            constraints=", ".join(request.constraints),
        )
        return ProviderResponse(
            provider_id=self.provider_id,
            task_id=request.task_id,
            content=content,
            latency_ms=self.latency_ms,
            cost=self.cost,
            metadata={"adapter": "mock", "runtime_version": "0.8.0"},
        )
