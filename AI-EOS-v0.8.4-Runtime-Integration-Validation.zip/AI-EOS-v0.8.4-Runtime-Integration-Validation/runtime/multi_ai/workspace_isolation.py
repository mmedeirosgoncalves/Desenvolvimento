"""Workspace isolation utilities for multi-agent execution."""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import shutil, subprocess, time

@dataclass(frozen=True)
class WorkspaceLease:
    agent_id: str
    task_id: str
    path: str
    created_at: float
    source: str

def create_agent_workspace(source_root: str, workspace_root: str, agent_id: str, task_id: str) -> WorkspaceLease:
    src = Path(source_root).resolve()
    root = Path(workspace_root).resolve()
    safe_agent = "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in agent_id)
    safe_task = "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in task_id)
    dst = root / safe_task / safe_agent
    if dst.exists():
        shutil.rmtree(dst)
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(src, dst, ignore=shutil.ignore_patterns(".git", "__pycache__", ".pytest_cache", "reports", "node_modules"))
    return WorkspaceLease(agent_id, task_id, str(dst), time.time(), str(src))

def run_read_only_probe(workspace: WorkspaceLease, command: list[str], timeout: int = 60) -> dict:
    proc = subprocess.run(command, cwd=workspace.path, capture_output=True, text=True, timeout=timeout)
    return {"agent_id": workspace.agent_id, "task_id": workspace.task_id, "returncode": proc.returncode, "stdout": proc.stdout, "stderr": proc.stderr}
