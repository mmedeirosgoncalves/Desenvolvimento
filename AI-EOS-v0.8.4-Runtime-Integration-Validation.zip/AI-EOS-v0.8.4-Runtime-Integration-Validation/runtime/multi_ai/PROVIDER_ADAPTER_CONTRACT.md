---
id: provider-adapter-contract
version: 0.8.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: false
depends_on: [multi-ai-runtime-foundation]
used_by: []
supersedes: null
---

# Provider Adapter Contract

A provider adapter converts a vendor-specific or local model call into a normalized `ProviderResponse`.

The contract is vendor-agnostic and does not require external network access.
