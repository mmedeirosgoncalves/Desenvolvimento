"""Multi-AI execution orchestrator.

v0.8.0 intentionally supports deterministic mock adapters only. This provides the
runtime seam for future real-provider adapters without adding network dependency.
"""
from __future__ import annotations

from dataclasses import asdict
from .provider_contract import ProviderRequest, ProviderResponse
from .provider_registry import ProviderRegistry
from .consensus_round import ConsensusRound
from .human_review_gate import HumanReviewGate
from .audit_trail import AuditTrail

class MultiAIOrchestrator:
    def __init__(
        self,
        registry: ProviderRegistry,
        consensus_round: ConsensusRound | None = None,
        human_review_gate: HumanReviewGate | None = None,
    ) -> None:
        self.registry = registry
        self.consensus_round = consensus_round or ConsensusRound()
        self.human_review_gate = human_review_gate or HumanReviewGate()

    def execute(self, request: ProviderRequest, provider_ids: list[str], audit: AuditTrail | None = None) -> dict:
        if not provider_ids:
            raise ValueError("provider_ids must not be empty")
        responses: list[ProviderResponse] = []
        errors = []
        for provider_id in provider_ids:
            try:
                adapter = self.registry.get_adapter(provider_id)
                responses.append(adapter.execute(request))
            except Exception as exc:
                errors.append({"provider_id": provider_id, "error": str(exc)})
        consensus = self.consensus_round.run(request.task_id, responses)
        human_review = self.human_review_gate.evaluate(consensus)
        event = {
            "version": "0.8.0",
            "task_id": request.task_id,
            "provider_ids": provider_ids,
            "responses": [asdict(r) for r in responses],
            "errors": errors,
            "consensus": asdict(consensus),
            "human_review": asdict(human_review),
        }
        if audit is not None:
            event["audit_path"] = str(audit.write_event(request.task_id, event))
        return event
