"""Consensus round wrapper for multi-provider responses."""
from __future__ import annotations

from dataclasses import dataclass
from runtime.consensus.engine import ConsensusEngine, ConsensusInput
from runtime.consensus.provider_interface import ProviderResponse as ConsensusProviderResponse
from .provider_contract import ProviderResponse

@dataclass(frozen=True)
class ConsensusRoundResult:
    task_id: str
    provider_count: int
    shared_claims: list[str]
    unique_claims: dict[str, list[str]]
    conflicts: list[str]
    agreement_rate: float
    requires_human_review: bool
    recommendation: str

class ConsensusRound:
    def __init__(self, review_threshold: float = 0.55) -> None:
        self.review_threshold = float(review_threshold)

    def run(self, task_id: str, responses: list[ProviderResponse]) -> ConsensusRoundResult:
        converted = [
            ConsensusProviderResponse(
                provider_id=r.provider_id,
                task_id=r.task_id,
                content=r.content,
                latency_ms=r.latency_ms,
                input_tokens=r.input_tokens,
                output_tokens=r.output_tokens,
                cost=r.cost,
                metadata=r.metadata,
            )
            for r in responses
            if r.status == "success"
        ]
        result = ConsensusEngine().build(ConsensusInput(task_id=task_id, responses=converted))
        conflicts = list(result.conflicts)
        requires_review = result.agreement_rate < self.review_threshold or bool(conflicts)
        recommendation = "human_review_required" if requires_review else "accept_consensus"
        return ConsensusRoundResult(
            task_id=task_id,
            provider_count=len(converted),
            shared_claims=list(result.shared_claims),
            unique_claims=dict(result.unique_claims),
            conflicts=conflicts,
            agreement_rate=float(result.agreement_rate),
            requires_human_review=requires_review,
            recommendation=recommendation,
        )
