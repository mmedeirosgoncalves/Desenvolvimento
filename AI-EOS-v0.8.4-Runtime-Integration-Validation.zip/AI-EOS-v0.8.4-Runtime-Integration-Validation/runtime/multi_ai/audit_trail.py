"""Audit trail writer for AI-EOS Multi-AI Runtime."""
from __future__ import annotations

from pathlib import Path
from typing import Any
import json
import math
from dataclasses import asdict, is_dataclass

def _strict(value: Any) -> Any:
    if isinstance(value, float):
        if math.isnan(value) or math.isinf(value):
            return None
        return value
    if isinstance(value, dict):
        return {str(k): _strict(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_strict(v) for v in value]
    if is_dataclass(value):
        return _strict(asdict(value))
    return value

class AuditTrail:
    def __init__(self, output_dir: str | Path) -> None:
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def write_event(self, task_id: str, event: dict[str, Any]) -> Path:
        path = self.output_dir / f"{task_id}.multi-ai-audit.json"
        path.write_text(json.dumps(_strict(event), indent=2, sort_keys=True, allow_nan=False), encoding="utf-8")
        return path
