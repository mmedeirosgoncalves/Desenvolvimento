"""Human review gate for high-divergence multi-AI runs."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Literal
from .consensus_round import ConsensusRoundResult

Decision = Literal["accept_consensus", "request_revision", "manual_decision_required"]

@dataclass(frozen=True)
class HumanReviewDecision:
    decision: Decision
    reason: str
    required: bool

class HumanReviewGate:
    def evaluate(self, consensus: ConsensusRoundResult) -> HumanReviewDecision:
        if consensus.requires_human_review:
            return HumanReviewDecision(
                decision="manual_decision_required",
                reason="Low agreement or explicit conflict detected.",
                required=True,
            )
        return HumanReviewDecision(
            decision="accept_consensus",
            reason="Agreement threshold met and no conflict detected.",
            required=False,
        )
