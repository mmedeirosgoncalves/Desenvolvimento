"""CLI for AI-EOS Multi-AI Runtime Foundation."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from .provider_contract import ProviderRequest
from .provider_registry import ProviderRegistry
from .orchestrator import MultiAIOrchestrator
from .audit_trail import AuditTrail

EXIT_OK = 0
EXIT_INVALID_INPUT = 1
EXIT_INTERNAL_ERROR = 3

def _error(code: str, message: str) -> str:
    return json.dumps({"status": "FAIL", "code": code, "message": message}, sort_keys=True, allow_nan=False)

def load_json(path: str | Path) -> dict:
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ValueError(f"invalid JSON: {exc.msg}")
    if not isinstance(data, dict):
        raise ValueError("payload must be a JSON object")
    return data

def run_payload(payload: dict, output: str | Path) -> dict:
    task_id = str(payload.get("task_id", "")).strip()
    if not task_id:
        raise ValueError("task_id is required")
    provider_ids = payload.get("provider_ids")
    if not isinstance(provider_ids, list) or not provider_ids:
        raise ValueError("provider_ids must be a non-empty array")
    registry_config = payload.get("provider_registry")
    if not isinstance(registry_config, dict):
        raise ValueError("provider_registry is required")
    registry = ProviderRegistry.from_config(registry_config)
    request = ProviderRequest(
        task_id=task_id,
        scope=str(payload.get("scope", "")),
        prompt=str(payload.get("prompt", "")),
        constraints=list(payload.get("constraints", [])),
        metadata=dict(payload.get("metadata", {})),
    )
    out = Path(output)
    audit = AuditTrail(out.parent / "audit")
    event = MultiAIOrchestrator(registry).execute(request, [str(x) for x in provider_ids], audit=audit)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(event, indent=2, sort_keys=True, allow_nan=False), encoding="utf-8")
    return event

def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="aieos-multi-ai", description="AI-EOS Multi-AI Runtime Foundation")
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args(argv)
    try:
        event = run_payload(load_json(args.input), args.output)
        print(json.dumps({"status": "PASS", "output": args.output, "human_review_required": event["human_review"]["required"]}, sort_keys=True, allow_nan=False))
        return EXIT_OK
    except ValueError as exc:
        print(_error("INVALID_INPUT", str(exc)))
        return EXIT_INVALID_INPUT
    except Exception as exc:
        print(_error("INTERNAL_ERROR", str(exc)))
        return EXIT_INTERNAL_ERROR

if __name__ == "__main__":
    raise SystemExit(main())
