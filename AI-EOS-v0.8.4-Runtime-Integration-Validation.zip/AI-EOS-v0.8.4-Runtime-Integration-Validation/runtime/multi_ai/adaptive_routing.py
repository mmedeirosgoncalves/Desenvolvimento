"""Adaptive multi-agent routing for AI-EOS."""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Iterable
import json

@dataclass(frozen=True)
class AgentProfile:
    provider_id: str
    model: str
    roles: tuple[str, ...] = ("generalist",)
    strengths: tuple[str, ...] = ()
    cost_tier: str = "unknown"
    permission_level: str = "read_only"
    enabled: bool = True
    metadata: dict[str, Any] = field(default_factory=dict)

@dataclass(frozen=True)
class TaskProfile:
    task_id: str
    task_type: str
    difficulty: str = "medium"
    risk: str = "medium"
    requires_code: bool = False
    requires_external_access: bool = False
    requires_sensitive_review: bool = False
    preferred_roles: tuple[str, ...] = ()

@dataclass(frozen=True)
class RoutingDecision:
    task_id: str
    selected: tuple[AgentProfile, ...]
    required_roles: tuple[str, ...]
    human_review_required: bool
    rationale: tuple[str, ...]
    degraded: bool = False

ROLE_BY_TASK = {
    "architecture": ("architect", "critic", "implementer"),
    "codegen": ("architect", "coder", "critic"),
    "security": ("security", "critic", "architect"),
    "documentation": ("writer", "critic"),
    "research": ("researcher", "critic"),
    "general": ("generalist", "critic"),
}

def load_roster(path: str) -> tuple[AgentProfile, ...]:
    data = json.loads(open(path, encoding="utf-8").read())
    agents = data.get("agents", data if isinstance(data, list) else [])
    return tuple(
        AgentProfile(
            provider_id=a["provider_id"],
            model=a.get("model", a["provider_id"]),
            roles=tuple(a.get("roles", ["generalist"])),
            strengths=tuple(a.get("strengths", [])),
            cost_tier=a.get("cost_tier", "unknown"),
            permission_level=a.get("permission_level", "read_only"),
            enabled=bool(a.get("enabled", True)),
            metadata=a.get("metadata", {}),
        )
        for a in agents
    )

def infer_required_roles(task: TaskProfile) -> tuple[str, ...]:
    roles = list(ROLE_BY_TASK.get(task.task_type, ROLE_BY_TASK["general"]))
    for role in task.preferred_roles:
        if role not in roles:
            roles.append(role)
    if task.requires_sensitive_review and "security" not in roles:
        roles.append("security")
    return tuple(roles)

def _score(agent: AgentProfile, roles: Iterable[str], task: TaskProfile) -> int:
    agent_roles = set(agent.roles)
    required = set(roles)
    score = 10 * len(agent_roles & required)
    score += 2 * len(set(agent.strengths) & {task.task_type, "codegen", "architecture", "security", "research"})
    if task.requires_code and ("coder" in agent_roles or "implementer" in agent_roles):
        score += 5
    if task.risk in ("high", "critical") and "critic" in agent_roles:
        score += 4
    if agent.permission_level not in ("read_only", "normal") and task.risk in ("high", "critical"):
        score -= 5
    return score

def select_agents(roster: Iterable[AgentProfile], task: TaskProfile, max_agents: int | None = None) -> RoutingDecision:
    enabled = [a for a in roster if a.enabled]
    roles = infer_required_roles(task)
    if max_agents is None:
        max_agents = 2 if task.difficulty == "low" and task.risk == "low" else 3
        if task.difficulty in ("high", "critical") or task.risk in ("high", "critical"):
            max_agents = 5
    ranked = sorted(enabled, key=lambda a: _score(a, roles, task), reverse=True)
    selected = []
    covered = set()
    rationale = []
    for role in roles:
        for agent in ranked:
            if agent in selected:
                continue
            if role in agent.roles:
                selected.append(agent)
                covered.add(role)
                rationale.append(f"selected {agent.provider_id} for role {role}")
                break
    for agent in ranked:
        if len(selected) >= max_agents:
            break
        if agent not in selected and _score(agent, roles, task) > 0:
            selected.append(agent)
            rationale.append(f"added {agent.provider_id} by score")
    degraded = bool(set(roles) - covered)
    if degraded:
        rationale.append("not all required roles covered")
    human_review = task.risk in ("high", "critical") or task.requires_sensitive_review or degraded
    return RoutingDecision(task.task_id, tuple(selected[:max_agents]), roles, human_review, tuple(rationale), degraded)
