---
id: provider-registry
version: 0.8.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: false
depends_on: [provider-adapter-contract]
used_by: []
supersedes: null
---

# Provider Registry

The registry stores provider identity, capabilities, limitations and adapter mode.

v0.8.0 supports `mode: mock` only.
