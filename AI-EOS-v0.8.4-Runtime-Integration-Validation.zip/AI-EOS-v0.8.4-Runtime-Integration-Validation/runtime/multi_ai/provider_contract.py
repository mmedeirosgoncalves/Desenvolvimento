"""Provider adapter contract for AI-EOS v0.8.0.

The contract is intentionally vendor-agnostic. Real provider adapters can be added later
without changing the orchestration or consensus logic.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Protocol, Any

@dataclass(frozen=True)
class ProviderRequest:
    task_id: str
    scope: str
    prompt: str
    constraints: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

@dataclass(frozen=True)
class ProviderResponse:
    provider_id: str
    task_id: str
    content: str
    status: str = "success"
    error: str | None = None
    latency_ms: int = 0
    input_tokens: int = 0
    output_tokens: int = 0
    cost: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)

class ProviderError(RuntimeError):
    """Structured provider execution error."""

class ProviderAdapter(Protocol):
    provider_id: str

    def execute(self, request: ProviderRequest) -> ProviderResponse:
        """Execute a request and return a normalized provider response."""
        ...
