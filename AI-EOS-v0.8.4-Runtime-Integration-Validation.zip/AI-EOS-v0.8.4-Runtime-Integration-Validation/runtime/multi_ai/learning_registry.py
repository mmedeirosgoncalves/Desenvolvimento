"""Advisory task outcome registry."""
from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
import json
from collections import defaultdict

@dataclass(frozen=True)
class ProviderOutcome:
    task_type: str
    provider_id: str
    score: float
    accepted: bool
    timestamp: float
    notes: str = ""

def append_outcome(path: str, outcome: ProviderOutcome) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("a", encoding="utf-8") as f:
        f.write(json.dumps(asdict(outcome), ensure_ascii=False, allow_nan=False) + "\n")

def summarize_outcomes(path: str) -> dict:
    p = Path(path)
    if not p.exists():
        return {}
    grouped = defaultdict(list)
    for line in p.read_text(encoding="utf-8").splitlines():
        if line.strip():
            item = json.loads(line)
            grouped[(item["task_type"], item["provider_id"])].append(item)
    out = {}
    for (task_type, provider_id), rows in grouped.items():
        accepted = sum(1 for r in rows if r.get("accepted"))
        avg = sum(float(r.get("score", 0)) for r in rows) / len(rows)
        out.setdefault(task_type, {})[provider_id] = {"runs": len(rows), "accepted": accepted, "accept_rate": accepted / len(rows), "avg_score": avg}
    return out
