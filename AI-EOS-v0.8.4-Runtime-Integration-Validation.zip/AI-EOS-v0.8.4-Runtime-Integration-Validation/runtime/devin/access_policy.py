"""Access classification for Devin Desktop model coupling."""
from __future__ import annotations

from enum import Enum

class AccessLevel(str, Enum):
    PROGRAMMATIC = "programmatic"
    CONFIG_ONLY = "config_only"
    UI_ONLY = "ui_only"
    UNAVAILABLE = "unavailable"

def classify_access(evidence: dict) -> AccessLevel:
    if evidence.get("cli_available") or evidence.get("api_available") or evidence.get("mcp_available") or evidence.get("local_endpoint_available"):
        return AccessLevel.PROGRAMMATIC
    if evidence.get("configured_model"):
        return AccessLevel.CONFIG_ONLY
    if evidence.get("ui_visible"):
        return AccessLevel.UI_ONLY
    return AccessLevel.UNAVAILABLE
