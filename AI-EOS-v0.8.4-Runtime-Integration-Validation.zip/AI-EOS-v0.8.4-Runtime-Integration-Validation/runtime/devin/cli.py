"""CLI for Devin AI discovery."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from .discovery import DevinDiscovery

def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="aieos-devin-discovery")
    parser.add_argument("--config", required=False)
    parser.add_argument("--output", required=True)
    args = parser.parse_args(argv)
    result = DevinDiscovery(args.config).discover().to_dict()
    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False), encoding="utf-8")
    print(json.dumps({"status": result["status"], "recommendation": result["recommendation"], "output": args.output}, sort_keys=True, allow_nan=False))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
