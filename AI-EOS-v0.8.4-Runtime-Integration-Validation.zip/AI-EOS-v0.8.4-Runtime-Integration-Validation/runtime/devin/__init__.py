"""AI-EOS Devin discovery adapter v0.8.1."""
from .discovery import DevinDiscovery, DevinModelCandidate, DiscoveryResult
from .adapter import DevinProviderAdapter, DevinAccessUnavailable
from .access_policy import AccessLevel, classify_access

__all__ = [
    "DevinDiscovery",
    "DevinModelCandidate",
    "DiscoveryResult",
    "DevinProviderAdapter",
    "DevinAccessUnavailable",
    "AccessLevel",
    "classify_access",
]

from .cli_provider import (
    DevinCliProviderAdapter,
    DevinCliPreflight,
    DevinCliUnavailable,
    DevinCliAuthError,
    DevinCliExecutionError,
    preflight_devin_cli,
)
