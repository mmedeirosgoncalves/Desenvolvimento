---
id: devin-provider-adapter-contract
version: 0.8.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: false
depends_on: [provider-adapter-contract, adr-0035]
used_by: []
supersedes: null
---

# Devin Provider Adapter Contract

A Devin adapter may implement the AI-EOS ProviderContract only if it can call Devin through a stable programmatic channel.

The adapter must return normalized `ProviderResponse` objects and must fail closed when access is not verified.
