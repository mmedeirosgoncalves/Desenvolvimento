---
id: devin-cli-provider
version: 0.8.2
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: false
depends_on: [adr-0036]
used_by: []
supersedes: null
---

# Devin CLI Provider

## Purpose

Expose Devin CLI as a fail-closed AI-EOS provider when programmatic access is available.

## Preflight

```bash
where devin
devin auth status
devin --model gpt -p "Return exactly: ping"
```

## Provider Command

```bash
devin --model <MODEL> --prompt-file prompt.json --export transcript.json --permission-mode normal
```

## Safety

- UI-only availability is not executable access.
- MCP is not the preferred path for Devin internal models.
- Provider execution should not mutate the repository during consensus rounds.
- Codegen must run after consensus, preferably in isolated worktrees.
