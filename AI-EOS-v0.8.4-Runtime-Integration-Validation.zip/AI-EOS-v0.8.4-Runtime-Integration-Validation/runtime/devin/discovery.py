"""Discovery utilities for Devin Desktop AI model availability.

v0.8.1 does not automate the Devin UI and does not assume hidden APIs. It creates
a repeatable inventory of possible Devin models and classifies each one by
evidence level.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any
import json
import os
import shutil
from .access_policy import AccessLevel, classify_access

KNOWN_DEVIN_MODEL_ALIASES = [
    "gpt-5.5-high-thinking",
    "gpt-5.5",
    "claude-opus-4.8-high",
    "claude-opus-4.8",
    "gemini",
    "devin-local",
]

@dataclass(frozen=True)
class DevinModelCandidate:
    provider_id: str
    display_name: str
    model: str
    access_level: str
    evidence: dict[str, Any]
    usable_by_aieos: bool
    reason: str

@dataclass(frozen=True)
class DiscoveryResult:
    status: str
    recommendation: str
    cli_available: bool
    api_available: bool
    mcp_available: bool
    local_endpoint_available: bool
    candidates: list[DevinModelCandidate]
    notes: list[str]

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["candidates"] = [asdict(c) for c in self.candidates]
        return data

class DevinDiscovery:
    def __init__(self, config_path: str | Path | None = None) -> None:
        self.config_path = Path(config_path) if config_path else None

    def _detect_cli(self) -> bool:
        return bool(shutil.which("devin"))

    def _detect_api_env(self) -> bool:
        return bool(os.environ.get("DEVIN_API_KEY") or os.environ.get("DEVIN_BASE_URL"))

    def _detect_mcp_env(self) -> bool:
        return bool(os.environ.get("DEVIN_MCP_URL") or os.environ.get("MCP_DEVIN_URL"))

    def _detect_local_endpoint_env(self) -> bool:
        return bool(os.environ.get("DEVIN_LOCAL_ENDPOINT"))

    def _load_config(self) -> dict[str, Any]:
        if not self.config_path or not self.config_path.exists():
            return {}
        return json.loads(self.config_path.read_text(encoding="utf-8"))

    def discover(self) -> DiscoveryResult:
        cfg = self._load_config()
        cli_available = self._detect_cli() or bool(cfg.get("devin_cli"))
        api_available = self._detect_api_env() or bool(cfg.get("devin_api"))
        mcp_available = self._detect_mcp_env() or bool(cfg.get("devin_mcp"))
        local_endpoint_available = self._detect_local_endpoint_env() or bool(cfg.get("devin_local_endpoint"))

        configured = cfg.get("models", [])
        names = configured if configured else [
            {"model": name, "display_name": name, "ui_visible": False}
            for name in KNOWN_DEVIN_MODEL_ALIASES
        ]

        candidates: list[DevinModelCandidate] = []
        for item in names:
            model = str(item.get("model") or item.get("provider_id") or item.get("display_name") or "").strip()
            display = str(item.get("display_name") or model)
            evidence = {
                "cli_available": cli_available,
                "api_available": api_available,
                "mcp_available": mcp_available,
                "local_endpoint_available": local_endpoint_available,
                "configured_model": bool(configured),
                "ui_visible": bool(item.get("ui_visible", False)),
                "source": "config" if configured else "known_alias_catalog",
            }
            level = classify_access(evidence)
            usable = level == AccessLevel.PROGRAMMATIC
            reason = {
                AccessLevel.PROGRAMMATIC: "Programmatic Devin access evidence found.",
                AccessLevel.CONFIG_ONLY: "Model is configured but no programmatic Devin access was detected.",
                AccessLevel.UI_ONLY: "Model is visible in UI but no programmatic access was detected.",
                AccessLevel.UNAVAILABLE: "Model alias is known but availability is not verified.",
            }[level]
            candidates.append(DevinModelCandidate(
                provider_id=f"devin:{model}",
                display_name=display,
                model=model,
                access_level=level.value,
                evidence=evidence,
                usable_by_aieos=usable,
                reason=reason,
            ))

        if any(c.usable_by_aieos for c in candidates):
            status = "PASS"
            recommendation = "PROGRAMMATIC_ACCESS_AVAILABLE"
        elif configured:
            status = "WARNING"
            recommendation = "CONFIGURED_BUT_NOT_EXECUTABLE"
        else:
            status = "WARNING"
            recommendation = "DISCOVERY_ONLY_NO_PROGRAMMATIC_ACCESS"

        return DiscoveryResult(
            status=status,
            recommendation=recommendation,
            cli_available=cli_available,
            api_available=api_available,
            mcp_available=mcp_available,
            local_endpoint_available=local_endpoint_available,
            candidates=candidates,
            notes=[
                "UI visibility is not sufficient for AI-EOS provider coupling.",
                "v0.8.1 does not automate Devin Desktop UI.",
                "Adapters are enabled only when CLI/API/MCP/local endpoint evidence exists.",
            ],
        )
