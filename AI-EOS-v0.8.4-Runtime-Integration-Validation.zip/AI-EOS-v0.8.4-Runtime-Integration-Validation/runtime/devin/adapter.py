"""Conservative Devin provider adapter."""
from __future__ import annotations

from dataclasses import dataclass
import json
import subprocess
from runtime.multi_ai.provider_contract import ProviderRequest, ProviderResponse, ProviderError

class DevinAccessUnavailable(ProviderError):
    pass

@dataclass
class DevinProviderAdapter:
    provider_id: str
    model: str
    access_method: str = "none"
    command: list[str] | None = None

    def execute(self, request: ProviderRequest) -> ProviderResponse:
        if self.access_method == "cli" and self.command:
            payload = {
                "task_id": request.task_id,
                "model": self.model,
                "scope": request.scope,
                "prompt": request.prompt,
                "constraints": request.constraints,
                "metadata": request.metadata,
            }
            proc = subprocess.run(
                self.command,
                input=json.dumps(payload, ensure_ascii=False),
                capture_output=True,
                text=True,
                timeout=120,
            )
            if proc.returncode != 0:
                raise ProviderError(proc.stderr or proc.stdout or f"Devin CLI failed with exit {proc.returncode}")
            return ProviderResponse(
                provider_id=self.provider_id,
                task_id=request.task_id,
                content=proc.stdout.strip(),
                status="success",
                metadata={"adapter": "devin", "model": self.model, "access_method": self.access_method},
            )
        raise DevinAccessUnavailable("No verified programmatic Devin access is configured. UI-only models are not executable providers.")
