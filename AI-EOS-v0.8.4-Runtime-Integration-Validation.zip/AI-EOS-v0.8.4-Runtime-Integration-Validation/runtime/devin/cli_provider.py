"""Devin CLI provider integration.

Treats Devin CLI as a programmatic ProviderContract execution surface.
The adapter is deliberately fail-closed: if the CLI or authentication is absent,
the provider is not usable and must not enter a consensus round.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Any
import json
import shutil
import subprocess
import time

from runtime.multi_ai.provider_contract import ProviderRequest, ProviderResponse, ProviderError

class DevinCliUnavailable(ProviderError):
    pass

class DevinCliAuthError(ProviderError):
    pass

class DevinCliExecutionError(ProviderError):
    pass

@dataclass(frozen=True)
class DevinCliPreflight:
    status: str
    devin_path: str | None
    auth_ok: bool
    ping_ok: bool
    model: str
    details: dict[str, Any] = field(default_factory=dict)

    @property
    def usable(self) -> bool:
        return self.status == "PASS"

def _run(cmd: list[str], *, timeout: int = 60, input_text: str | None = None) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, input=input_text, capture_output=True, text=True, timeout=timeout)

def devin_cli_path() -> str | None:
    return shutil.which("devin")

def preflight_devin_cli(model: str = "gpt", *, run_ping: bool = False, timeout: int = 60) -> DevinCliPreflight:
    path = devin_cli_path()
    if not path:
        return DevinCliPreflight(
            status="FAIL",
            devin_path=None,
            auth_ok=False,
            ping_ok=False,
            model=model,
            details={"reason": "devin CLI not found in PATH"},
        )

    auth = _run([path, "auth", "status"], timeout=timeout)
    if auth.returncode != 0:
        return DevinCliPreflight(
            status="FAIL",
            devin_path=path,
            auth_ok=False,
            ping_ok=False,
            model=model,
            details={"reason": "devin auth status failed", "stdout": auth.stdout, "stderr": auth.stderr, "returncode": auth.returncode},
        )

    if run_ping:
        ping = _run([path, "--model", model, "-p", "Return exactly: ping"], timeout=timeout)
        ping_ok = ping.returncode == 0 and "ping" in (ping.stdout or "").lower()
        if not ping_ok:
            return DevinCliPreflight(
                status="FAIL",
                devin_path=path,
                auth_ok=True,
                ping_ok=False,
                model=model,
                details={"reason": "devin model ping failed", "stdout": ping.stdout, "stderr": ping.stderr, "returncode": ping.returncode},
            )
    else:
        ping_ok = False

    return DevinCliPreflight(
        status="PASS",
        devin_path=path,
        auth_ok=True,
        ping_ok=ping_ok,
        model=model,
        details={"ping_checked": run_ping},
    )

@dataclass
class DevinCliProviderAdapter:
    provider_id: str
    model: str
    timeout_seconds: int = 600
    permission_mode: str = "normal"
    require_auth_preflight: bool = True
    extra_args: list[str] = field(default_factory=list)

    def _build_prompt(self, request: ProviderRequest) -> str:
        payload = {
            "task_id": request.task_id,
            "scope": request.scope,
            "prompt": request.prompt,
            "constraints": request.constraints,
            "metadata": request.metadata,
            "instruction": "Return a textual answer only. Do not edit files unless explicitly requested by the task scope.",
        }
        return json.dumps(payload, ensure_ascii=False, indent=2, allow_nan=False)

    def execute(self, request: ProviderRequest) -> ProviderResponse:
        path = devin_cli_path()
        if not path:
            raise DevinCliUnavailable("devin CLI not found in PATH")

        if self.require_auth_preflight:
            pf = preflight_devin_cli(self.model, run_ping=False, timeout=60)
            if not pf.usable:
                raise DevinCliAuthError(json.dumps(pf.details, ensure_ascii=False, allow_nan=False))

        started = time.perf_counter()
        with TemporaryDirectory(prefix="aieos-devin-cli-") as tmp:
            tmp_path = Path(tmp)
            prompt_file = tmp_path / "prompt.json"
            export_file = tmp_path / "transcript.json"
            prompt_file.write_text(self._build_prompt(request), encoding="utf-8")

            cmd = [
                path,
                "--model", self.model,
                "--prompt-file", str(prompt_file),
                "--export", str(export_file),
            ]
            if self.permission_mode:
                cmd.extend(["--permission-mode", self.permission_mode])
            cmd.extend(self.extra_args)

            proc = _run(cmd, timeout=self.timeout_seconds)
            elapsed_ms = int((time.perf_counter() - started) * 1000)

            if proc.returncode != 0:
                raise DevinCliExecutionError(proc.stderr or proc.stdout or f"devin CLI failed with exit {proc.returncode}")

            transcript = None
            if export_file.exists():
                try:
                    transcript = json.loads(export_file.read_text(encoding="utf-8"))
                except json.JSONDecodeError:
                    transcript = {"raw_export": export_file.read_text(encoding="utf-8")}

            return ProviderResponse(
                provider_id=self.provider_id,
                task_id=request.task_id,
                content=(proc.stdout or "").strip(),
                status="success",
                metadata={
                    "adapter": "devin-cli",
                    "model": self.model,
                    "latency_ms": elapsed_ms,
                    "permission_mode": self.permission_mode,
                    "export_available": export_file.exists(),
                    "transcript": transcript,
                },
            )
