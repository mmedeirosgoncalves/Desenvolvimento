---
id: devin-ai-discovery
version: 0.8.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: false
depends_on: [adr-0035]
used_by: []
supersedes: null
---

# Devin AI Discovery Adapter

v0.8.1 adds a conservative discovery layer for identifying which AI models available in Devin Desktop can be coupled to the AI-EOS `ProviderContract`.

## Policy

A model is usable by AI-EOS only when at least one programmatic access method is verified:

- CLI;
- API;
- MCP endpoint;
- local endpoint.

UI visibility alone is insufficient.

## Command

```bash
python -m runtime.devin --config examples/devin/devin_discovery_config.example.json --output reports/devin/devin-discovery-report.json
```

## Scope

This release does not automate the Devin UI and does not implement real provider calls. It classifies available evidence and prevents premature coupling.
