---
id: devin-access-policy
version: 0.8.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: false
depends_on: [adr-0035]
used_by: []
supersedes: null
---

# Devin Access Policy

## Rule

Do not treat a Devin Desktop UI model as an executable provider unless programmatic access is confirmed.

## Evidence Levels

- `programmatic`: CLI/API/MCP/local endpoint discovered.
- `config_only`: user supplied model names, but no verified execution path.
- `ui_only`: visible in the interface, but not callable by AI-EOS.
- `unavailable`: known alias only; no evidence.

## Rationale

UI visibility alone is insufficient. This avoids fragile UI automation and prevents overclaiming integration status.
