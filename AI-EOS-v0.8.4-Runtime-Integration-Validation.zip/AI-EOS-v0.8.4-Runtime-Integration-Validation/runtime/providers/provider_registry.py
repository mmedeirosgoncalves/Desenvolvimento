from __future__ import annotations
from dataclasses import dataclass
from typing import Any
from .provider_contract import ProviderRequest, ProviderResponse
from .devin_cli_provider import DevinCliProvider

class MockProvider:
    mode = "mock"
    def __init__(self, provider_id: str = "mock", response: str = "mock response"):
        self.provider_id = provider_id
        self.response = response
    def availability(self) -> dict:
        return {"provider_id": self.provider_id, "state": "AVAILABLE", "mode": self.mode}
    def execute(self, request: ProviderRequest) -> ProviderResponse:
        return ProviderResponse(self.provider_id, self.response, "OK", {"task_id": request.task_id, "mock": True})

class LocalProvider(MockProvider):
    mode = "local"

class APIProvider(MockProvider):
    mode = "api"

@dataclass
class ProviderRegistry:
    providers: dict[str, Any]
    @classmethod
    def from_config(cls, config: dict | None = None) -> "ProviderRegistry":
        config = config or {}
        entries = config.get("providers", [{"provider_id": "mock", "mode": "mock"}])
        providers = {}
        for item in entries:
            mode = item.get("mode", "mock")
            pid = item.get("provider_id", mode)
            if mode == "mock":
                providers[pid] = MockProvider(pid, item.get("response", "mock response"))
            elif mode == "devin-cli":
                providers[pid] = DevinCliProvider(model=item.get("model", "gpt"), command=item.get("command", "devin"))
                providers[pid].provider_id = pid
            elif mode == "local":
                providers[pid] = LocalProvider(pid, item.get("response", "local response"))
            elif mode == "api":
                providers[pid] = APIProvider(pid, item.get("response", "api response"))
            else:
                providers[pid] = MockProvider(pid, f"degraded unsupported provider mode: {mode}")
                providers[pid].mode = mode
        return cls(providers)
    def availability(self) -> dict:
        states = {}
        for pid, provider in self.providers.items():
            try:
                states[pid] = provider.availability()
            except Exception as exc:
                states[pid] = {"provider_id": pid, "state": "DEGRADED", "reason": str(exc)}
        return states
    def active(self) -> list[Any]:
        return [p for p in self.providers.values() if p.availability().get("state") == "AVAILABLE"]
