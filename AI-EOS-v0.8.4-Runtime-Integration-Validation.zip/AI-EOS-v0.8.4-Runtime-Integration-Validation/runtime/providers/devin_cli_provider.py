from __future__ import annotations
import shutil, subprocess, tempfile
from pathlib import Path
from .provider_contract import ProviderRequest, ProviderResponse

class DevinCLIUnavailable(RuntimeError):
    pass

class DevinCliProvider:
    provider_id = "devin-cli"
    mode = "devin-cli"
    def __init__(self, model: str = "gpt", timeout_seconds: int = 600, permission_mode: str = "normal", command: str = "devin"):
        self.model = model
        self.timeout_seconds = timeout_seconds
        self.permission_mode = permission_mode
        self.command = command
    def availability(self) -> dict:
        exe = shutil.which(self.command)
        if not exe:
            return {"provider_id": self.provider_id, "state": "UNAVAILABLE", "reason": f"{self.command} not found on PATH"}
        return {"provider_id": self.provider_id, "state": "AVAILABLE", "command": exe, "model": self.model}
    def execute(self, request: ProviderRequest) -> ProviderResponse:
        available = self.availability()
        if available.get("state") != "AVAILABLE":
            raise DevinCLIUnavailable(available.get("reason", "Devin CLI unavailable"))
        with tempfile.TemporaryDirectory(prefix="ai_eos_devin_") as td:
            prompt_file = Path(td) / "prompt.txt"
            export_file = Path(td) / "transcript.json"
            prompt_file.write_text(request.prompt, encoding="utf-8")
            cmd = [self.command, "--model", request.model or self.model, "-p", str(prompt_file), "--export", str(export_file), "--permission-mode", self.permission_mode]
            proc = subprocess.run(cmd, capture_output=True, text=True, timeout=self.timeout_seconds)
            if proc.returncode != 0:
                raise DevinCLIUnavailable(proc.stderr or f"Devin CLI exited {proc.returncode}")
            return ProviderResponse(self.provider_id, proc.stdout.strip(), "OK", {"transcript_path": str(export_file), "availability": available})
