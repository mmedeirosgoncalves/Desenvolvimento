from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Protocol

@dataclass(frozen=True)
class ProviderRequest:
    task_id: str
    prompt: str
    model: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

@dataclass(frozen=True)
class ProviderResponse:
    provider_id: str
    content: str
    status: str = "OK"
    metadata: dict[str, Any] = field(default_factory=dict)

class ProviderContract(Protocol):
    provider_id: str
    mode: str
    def availability(self) -> dict[str, Any]: ...
    def execute(self, request: ProviderRequest) -> ProviderResponse: ...
