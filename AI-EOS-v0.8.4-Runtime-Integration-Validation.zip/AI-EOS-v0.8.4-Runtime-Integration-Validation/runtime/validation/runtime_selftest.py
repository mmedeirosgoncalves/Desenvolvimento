from __future__ import annotations
from pathlib import Path
import json, tempfile, sys
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from runtime.orchestrator.orchestrator import run_task
from runtime.graph.runtime_callgraph import write_callgraph
from runtime.coverage.runtime_coverage import write_coverage
def main() -> int:
    reports = ROOT / "reports"; reports.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory() as td:
        result = run_task({"task_id":"SELFTEST-001","task_type":"codegen","difficulty":"medium","risk":"medium","requires_code":True,"prompt":"Return OK."}, {"providers":[{"provider_id":"mock-a","mode":"mock","response":"OK"}], "workspace_root": td, "learning_registry": str(reports/"learning-registry.jsonl")}, source_root=str(ROOT))
    callgraph = write_callgraph(str(reports/"runtime-callgraph.json"))
    coverage = write_coverage(str(reports/"runtime-coverage.json"), str(ROOT))
    out = {"runtime_result": result.__dict__, "callgraph": callgraph, "coverage": coverage}
    (reports/"runtime-selftest.json").write_text(json.dumps(out, indent=2, sort_keys=True, allow_nan=False), encoding="utf-8")
    ok = result.status == "PASS" and coverage["status"] == "PASS" and not callgraph["orphan_nodes"]
    print("PASS" if ok else "FAIL")
    return 0 if ok else 1
if __name__ == "__main__":
    raise SystemExit(main())
