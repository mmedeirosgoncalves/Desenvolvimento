from pathlib import Path
import sys, tempfile, json
ROOT = Path(__file__).resolve().parents[6]
sys.path.insert(0, str(ROOT))
from runtime.multi_ai.learning_registry import ProviderOutcome, append_outcome, summarize_outcomes
with tempfile.TemporaryDirectory() as d:
    p = str(Path(d, "outcomes.jsonl"))
    append_outcome(p, ProviderOutcome(task_type="codegen", provider_id="devin:gpt", score=0.8, accepted=True, timestamp=1.0))
    append_outcome(p, ProviderOutcome(task_type="codegen", provider_id="devin:gpt", score=0.4, accepted=False, timestamp=2.0))
    summary = summarize_outcomes(p)
    assert summary["codegen"]["devin:gpt"]["runs"] == 2
    assert summary["codegen"]["devin:gpt"]["accepted"] == 1
    for line in Path(p).read_text(encoding="utf-8").splitlines():
        json.dumps(json.loads(line), allow_nan=False)
