from pathlib import Path
import sys
from unittest.mock import patch, Mock
ROOT = Path(__file__).resolve().parents[6]
sys.path.insert(0, str(ROOT))

from runtime.devin.cli_provider import DevinCliProviderAdapter, DevinCliUnavailable, preflight_devin_cli
from runtime.multi_ai.provider_contract import ProviderRequest

with patch("runtime.devin.cli_provider.shutil.which", return_value=None):
    pf = preflight_devin_cli("gpt")
    assert pf.status == "FAIL"
    assert pf.usable is False

adapter = DevinCliProviderAdapter(provider_id="devin:gpt", model="gpt")
try:
    with patch("runtime.devin.cli_provider.shutil.which", return_value=None):
        adapter.execute(ProviderRequest(task_id="T", scope="S", prompt="P"))
    raise AssertionError("adapter should fail closed without devin CLI")
except DevinCliUnavailable:
    pass

def fake_run(cmd, timeout=60, input_text=None):
    m = Mock()
    if len(cmd) >= 3 and cmd[1:3] == ["auth", "status"]:
        m.returncode = 0
        m.stdout = "authenticated"
        m.stderr = ""
        return m
    m.returncode = 0
    m.stdout = "provider response"
    m.stderr = ""
    return m

with patch("runtime.devin.cli_provider.shutil.which", return_value="/usr/bin/devin"):
    with patch("runtime.devin.cli_provider._run", side_effect=fake_run):
        response = adapter.execute(ProviderRequest(task_id="T", scope="S", prompt="P"))
        assert response.provider_id == "devin:gpt"
        assert response.status == "success"
        assert "provider response" in response.content
        assert response.metadata["adapter"] == "devin-cli"
