from pathlib import Path
import sys, json, tempfile
ROOT = Path(__file__).resolve().parents[6]
sys.path.insert(0, str(ROOT))

from runtime.devin.discovery import DevinDiscovery

with tempfile.TemporaryDirectory() as tmp:
    root = Path(tmp)
    cfg = {
        "devin_cli": True,
        "models": [
            {"model": "gpt-5.5-high-thinking", "display_name": "GPT-5.5 High Thinking", "ui_visible": True},
        ],
    }
    cfg_path = root / "cfg.json"
    cfg_path.write_text(json.dumps(cfg), encoding="utf-8")
    result = DevinDiscovery(cfg_path).discover()
    assert result.status == "PASS"
    assert result.candidates[0].access_level == "programmatic"
    assert result.candidates[0].usable_by_aieos is True
