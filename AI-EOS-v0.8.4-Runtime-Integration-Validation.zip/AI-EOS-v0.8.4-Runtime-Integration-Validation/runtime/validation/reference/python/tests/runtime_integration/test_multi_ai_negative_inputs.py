from pathlib import Path
import sys, tempfile, json, io, contextlib
ROOT = Path(__file__).resolve().parents[6]
sys.path.insert(0, str(ROOT))
from runtime.multi_ai.cli import main

with tempfile.TemporaryDirectory() as tmp:
    root = Path(tmp)
    bad = root / "bad.json"
    bad.write_text(json.dumps({"task_id": "T-BAD"}), encoding="utf-8")
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        rc = main(["--input", str(bad), "--output", str(root / "out.json")])
    assert rc == 1
    assert "INVALID_INPUT" in buf.getvalue()

    malformed = root / "malformed.json"
    malformed.write_text("{", encoding="utf-8")
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        rc = main(["--input", str(malformed), "--output", str(root / "out.json")])
    assert rc == 1
    assert "INVALID_INPUT" in buf.getvalue()
