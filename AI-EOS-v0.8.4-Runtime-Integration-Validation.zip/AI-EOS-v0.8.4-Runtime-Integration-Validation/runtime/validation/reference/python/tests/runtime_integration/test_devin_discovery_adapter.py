from pathlib import Path
import sys, json, tempfile
ROOT = Path(__file__).resolve().parents[6]
sys.path.insert(0, str(ROOT))

from runtime.devin.discovery import DevinDiscovery
from runtime.devin.access_policy import AccessLevel, classify_access
from runtime.devin.adapter import DevinProviderAdapter, DevinAccessUnavailable
from runtime.multi_ai.provider_contract import ProviderRequest
from runtime.devin.cli import main

assert classify_access({"ui_visible": True}) == AccessLevel.UI_ONLY
assert classify_access({"configured_model": True}) == AccessLevel.CONFIG_ONLY
assert classify_access({"cli_available": True}) == AccessLevel.PROGRAMMATIC

with tempfile.TemporaryDirectory() as tmp:
    root = Path(tmp)
    cfg = {
        "devin_cli": False,
        "devin_api": False,
        "devin_mcp": False,
        "devin_local_endpoint": False,
        "models": [
            {"model": "gpt-5.5-high-thinking", "display_name": "GPT-5.5 High Thinking", "ui_visible": True},
            {"model": "claude-opus-4.8-high", "display_name": "Claude Opus 4.8 High", "ui_visible": True},
        ],
    }
    cfg_path = root / "cfg.json"
    out = root / "report.json"
    cfg_path.write_text(json.dumps(cfg), encoding="utf-8")
    result = DevinDiscovery(cfg_path).discover()
    assert result.status == "WARNING"
    assert all(not c.usable_by_aieos for c in result.candidates)
    assert {c.access_level for c in result.candidates} == {"config_only"}
    rc = main(["--config", str(cfg_path), "--output", str(out)])
    assert rc == 0
    loaded = json.loads(out.read_text(encoding="utf-8"))
    assert loaded["recommendation"] == "CONFIGURED_BUT_NOT_EXECUTABLE"

adapter = DevinProviderAdapter(provider_id="devin:gpt-5.5", model="gpt-5.5")
try:
    adapter.execute(ProviderRequest(task_id="T", scope="S", prompt="P"))
    raise AssertionError("adapter should fail closed without programmatic access")
except DevinAccessUnavailable:
    pass
