from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[6]
sys.path.insert(0, str(ROOT))
from runtime.multi_ai.adaptive_routing import AgentProfile, TaskProfile, select_agents
roster = [
    AgentProfile("a", "m1", roles=("architect", "writer")),
    AgentProfile("b", "m2", roles=("critic",)),
    AgentProfile("c", "m3", roles=("coder",)),
    AgentProfile("d", "m4", roles=("security",)),
]
low = TaskProfile(task_id="T1", task_type="documentation", difficulty="low", risk="low")
d1 = select_agents(roster, low)
assert len(d1.selected) <= 2
assert d1.human_review_required is False
high = TaskProfile(task_id="T2", task_type="codegen", difficulty="high", risk="critical", requires_code=True, requires_sensitive_review=True)
d2 = select_agents(roster, high)
assert len(d2.selected) >= 3
assert d2.human_review_required is True
assert "architect" in d2.required_roles and "coder" in d2.required_roles
