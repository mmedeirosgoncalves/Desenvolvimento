from pathlib import Path
import sys, tempfile
ROOT = Path(__file__).resolve().parents[6]
sys.path.insert(0, str(ROOT))
from runtime.multi_ai.workspace_isolation import create_agent_workspace
with tempfile.TemporaryDirectory() as src, tempfile.TemporaryDirectory() as dst:
    Path(src, "file.txt").write_text("x", encoding="utf-8")
    w1 = create_agent_workspace(src, dst, "agent-a", "task-1")
    w2 = create_agent_workspace(src, dst, "agent-b", "task-1")
    assert w1.path != w2.path
    assert Path(w1.path, "file.txt").exists()
    assert Path(w2.path, "file.txt").exists()
