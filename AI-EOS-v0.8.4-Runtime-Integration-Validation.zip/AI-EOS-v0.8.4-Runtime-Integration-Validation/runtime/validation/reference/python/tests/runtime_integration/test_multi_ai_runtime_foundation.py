from pathlib import Path
import sys, tempfile, json
ROOT = Path(__file__).resolve().parents[6]
sys.path.insert(0, str(ROOT))

from runtime.multi_ai import (
    ProviderRequest,
    ProviderRegistry,
    ProviderProfile,
    MockProviderAdapter,
    MultiAIOrchestrator,
    AuditTrail,
)
from runtime.multi_ai.cli import main

registry = ProviderRegistry()
registry.register(
    ProviderProfile("mock-a", "Mock A", ["architecture"], ["mock only"]),
    MockProviderAdapter("mock-a", "Use adapter contract. Add audit trail."),
)
registry.register(
    ProviderProfile("mock-b", "Mock B", ["review"], ["mock only"]),
    MockProviderAdapter("mock-b", "Use adapter contract. Add human review gate."),
)

request = ProviderRequest(task_id="T-MULTI", scope="test", prompt="Create runtime.")
with tempfile.TemporaryDirectory() as tmp:
    audit = AuditTrail(tmp)
    event = MultiAIOrchestrator(registry).execute(request, ["mock-a", "mock-b"], audit=audit)
    assert event["version"] == "0.8.0"
    assert len(event["responses"]) == 2
    assert "consensus" in event
    assert "human_review" in event
    assert Path(event["audit_path"]).exists()

    payload = {
        "task_id": "T-CLI-MULTI",
        "scope": "runtime",
        "prompt": "Run mocks.",
        "provider_ids": ["mock-a", "mock-b"],
        "provider_registry": {
            "providers": [
                {"provider_id": "mock-a", "mode": "mock", "response_template": "Use adapter contract."},
                {"provider_id": "mock-b", "mode": "mock", "response_template": "Use adapter contract."},
            ]
        },
    }
    inp = Path(tmp) / "input.json"
    out = Path(tmp) / "out.json"
    inp.write_text(json.dumps(payload), encoding="utf-8")
    rc = main(["--input", str(inp), "--output", str(out)])
    assert rc == 0
    assert out.exists()
    text = out.read_text(encoding="utf-8")
    assert "Infinity" not in text
    assert json.loads(text)["version"] == "0.8.0"
