from pathlib import Path
import sys
from unittest.mock import patch, Mock
ROOT = Path(__file__).resolve().parents[6]
sys.path.insert(0, str(ROOT))

from runtime.devin.cli_provider import preflight_devin_cli

def ok_run(cmd, timeout=60, input_text=None):
    m = Mock()
    m.returncode = 0
    m.stdout = "ping authenticated"
    m.stderr = ""
    return m

with patch("runtime.devin.cli_provider.shutil.which", return_value="/usr/bin/devin"):
    with patch("runtime.devin.cli_provider._run", side_effect=ok_run):
        pf = preflight_devin_cli("gpt", run_ping=True)
        assert pf.status == "PASS"
        assert pf.auth_ok is True
        assert pf.ping_ok is True
