from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import Any
import tempfile, time
from runtime.multi_ai.adaptive_routing import AgentProfile, TaskProfile, select_agents
from runtime.multi_ai.workspace_isolation import create_agent_workspace
from runtime.multi_ai.learning_registry import ProviderOutcome, append_outcome
from runtime.providers.provider_contract import ProviderRequest
from runtime.providers.provider_registry import ProviderRegistry
from runtime.providers.devin_cli_provider import DevinCliProvider  # integration visibility

@dataclass
class RuntimeResult:
    task_id: str
    status: str
    selected_providers: list[str]
    responses: list[dict[str, Any]]
    human_review_required: bool
    degraded: bool
    audit: dict[str, Any]

def _agent_from_provider(provider: Any) -> AgentProfile:
    roles = ("generalist", "critic")
    if getattr(provider, "mode", "") == "devin-cli":
        roles = ("coder", "architect", "critic")
    return AgentProfile(provider_id=provider.provider_id, model=getattr(provider, "mode", "unknown"), roles=roles)

def run_task(task: dict[str, Any], config: dict[str, Any] | None = None, source_root: str | None = None) -> RuntimeResult:
    config = config or {}
    registry = ProviderRegistry.from_config(config)
    agents = [_agent_from_provider(p) for p in registry.active()]
    task_profile = TaskProfile(task.get("task_id", "TASK-UNSPECIFIED"), task.get("task_type", "general"), task.get("difficulty", "medium"), task.get("risk", "medium"), bool(task.get("requires_code", False)), False, ())
    routing = select_agents(agents, task_profile)
    workspace_root = config.get("workspace_root") or tempfile.mkdtemp(prefix="ai_eos_runtime_")
    source_root = source_root or str(Path.cwd())
    responses = []
    for agent in routing.selected:
        provider = registry.providers.get(agent.provider_id)
        lease = create_agent_workspace(source_root, workspace_root, agent.provider_id, task_profile.task_id)
        try:
            resp = provider.execute(ProviderRequest(task_profile.task_id, task.get("prompt", ""), model=agent.model))
            responses.append({"provider_id": agent.provider_id, "status": resp.status, "content": resp.content, "workspace": lease.path})
            if config.get("learning_registry"):
                append_outcome(config["learning_registry"], ProviderOutcome(task_profile.task_type, agent.provider_id, 1.0, True, time.time()))
        except Exception as exc:
            responses.append({"provider_id": agent.provider_id, "status": "DEGRADED", "error": str(exc), "workspace": lease.path})
    status = "PASS" if any(x.get("status") == "OK" for x in responses) else "FAIL"
    return RuntimeResult(task_profile.task_id, status, [a.provider_id for a in routing.selected], responses, routing.human_review_required, routing.degraded, {"routing": {"required_roles": routing.required_roles, "rationale": routing.rationale}, "availability": registry.availability()})
