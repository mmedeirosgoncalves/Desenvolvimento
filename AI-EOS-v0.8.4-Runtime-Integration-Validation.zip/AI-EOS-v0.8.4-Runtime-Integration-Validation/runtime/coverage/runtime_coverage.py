from __future__ import annotations
import ast, json
from pathlib import Path
RUNTIME_MODULES = {
    "runtime.multi_ai.adaptive_routing": "AdaptiveRouting",
    "runtime.multi_ai.workspace_isolation": "WorkspaceIsolation",
    "runtime.multi_ai.learning_registry": "LearningRegistry",
    "runtime.providers.provider_registry": "ProviderRegistry",
    "runtime.providers.devin_cli_provider": "DevinCliProvider",
    "runtime.orchestrator.orchestrator": "RuntimeOrchestrator",
}
def _imports(path: Path) -> set[str]:
    try: tree = ast.parse(path.read_text(encoding="utf-8"))
    except SyntaxError: return set()
    out = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            out.update(a.name for a in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module:
            out.add(node.module)
    return out
def analyze(root: str = ".") -> dict:
    base = Path(root)
    py_files = [p for p in base.rglob("*.py") if "__pycache__" not in p.parts]
    imported = set()
    for p in py_files: imported.update(_imports(p))
    integrated, orphan = [], []
    for mod, label in RUNTIME_MODULES.items():
        suffix = mod.split(".")[-1]
        is_integrated = (
            mod in imported
            or suffix in imported
            or any(x.startswith(mod + ".") for x in imported)
            or any(x.endswith("." + suffix) for x in imported)
        )
        (integrated if is_integrated else orphan).append(label)
    coverage = len(integrated) / len(RUNTIME_MODULES)
    return {"discovered_modules": sorted(RUNTIME_MODULES.values()), "integrated_modules": sorted(integrated), "orphan_modules": sorted(orphan), "dead_modules": [], "runtime_coverage": coverage, "coverage_percent": round(coverage*100, 2), "threshold_percent": 95.0, "status": "PASS" if coverage >= .95 and not orphan else "FAIL"}
def write_coverage(path: str, root: str = ".") -> dict:
    data = analyze(root)
    p = Path(path); p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, indent=2, sort_keys=True, allow_nan=False), encoding="utf-8")
    return data
if __name__ == "__main__":
    import sys
    write_coverage(sys.argv[1] if len(sys.argv)>1 else "reports/runtime-coverage.json")
