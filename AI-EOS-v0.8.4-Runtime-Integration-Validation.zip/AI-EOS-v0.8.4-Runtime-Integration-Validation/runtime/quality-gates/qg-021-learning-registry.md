---
id: qg-021
version: 0.8.3
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: false
depends_on: [adr-0037]
used_by: []
supersedes: null
---

# QG-021 — Learning Registry

## Criterion

Provider outcome history may guide routing, but must not permanently exclude new providers.

## Automation Level

L2.
