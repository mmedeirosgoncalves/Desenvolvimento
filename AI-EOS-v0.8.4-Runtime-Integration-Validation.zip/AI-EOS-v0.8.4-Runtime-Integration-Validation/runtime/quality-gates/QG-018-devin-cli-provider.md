---
id: qg-018
version: 0.8.2
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: false
depends_on: [devin-cli-provider, adr-0036]
used_by: []
supersedes: null
---

# QG-018 — Devin CLI Provider

## Criterion

Devin CLI may be used as an executable provider only when preflight passes.

## Blocking Rules

- Fail if adapter does not fail closed when `devin` is unavailable.
- Fail if provider execution bypasses ProviderContract.
- Fail if documentation recommends MCP as the route for Devin internal models.
- Fail if command construction omits prompt-file or structured export support.

## Automation Level

L2 Automated/Blocking.
