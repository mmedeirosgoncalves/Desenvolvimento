---
id: qg-015-consensus-execution-entrypoint
version: 0.8.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: true
depends_on: [adr-0032]
used_by: []
supersedes: null
---

# QG-015 Consensus Execution Entry Point

## Requirement

A consensus release is not operational unless it has a callable entry point outside the test suite.

## Validation

- `python -m runtime.consensus consensus` must produce a JSON report.
- `python -m runtime.consensus benchmark` must produce benchmark reports.
- Both commands must run without network access.

