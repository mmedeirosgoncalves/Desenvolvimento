---
id: qg-017
version: 0.8.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: false
depends_on: [devin-ai-discovery]
used_by: []
supersedes: null
---

# QG-017 — Devin AI Discovery

## Criterion

AI-EOS must classify Devin model candidates by verified access evidence and must not expose UI-only models as executable providers.

## Automation Level

L2 Automated/Blocking.

## Validators

- devin-discovery-validator
- devin-access-policy-validator
