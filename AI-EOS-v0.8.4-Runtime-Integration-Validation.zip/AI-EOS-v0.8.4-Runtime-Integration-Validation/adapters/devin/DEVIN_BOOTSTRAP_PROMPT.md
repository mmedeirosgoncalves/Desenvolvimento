---
id: devin-bootstrap
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [agents]
used_by: []
supersedes: null
---

# Devin Bootstrap Prompt

Read `.ai/AI-EOS/AGENTS.md` first.

Treat the folder containing `AGENTS.md` as AI-EOS root.

For every task:

1. classify task
2. load relevant Knowledge Packs
3. load relevant Skills and Playbooks
4. consult `runtime/routing/MULTI_AGENT_TRIGGER_POLICY.md`
5. apply relevant Quality Gates
6. report:
   - assumptions
   - trade-offs
   - risks
   - validation
   - quality gate results

Do not treat placeholder skills as mature expertise.
