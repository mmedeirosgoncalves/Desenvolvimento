---
id: migration-guide
version: 0.8.4
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: true
depends_on: [adr-0038, adr-0039, adr-0040]
used_by: []
supersedes: null
---

# Migration Guide — v0.8.3 to v0.8.4

Provider config now supports `mock`, `api`, `local`, and `devin-cli` modes.
