---
id: readme
version: 0.8.4
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: true
depends_on: [adr-0037, adr-0038, adr-0039, adr-0040]
used_by: []
supersedes: null
---

# AI-EOS v0.8.4 — Runtime Integration & Validation

Codename: Runtime Convergence.

This release wires adaptive routing, workspace isolation, provider registry, provider execution, consensus boundary, learning registry, human review and audit trail into an executable runtime path.
