---
id: getting-started
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [agents]
used_by: []
supersedes: null
---

# Getting Started

## Install

Place AI-EOS in:

```text
.ai/AI-EOS/
```

## Bootstrap

Ask the agent:

```text
Read `.ai/AI-EOS/AGENTS.md` and follow AI-EOS as your engineering operating system.
```

## For Each Task

The agent should:

1. read the entry point
2. classify the task
3. identify relevant Knowledge Packs
4. select Skills and Playbooks
5. consult trigger policy
6. execute
7. apply quality gates
8. produce a report
