---
id: agents
version: 0.8.4
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: true
depends_on: []
used_by: []
supersedes: null
---

# AGENTS

Run `python runtime/validation/runtime_selftest.py` before release.
