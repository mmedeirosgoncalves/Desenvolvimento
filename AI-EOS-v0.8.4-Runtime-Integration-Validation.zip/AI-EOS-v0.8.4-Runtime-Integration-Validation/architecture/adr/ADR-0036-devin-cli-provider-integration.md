---
id: adr-0036
version: 0.8.2
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: false
depends_on: [adr-0035]
used_by: []
supersedes: null
---

# ADR-0036 — Devin CLI Provider Integration

## Status

Accepted.

## Context

The Devin Desktop UI exposes model choices, but the correct integration point is not the UI and not MCP for Devin's internal models. The programmatic interface is Devin CLI non-interactive execution:

```bash
devin --model <MODEL> -p "<prompt>"
devin --model <MODEL> --prompt-file prompt.txt --export out.json
```

## Decision

AI-EOS treats Devin CLI as a provider execution surface only when:

- `devin` is available in PATH;
- `devin auth status` succeeds;
- optional model ping succeeds;
- execution happens through ProviderContract;
- the adapter fails closed otherwise.

MCP is not the default route for consuming Devin-contained LLMs.

## Risks

- Devin CLI execution may be agentic rather than pure completion.
- Providers may mutate files if permission policy is too broad.
- Outputs are not byte-deterministic.
- Cost and latency scale with model count.

## Mitigations

- Use `--permission-mode normal`.
- Prefer disposable worktrees for codegen.
- Use prompt-file execution and export transcripts.
- Log stdout, stderr, transcript path, latency and model.
- Do not add a provider to consensus if preflight fails.
