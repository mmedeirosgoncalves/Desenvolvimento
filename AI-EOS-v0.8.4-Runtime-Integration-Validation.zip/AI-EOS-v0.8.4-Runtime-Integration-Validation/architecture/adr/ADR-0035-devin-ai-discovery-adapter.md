---
id: adr-0035
version: 0.8.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: false
depends_on: [adr-0033]
used_by: []
supersedes: null
---

# ADR-0035 — Devin AI Discovery Adapter

## Status

Accepted.

## Context

The user wants AI-EOS to use the AI models available inside Devin Desktop. Screenshots show multiple selectable models, but UI availability does not prove programmatic access.

## Decision

Create a discovery adapter that classifies Devin model candidates by access evidence:

- `programmatic`;
- `config_only`;
- `ui_only`;
- `unavailable`.

Only `programmatic` candidates may be exposed as executable AI-EOS providers.

## Consequences

Positive:

- Prevents false claims that a UI-visible model is integrated.
- Keeps ProviderContract independent from Devin.
- Enables a future real adapter if Devin exposes CLI/API/MCP/local endpoints.

Negative:

- v0.8.1 may report no executable Devin models even when models are visible in the UI.
- Real execution remains blocked until programmatic access evidence is available.
