---
id: adr-0034
version: 0.8.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: false
depends_on: [adr-0033]
used_by: []
supersedes: null
---

# ADR-0034 — Human Review Gate

## Status

Accepted.

## Decision

If a consensus round has low agreement or explicit conflicts, the runtime must mark the result as requiring human review.

## Rationale

The goal of multi-AI consensus is not blind majority voting. The system must preserve uncertainty and ask for a human decision when automated consensus is weak.
