---
id: adr-0039
version: 0.8.4
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: false
depends_on: [adr-0037]
used_by: []
supersedes: null
---

# ADR-0039 — Provider Lifecycle

Providers follow: DISCOVERED -> REGISTERED -> AVAILABLE -> ACTIVE -> DEGRADED -> DISABLED. Unsupported providers fail closed.
