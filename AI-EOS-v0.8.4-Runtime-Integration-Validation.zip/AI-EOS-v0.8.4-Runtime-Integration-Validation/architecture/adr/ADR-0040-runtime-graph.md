---
id: adr-0040
version: 0.8.4
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: false
depends_on: [adr-0037]
used_by: []
supersedes: null
---

# ADR-0040 — Runtime Graph

The runtime call graph is generated and used to detect orphan modules, dead paths and undocumented execution changes.
