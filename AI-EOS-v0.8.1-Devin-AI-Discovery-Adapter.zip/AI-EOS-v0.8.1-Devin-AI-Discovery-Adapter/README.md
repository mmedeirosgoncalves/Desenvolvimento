---
id: readme
version: 0.8.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: true
depends_on: [adr-0035]
used_by: []
supersedes: null
---

# AI-EOS v0.8.1 — Devin AI Discovery Adapter

AI-EOS v0.8.1 adds a conservative discovery layer to determine which AI models visible or configured in Devin Desktop can be safely coupled to the AI-EOS ProviderContract.

## Release Objective

Classify Devin model candidates without overclaiming integration.

## Key Rule

A Devin model is executable by AI-EOS only when programmatic access is verified through CLI, API, MCP or a local endpoint. UI-only availability is not enough.

## Commands

```bash
python -m runtime.devin --config examples/devin/devin_discovery_config.example.json --output reports/devin/devin-discovery-report.json
python runtime/validation/reference/python/run_tests.py
python runtime/validation/reference/python/ai_eos_validate.py . --output validation-report.json
```

## Scope

This release does not automate the Devin Desktop UI and does not call real AI providers.
