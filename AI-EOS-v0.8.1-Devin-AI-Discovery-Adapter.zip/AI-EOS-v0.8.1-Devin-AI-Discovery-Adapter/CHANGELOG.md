---
id: changelog
version: 0.8.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: true
depends_on: []
used_by: []
supersedes: null
---

# Changelog

## v0.8.1 — Devin AI Discovery Adapter

- Added Devin discovery module.
- Added conservative access classification.
- Added Devin adapter that fails closed without programmatic access.
- Added QG-017 Devin AI Discovery.
- Added ADR-0035.
- Added Devin discovery CLI.
- Added positive and negative discovery tests.
- Preserved v0.8.0 Multi-AI Runtime Foundation baseline.
