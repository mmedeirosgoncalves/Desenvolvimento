"""Provider registry for AI-EOS v0.8.0."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any
from .provider_contract import ProviderAdapter
from .mock_adapter import MockProviderAdapter

@dataclass(frozen=True)
class ProviderProfile:
    provider_id: str
    display_name: str
    capabilities: list[str]
    limitations: list[str] = field(default_factory=list)
    mode: str = "mock"
    metadata: dict[str, Any] = field(default_factory=dict)

class ProviderRegistry:
    def __init__(self) -> None:
        self._profiles: dict[str, ProviderProfile] = {}
        self._adapters: dict[str, ProviderAdapter] = {}

    def register(self, profile: ProviderProfile, adapter: ProviderAdapter) -> None:
        if profile.provider_id in self._profiles:
            raise ValueError(f"duplicate provider_id: {profile.provider_id}")
        if getattr(adapter, "provider_id", None) != profile.provider_id:
            raise ValueError("adapter provider_id must match profile provider_id")
        self._profiles[profile.provider_id] = profile
        self._adapters[profile.provider_id] = adapter

    def get_adapter(self, provider_id: str) -> ProviderAdapter:
        if provider_id not in self._adapters:
            raise KeyError(f"provider not registered: {provider_id}")
        return self._adapters[provider_id]

    def get_profile(self, provider_id: str) -> ProviderProfile:
        if provider_id not in self._profiles:
            raise KeyError(f"provider not registered: {provider_id}")
        return self._profiles[provider_id]

    def list_profiles(self) -> list[ProviderProfile]:
        return [self._profiles[k] for k in sorted(self._profiles)]

    @classmethod
    def from_config(cls, config: dict) -> "ProviderRegistry":
        registry = cls()
        for item in config.get("providers", []):
            provider_id = item["provider_id"]
            profile = ProviderProfile(
                provider_id=provider_id,
                display_name=item.get("display_name", provider_id),
                capabilities=list(item.get("capabilities", [])),
                limitations=list(item.get("limitations", [])),
                mode=item.get("mode", "mock"),
                metadata=dict(item.get("metadata", {})),
            )
            if profile.mode != "mock":
                raise ValueError(f"v0.8.0 supports mock adapters only; got mode={profile.mode}")
            adapter = MockProviderAdapter(
                provider_id=provider_id,
                response_template=item.get("response_template", "Provider {task_id}: {prompt}"),
                latency_ms=int(item.get("latency_ms", 0) or 0),
                cost=float(item.get("cost", 0.0) or 0.0),
            )
            registry.register(profile, adapter)
        return registry
