---
id: agents
version: 0.8.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: true
depends_on: []
used_by: []
supersedes: null
---

# AGENTS

## Release

AI-EOS v0.8.1 — Devin AI Discovery Adapter.

## Required Validation Flow

```bash
python runtime/validation/reference/python/run_tests.py
python runtime/validation/reference/python/ai_eos_validate.py . --output validation-report.json
python -m runtime.multi_ai --input examples/multi_ai/sample_multi_ai_execution.json --output reports/multi-ai/sample-multi-ai-run.json
python -m runtime.devin --config examples/devin/devin_discovery_config.example.json --output reports/devin/devin-discovery-report.json
```

## Agent Rule

Do not claim that a Devin Desktop model is integrated unless programmatic access is verified. UI visibility is discovery evidence only.
