---
id: migration-guide
version: 0.8.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: true
depends_on: [adr-0035]
used_by: []
supersedes: null
---

# Migration Guide — v0.8.0 to v0.8.1

## Summary

v0.8.1 adds Devin model discovery. It does not change the v0.8.0 Multi-AI Runtime API.

## New Command

```bash
python -m runtime.devin --config examples/devin/devin_discovery_config.example.json --output reports/devin/devin-discovery-report.json
```

## Interpretation

- `programmatic`: can be coupled as provider.
- `config_only`: user configured model names but no verified execution path.
- `ui_only`: visible in Devin Desktop, not executable by AI-EOS.
- `unavailable`: no evidence.
