---
id: roadmap
version: 0.8.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: true
depends_on: []
used_by: []
supersedes: null
---

# Roadmap

## Completed

### v0.8.0 — Multi-AI Runtime Foundation

Introduced provider contract, registry, orchestrator, consensus round, human review gate and audit trail.

### v0.8.1 — Devin AI Discovery Adapter

Adds conservative discovery for Devin Desktop model candidates and classifies access by evidence level.

## Next

### v0.8.2 — Devin Programmatic Adapter Pilot

Implement a real Devin adapter only if CLI/API/MCP/local endpoint evidence is available.

If no programmatic Devin access exists, the next step is a native provider adapter such as OpenAI, Anthropic, Gemini, OpenRouter or Ollama.
