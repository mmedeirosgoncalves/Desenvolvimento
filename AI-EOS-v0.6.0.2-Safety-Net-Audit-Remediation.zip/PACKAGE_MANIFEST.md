---
id: package-manifest
version: 0.6.0.2
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [adr-0024, audit-remediation-policy, test-gate-policy]
used_by: []
supersedes: null
---

# Package Manifest

## Release

AI-EOS v0.6.0.2 Safety Net + Audit Remediation Governance

## Baseline

AI-EOS v0.6.0.1 Runtime Integration.

## Entry Point

`AGENTS.md`

## Markdown Files

263

## YAML Files

4

## Python Files

11

## Top-Level Areas

- adapters/
- agents/
- architecture/
- canon/
- constitution/
- decision-trees/
- docs/
- evaluation/
- governance/
- harness/
- heuristics/
- knowledge/
- labs/
- multi-agent/
- playbooks/
- runtime/
- skills/
- templates/
- vision/

## Added Files

- architecture/adr/ADR-0024-test-safety-net-and-audit-remediation.md
- evaluation/AUDIT_REMEDIATION_DECISION_RULES.md
- evaluation/AUDIT_REMEDIATION_PROPOSAL_TEMPLATE.md
- governance/AUDIT_REMEDIATION_POLICY.md
- runtime/validation/TEST_GATE_POLICY.md
- runtime/validation/reference/python/run_tests.py
- runtime/validation/reference/python/tests/runtime_integration/test_allowed_duplicate_group_api.py

## Removed Files

None.
