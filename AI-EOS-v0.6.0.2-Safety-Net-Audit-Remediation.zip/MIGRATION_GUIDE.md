---
id: migration-guide
version: 0.3.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [adr-0008, adr-0009]
used_by: []
supersedes: null
---

# Migration Guide — v0.2 / v0.3 Vision to v0.3.1 Evolution Framework

## Recommended Source

Use v0.3.1 as the new complete baseline.

## What Changed

v0.3.1 merges:

- v0.2 operational baseline
- v0.3 Vision architecture
- Epic 0 Evolution Framework

## What Was Preserved

v0.3.1 preserves operational assets from v0.2, including:

- Skills
- Playbooks
- Knowledge Packs
- Runtime routing
- Quality Gates
- Heuristics
- Decision Trees
- Templates
- Harness materials
- Multi-Agent protocols

## What Was Added

- Vision documents
- Target Architecture
- Canon strategy
- Evaluation models
- Labs policy
- Evolution policies
- Baseline policy
- Regression policy
- Review loop
- ADR-0008
- ADR-0009

## Manual Migration

Replace the old `.ai/AI-EOS/` folder with the contents of this release.

Confirm that `AGENTS.md` exists directly under:

```text
.ai/AI-EOS/AGENTS.md
```

Then instruct Devin:

```text
Read .ai/AI-EOS/AGENTS.md and follow AI-EOS as the engineering operating system for this project.
```
