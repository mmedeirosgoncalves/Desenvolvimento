---
id: qg-009-dependency-integrity
version: 0.3.2
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [regression-policy, baseline-policy]
used_by: [release-validation]
supersedes: null
---

# QG-009 — Dependency Integrity

## Purpose

Validate that AI-EOS artifact metadata references valid dependencies and does not create broken graph relationships.

## Checks

- [ ] Every artifact with front matter has a unique `id`.
- [ ] Every `depends_on` reference resolves to an existing artifact id.
- [ ] Every `supersedes` value resolves to an existing artifact id or is explicitly `null`.
- [ ] No duplicate ids exist.
- [ ] Bootstrap references in `AGENTS.md` point to existing files.
- [ ] Package manifest file counts match the actual package inventory.
- [ ] Removed files from previous baseline are documented.

## Result Format

```text
Gate: Dependency Integrity
Status: PASS | FAIL | NOT_APPLICABLE | NOT_VERIFIED
Evidence:
Residual Risk:
```

## Automation Level

L2 — Automated / Blocking.

Validated by the reference Python validator.
