---
id: qg-005-observability
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: []
used_by: []
supersedes: null
---

# QG-005-OBSERVABILITY — Observability

## Checks

- [ ] Logs considered.
- [ ] Metrics considered.
- [ ] Failure diagnosis possible.

## Result Format

```text
Gate: Observability
Status: PASS | FAIL | NOT_APPLICABLE | NOT_VERIFIED
Evidence:
Residual Risk:
```
