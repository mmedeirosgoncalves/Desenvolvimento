---
id: qg-004-documentation
version: 0.4.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [canon-document-policy, qg-009-dependency-integrity]
used_by: [release-validation]
supersedes: null
---

# QG-004 — Documentation

## Purpose

Validate that documentation is usable, consistent, traceable and not misleading.

## Checks

- [ ] Documentation updated when behavior changes.
- [ ] ADR updated when architecture changes.
- [ ] Specification updated when relevant.
- [ ] Markdown does not contain obvious rendering defects.
- [ ] Markdown does not contain literal `\n` sequences where real line breaks are expected.
- [ ] Files are not duplicated generic templates without justification.
- [ ] Canon-wide rules are not copied into multiple domain files.
- [ ] Links and referenced paths are valid where they are intended to resolve.
- [ ] Required front matter exists.
- [ ] Every front matter block includes an `id`.
- [ ] `depends_on` references resolve when provided.
- [ ] `supersedes` is either `null` or resolves to a known artifact.
- [ ] Documentation status and maturity are not overstated.

## Result Format

```text
Gate: Documentation
Status: PASS | FAIL | NOT_APPLICABLE | NOT_VERIFIED
Evidence:
Residual Risk:
```

## Automation Level

L1 — Semi-Automated.

Validators collect evidence, but final interpretation remains reviewer-mediated.
