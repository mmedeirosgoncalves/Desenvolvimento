---
id: quality-gates
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: []
used_by: []
supersedes: null
---

# Quality Gates

Each task must state which gates were applied.

## Status Values

- PASS
- FAIL
- NOT_APPLICABLE
- NOT_VERIFIED

## Gates

- QG-001 Architecture
- QG-002 Security
- QG-003 Tests
- QG-004 Documentation
- QG-005 Observability
- QG-006 Data Integrity
- QG-007 Legacy Compatibility
- QG-008 Deployment / Rollback
- QG-009 Dependency Integrity
