---
id: validator-model
version: 0.5.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [adr-0014]
used_by: []
supersedes: null
---

# Validator Model

## Definition

A Validator is an executable or specified check that collects evidence for one or more Quality Gates.

## Validator Responsibilities

A Validator should define:

- id
- name
- purpose
- automation level
- input files
- checks
- output schema
- quality gates supported
- failure conditions
- known limitations

## Validator Output

```json
{
  "validator_id": "validator-id",
  "status": "PASS",
  "findings": [],
  "evidence": {},
  "gates": ["qg-009-dependency-integrity"]
}
```

## Rule

Validators collect evidence.

Quality Gates interpret evidence.
