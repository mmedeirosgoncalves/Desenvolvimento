"""Canonical path utilities for AI-EOS validators."""
from __future__ import annotations
from pathlib import Path

def normalize_path(value: str | Path) -> str:
    raw = str(value).replace("\\", "/").strip()
    while "//" in raw:
        raw = raw.replace("//", "/")
    raw = raw.lstrip("./").strip("/")
    return raw

def relative_path(path: str | Path, root: str | Path) -> str:
    return normalize_path(Path(path).resolve().relative_to(Path(root).resolve()))
