---
id: test-gate-policy
version: 0.6.0.2
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [adr-0024]
used_by: []
supersedes: null
---

# Test Gate Policy

## Purpose

Prevent silent regression of the validation safety net.

## Required Suites

For validation releases, run:

- `runtime/validation/reference/python/run_tests.py`
- `runtime/validation/reference/python/ai_eos_validate.py <package>`

## Rule

If any in-package test fails, RELEASE_VALIDATION must fail.

## Fixture Rule

A fixture root must be scanned as a normal validation root. It must not be excluded merely because its path includes `tests/fixtures`.

## Compatibility Rule

Validator APIs referenced by existing tests must be preserved or formally migrated.
