---
id: yaml-validation-spec
version: 0.6.0.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [knowledge-pack-spec, knowledge-registry]
used_by: []
supersedes: null
---

# YAML Validation

## Purpose

Validate production YAML artifacts used by Knowledge Runtime.

## Covered

- `knowledge/packs/*/package.yaml`
- `runtime/registry/knowledge_registry.yaml`

## Checks

- required package metadata;
- package ids;
- package lifecycle status;
- maturity;
- registry path resolution;
- registry id/path consistency;
- required dependencies.
