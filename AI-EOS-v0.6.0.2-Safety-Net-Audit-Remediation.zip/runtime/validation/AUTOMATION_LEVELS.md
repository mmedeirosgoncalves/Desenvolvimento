---
id: validation-automation-levels
version: 0.5.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [adr-0015]
used_by: [validator-registry]
supersedes: null
---

# Validation Automation Levels

## L0 — Manual

Human or agent judgment required.

Use for architecture, product judgment and high-context decisions.

## L1 — Semi-Automated

Automated evidence collection with human/agent interpretation.

Use for documentation quality, duplication, maturity and cross-reference quality.

## L2 — Automated / Blocking

Automated pass/fail with release-blocking authority.

Use only for objective checks with low ambiguity.

## Initial Gate Classification

| Quality Gate | Level | Reason |
|---|---|---|
| QG-009 Dependency Integrity | L2 | Objective graph and metadata checks |
| QG-004 Documentation | L1 | Objective evidence plus judgment |
| QG-001 Architecture | L0/L1 | Requires architectural interpretation |
