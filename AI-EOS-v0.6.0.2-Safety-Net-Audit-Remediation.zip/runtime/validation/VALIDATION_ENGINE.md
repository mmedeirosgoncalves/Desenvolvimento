---
id: validation-engine
version: 0.5.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [adr-0013, validator-model]
used_by: [agents-entry-point]
supersedes: null
---

# Validation Engine

## Purpose

The Validation Engine executes validators, aggregates evidence and maps results to AI-EOS Quality Gates.

## Architectural Position

```text
Quality Gates
  define criteria

Validators
  collect evidence

Validation Engine
  orchestrates validators and produces reports
```

## Non-Goals

The Validation Engine does not replace architectural judgment.

It does not decide all engineering questions.

It automates objective checks and produces structured evidence for subjective checks.

## Execution Pipeline

```text
Load
  -> Discover
  -> Validate
  -> Aggregate
  -> Score
  -> Generate Report
  -> Quality Gates
  -> Release Decision
```

## Reference Implementation

AI-EOS includes a Python reference validator at:

```text
runtime/validation/reference/python/ai_eos_validate.py
```

This implementation validates the AI-EOS repository itself.

## v0.5.1 Hardening

The reference implementation now includes hardened checks for near-duplicate content, literal newline occurrences, manifest top-level areas, metadata consistency and negative fixtures.

## v0.5.2 Cross-Platform Validation

The reference validator now uses canonical POSIX-style paths internally through `path_utils.py`.

All path matching, allow-lists and reports should use normalized paths.
