---
id: readme
version: 0.6.1.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
release_document: true
review_date: 2026-10-06
depends_on: [knowledge-pack-spec, knowledge-runtime-contract]
used_by: []
supersedes: null
---

# AI-EOS v0.6.0 Knowledge Pack Foundation

AI-EOS is an Artificial Intelligence Engineering Operating System for AI-assisted software engineering.

This release introduces Knowledge Packs as the official modular unit of distributable operational knowledge.

## Baseline

v0.5.2 Cross-Platform Validation.

## Part A — Infrastructure Maintenance

- Maintenance Queue introduced.
- Manifest normalization hardening incorporated.
- Shared comparison contract added.
- Shared comparator utilities added.

## Part B — Knowledge Runtime Foundation

Added:

- Knowledge Pack Specification;
- Knowledge Lifecycle;
- Knowledge Boundaries;
- Knowledge Registry;
- Capability Model;
- Knowledge Dependency Graph;
- Context Model;
- Context Builder;
- Runtime Contracts;
- Knowledge Validators;
- ADR-0018 through ADR-0022.

## Status

v0.6.0 establishes the foundation for Knowledge Pack expansion and runtime consumption.
