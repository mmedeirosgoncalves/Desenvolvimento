---
id: package-manifest
version: 0.6.1.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
release_document: true
depends_on: [adr-0026, release-document-policy, adr-0025]
used_by: []
supersedes: null
---

# Package Manifest

## Release

AI-EOS v0.6.1.0 Validation Governance

## Baseline

AI-EOS v0.6.0.3 Validation Hygiene.

## Entry Point

`AGENTS.md`

## Version Source

`VERSION`

## Markdown Files

266

## YAML Files

4

## Python Files

13

## Top-Level Areas

- adapters/
- agents/
- architecture/
- canon/
- constitution/
- decision-trees/
- docs/
- evaluation/
- governance/
- harness/
- heuristics/
- knowledge/
- labs/
- multi-agent/
- playbooks/
- runtime/
- skills/
- templates/
- vision/

## Added Files

- VERSION
- architecture/adr/ADR-0026-release-document-classification.md
- governance/RELEASE_DOCUMENT_POLICY.md
- runtime/validation/reference/python/tests/runtime_integration/test_release_document_policy.py

## Removed Files

None.
