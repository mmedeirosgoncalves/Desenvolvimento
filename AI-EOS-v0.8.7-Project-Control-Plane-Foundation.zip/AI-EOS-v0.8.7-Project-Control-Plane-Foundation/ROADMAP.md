---
id: roadmap
version: 0.8.7
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: true
depends_on: []
used_by: []
supersedes: null
---

# Roadmap

## Completed

- v0.8.5 — Validation Truthfulness Hardening.
- v0.8.6 — Unified Validation Governance.
- v0.8.7 — Project Control Plane Foundation.

## Next

- v0.8.8 — Provider Layer Consolidation.
- v0.9.0 — Adaptive Intelligence and runtime learning.
