---
id: readme
version: 0.8.7
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: true
depends_on: [adr-0042, adr-0043]
used_by: []
supersedes: null
---

# AI-EOS v0.8.7 — Project Control Plane Foundation

Codename: Controlled Work.

This release adds the first explicit **Project Control Plane** for AI-EOS.

## What changed

- Added `runtime/control_plane/`.
- Added `TaskPacket`.
- Added `EvidenceLedger`.
- Added `SkillRegistry`.
- Added `AgentRegistry`.
- Added CLI bootstrap:

```bash
python -m runtime.control_plane --root . bootstrap
```

- Added `control-plane-foundation-validator`.
- Added ADR-0043.

## Why this matters

Previous releases improved runtime and validation truthfulness. v0.8.7 adds the layer that makes future agentic work governable: work is packetized, evidence is recorded, skills are declared and agents have explicit permissions.

## Baseline

AI-EOS v0.8.6 Unified Validation Governance.
