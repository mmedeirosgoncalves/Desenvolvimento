---
id: changelog
version: 0.8.7
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: true
depends_on: []
used_by: []
supersedes: null
---

# Changelog

## v0.8.7 — Project Control Plane Foundation

- Added runtime control plane package.
- Added task packet model.
- Added evidence ledger.
- Added skill registry.
- Added agent registry.
- Added control-plane CLI bootstrap.
- Added control-plane validation.
- Added ADR-0043.
