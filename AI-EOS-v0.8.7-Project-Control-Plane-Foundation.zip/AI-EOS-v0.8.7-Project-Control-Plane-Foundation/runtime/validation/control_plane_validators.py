from __future__ import annotations
import json, subprocess, sys, tempfile
from pathlib import Path

def validate_control_plane(root: str | Path = ".") -> dict:
    root = Path(root).resolve()
    required = [
        "runtime/control_plane/models.py",
        "runtime/control_plane/control_plane.py",
        "runtime/control_plane/ledger.py",
        "runtime/control_plane/registry.py",
        "runtime/control_plane/cli.py",
        "runtime/control_plane/CONTROL_PLANE.md",
        "runtime/control_plane/TASK_PACKET_SCHEMA.md",
        "runtime/control_plane/EVIDENCE_LEDGER.md",
        "runtime/control_plane/SKILL_REGISTRY.md",
        "runtime/control_plane/AGENT_DEFINITION.md",
    ]
    missing = [p for p in required if not (root / p).exists()]
    if missing:
        return {"validator_id": "control-plane-foundation-validator", "status": "FAIL", "missing": missing}

    with tempfile.TemporaryDirectory() as td:
        proc = subprocess.run(
            [sys.executable, "-m", "runtime.control_plane", "--root", td, "bootstrap"],
            cwd=str(root), capture_output=True, text=True, timeout=60
        )
        if proc.returncode != 0:
            return {"validator_id": "control-plane-foundation-validator", "status": "FAIL", "stderr": proc.stderr, "stdout": proc.stdout}
        payload = json.loads(proc.stdout)
        ok = payload.get("status") == "PASS" and payload.get("skills", 0) >= 3 and payload.get("agents", 0) >= 2
        return {"validator_id": "control-plane-foundation-validator", "status": "PASS" if ok else "WARNING", "metrics": payload}
