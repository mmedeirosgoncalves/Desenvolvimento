---
id: skill-registry
version: 0.8.7
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: false
depends_on: [adr-0043]
used_by: []
supersedes: null
---

# Skill Registry

The skill registry describes reusable capabilities using explicit metadata:

- skill id;
- name;
- description;
- triggers;
- inputs;
- outputs;
- risks.

This directly addresses the external audit criticism that skills should not be one-line generic stubs.
