---
id: agent-definition
version: 0.8.7
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: false
depends_on: [adr-0043]
used_by: []
supersedes: null
---

# Agent Definition

Agent definitions declare:

- agent id;
- role;
- allowed skills;
- denied actions;
- risk levels requiring review.

The default policy denies destructive writes without approval and secret exfiltration.
