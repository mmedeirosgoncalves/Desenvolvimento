---
id: evidence-ledger
version: 0.8.7
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: false
depends_on: [adr-0043]
used_by: []
supersedes: null
---

# Evidence Ledger

The evidence ledger records execution evidence as JSON records with payload hashes.

Each record includes:

- `evidence_id`;
- `task_id`;
- `kind`;
- `source`;
- `summary`;
- `payload_hash`;
- `created_at`.

The ledger is append-oriented. It is not a replacement for full artifacts, but it records enough hashes and summaries to support auditability.
