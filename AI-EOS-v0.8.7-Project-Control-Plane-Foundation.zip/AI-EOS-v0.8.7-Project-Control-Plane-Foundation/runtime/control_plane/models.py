from __future__ import annotations
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
import hashlib, json, uuid

VALID_RISKS = {"low", "medium", "high", "critical"}
VALID_STATUS = {"draft", "ready", "running", "blocked", "completed", "failed"}

def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()

def stable_hash(obj: Any) -> str:
    payload = json.dumps(obj, sort_keys=True, ensure_ascii=False, allow_nan=False).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()

@dataclass
class TaskPacket:
    task_id: str
    objective: str
    scope: str
    constraints: list[str] = field(default_factory=list)
    required_skills: list[str] = field(default_factory=list)
    providers: list[str] = field(default_factory=list)
    risk: str = "medium"
    status: str = "ready"
    acceptance_criteria: list[str] = field(default_factory=list)
    created_at: str = field(default_factory=utc_now)
    updated_at: str = field(default_factory=utc_now)

    @classmethod
    def create(cls, objective: str, scope: str, **kwargs: Any) -> "TaskPacket":
        return cls(task_id=f"TASK-{uuid.uuid4().hex[:10].upper()}", objective=objective, scope=scope, **kwargs)

    def validate(self) -> list[str]:
        errors = []
        if not self.task_id:
            errors.append("task_id is required")
        if not self.objective:
            errors.append("objective is required")
        if not self.scope:
            errors.append("scope is required")
        if self.risk not in VALID_RISKS:
            errors.append(f"risk must be one of {sorted(VALID_RISKS)}")
        if self.status not in VALID_STATUS:
            errors.append(f"status must be one of {sorted(VALID_STATUS)}")
        if not self.acceptance_criteria:
            errors.append("acceptance_criteria must not be empty")
        return errors

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["sha256"] = stable_hash({k:v for k,v in d.items() if k != "sha256"})
        return d

@dataclass
class EvidenceRecord:
    evidence_id: str
    task_id: str
    kind: str
    source: str
    summary: str
    payload_hash: str
    created_at: str = field(default_factory=utc_now)

    @classmethod
    def from_payload(cls, task_id: str, kind: str, source: str, summary: str, payload: Any) -> "EvidenceRecord":
        return cls(
            evidence_id=f"EVID-{uuid.uuid4().hex[:10].upper()}",
            task_id=task_id,
            kind=kind,
            source=source,
            summary=summary,
            payload_hash=stable_hash(payload),
        )

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

@dataclass
class SkillDefinition:
    skill_id: str
    name: str
    description: str
    triggers: list[str]
    inputs: list[str]
    outputs: list[str]
    risks: list[str] = field(default_factory=list)
    owner: str = "AI-EOS"

    def validate(self) -> list[str]:
        errors = []
        if not self.skill_id or not self.name:
            errors.append("skill_id and name are required")
        if not self.triggers:
            errors.append("triggers must not be empty")
        if not self.outputs:
            errors.append("outputs must not be empty")
        return errors

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

@dataclass
class AgentDefinition:
    agent_id: str
    name: str
    role: str
    allowed_skills: list[str]
    denied_actions: list[str] = field(default_factory=lambda: ["destructive_write_without_approval", "secret_exfiltration"])
    review_required_for: list[str] = field(default_factory=lambda: ["high", "critical"])

    def validate(self) -> list[str]:
        errors = []
        if not self.agent_id or not self.name:
            errors.append("agent_id and name are required")
        if not self.allowed_skills:
            errors.append("allowed_skills must not be empty")
        return errors

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
