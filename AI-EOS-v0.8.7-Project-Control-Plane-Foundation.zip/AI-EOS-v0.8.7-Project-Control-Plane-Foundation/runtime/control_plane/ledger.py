from __future__ import annotations
import json
from pathlib import Path
from typing import Any
from .models import EvidenceRecord

class EvidenceLedger:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self.path.write_text("[]", encoding="utf-8")

    def read(self) -> list[dict[str, Any]]:
        return json.loads(self.path.read_text(encoding="utf-8"))

    def append(self, record: EvidenceRecord) -> list[dict[str, Any]]:
        data = self.read()
        item = record.to_dict()
        data.append(item)
        self.path.write_text(json.dumps(data, indent=2, sort_keys=True, allow_nan=False), encoding="utf-8")
        return data

    def for_task(self, task_id: str) -> list[dict[str, Any]]:
        return [r for r in self.read() if r.get("task_id") == task_id]
