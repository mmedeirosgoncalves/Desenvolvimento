---
id: control-plane
version: 0.8.7
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: false
depends_on: [adr-0043]
used_by: []
supersedes: null
---

# Project Control Plane

The Project Control Plane is the governance layer that turns an AI-EOS release from a collection of runtime modules into a controllable operating system for agentic work.

It provides four primitives:

1. `TaskPacket` — explicit unit of work.
2. `EvidenceLedger` — append-only evidence trail with payload hashes.
3. `SkillRegistry` — catalog of executable/reviewable capabilities.
4. `AgentRegistry` — declared agent roles, allowed skills and review requirements.

The control plane does not replace the consensus engine. It prepares work for it and records evidence after it.
