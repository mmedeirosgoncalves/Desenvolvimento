from __future__ import annotations
import json
from pathlib import Path
from typing import Any
from .models import TaskPacket, EvidenceRecord, SkillDefinition, AgentDefinition
from .ledger import EvidenceLedger
from .registry import SkillRegistry, AgentRegistry

class ProjectControlPlane:
    def __init__(self, root: str | Path = "."):
        self.root = Path(root)
        self.state = self.root / "runtime" / "control_plane" / "state"
        self.state.mkdir(parents=True, exist_ok=True)
        self.task_dir = self.state / "tasks"
        self.task_dir.mkdir(exist_ok=True)
        self.ledger = EvidenceLedger(self.state / "evidence-ledger.json")
        self.skills = SkillRegistry(self.state / "skill-registry.json")
        self.agents = AgentRegistry(self.state / "agent-registry.json")

    def create_task(self, objective: str, scope: str, **kwargs: Any) -> TaskPacket:
        task = TaskPacket.create(objective, scope, **kwargs)
        errors = task.validate()
        if errors:
            raise ValueError("; ".join(errors))
        (self.task_dir / f"{task.task_id}.json").write_text(
            json.dumps(task.to_dict(), indent=2, sort_keys=True, allow_nan=False), encoding="utf-8"
        )
        self.ledger.append(EvidenceRecord.from_payload(task.task_id, "task-created", "control-plane", "Task packet created", task.to_dict()))
        return task

    def load_task(self, task_id: str) -> dict[str, Any]:
        path = self.task_dir / f"{task_id}.json"
        if not path.exists():
            raise FileNotFoundError(task_id)
        return json.loads(path.read_text(encoding="utf-8"))

    def add_evidence(self, task_id: str, kind: str, source: str, summary: str, payload: Any) -> dict[str, Any]:
        record = EvidenceRecord.from_payload(task_id, kind, source, summary, payload)
        self.ledger.append(record)
        return record.to_dict()

    def register_default_skills(self) -> None:
        defaults = [
            SkillDefinition(
                skill_id="skill.release-audit",
                name="Release Audit",
                description="Evaluate a release using reproducible validation evidence.",
                triggers=["release", "audit", "validation"],
                inputs=["release_package", "validation_report"],
                outputs=["audit_findings", "risk_assessment"],
                risks=["false_positive", "stale_documentation"],
            ),
            SkillDefinition(
                skill_id="skill.consensus-execution",
                name="Consensus Execution",
                description="Run independent provider responses through consensus and human-review gates.",
                triggers=["multi-ai", "consensus", "provider"],
                inputs=["task_packet", "provider_responses"],
                outputs=["consensus_report", "review_recommendation"],
                risks=["provider_drift", "hidden_cost"],
            ),
            SkillDefinition(
                skill_id="skill.codegen-control",
                name="Codegen Control",
                description="Convert approved consensus output into implementation steps and testable patches.",
                triggers=["codegen", "implementation", "patch"],
                inputs=["consensus_report", "acceptance_criteria"],
                outputs=["patch_plan", "test_plan"],
                risks=["side_effects", "permission_scope"],
            ),
        ]
        for skill in defaults:
            self.skills.add_skill(skill)

    def register_default_agents(self) -> None:
        defaults = [
            AgentDefinition(
                agent_id="agent.release-steward",
                name="Release Steward",
                role="Coordinates release readiness, evidence, and validation gates.",
                allowed_skills=["skill.release-audit", "skill.consensus-execution"],
            ),
            AgentDefinition(
                agent_id="agent.codegen-operator",
                name="Codegen Operator",
                role="Transforms approved task packets into implementation work.",
                allowed_skills=["skill.codegen-control"],
                review_required_for=["medium", "high", "critical"],
            ),
        ]
        for agent in defaults:
            self.agents.add_agent(agent)

    def bootstrap(self) -> dict[str, Any]:
        self.register_default_skills()
        self.register_default_agents()
        task = self.create_task(
            objective="Bootstrap project control plane",
            scope="Initialize task packet, evidence ledger, skill registry and agent registry.",
            constraints=["non-destructive", "validation-first"],
            required_skills=["skill.release-audit"],
            providers=["mock-control-plane"],
            risk="medium",
            acceptance_criteria=[
                "task packet can be created",
                "evidence ledger records immutable hashes",
                "skill registry exists",
                "agent registry exists",
            ],
        )
        return {
            "status": "PASS",
            "task_id": task.task_id,
            "skills": len(self.skills.read()),
            "agents": len(self.agents.read()),
            "evidence_records": len(self.ledger.read()),
        }
