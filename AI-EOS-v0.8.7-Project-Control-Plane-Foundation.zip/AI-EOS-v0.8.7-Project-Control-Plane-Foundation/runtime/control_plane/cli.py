from __future__ import annotations
import argparse, json
from .control_plane import ProjectControlPlane

def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="python -m runtime.control_plane")
    parser.add_argument("--root", default=".")
    sub = parser.add_subparsers(dest="cmd", required=True)

    sub.add_parser("bootstrap")
    create = sub.add_parser("create-task")
    create.add_argument("--objective", required=True)
    create.add_argument("--scope", required=True)
    create.add_argument("--acceptance", action="append", default=[])

    args = parser.parse_args(argv)
    cp = ProjectControlPlane(args.root)

    if args.cmd == "bootstrap":
        print(json.dumps(cp.bootstrap(), indent=2, allow_nan=False))
        return 0
    if args.cmd == "create-task":
        task = cp.create_task(
            objective=args.objective,
            scope=args.scope,
            acceptance_criteria=args.acceptance or ["task has explicit acceptance criteria"],
        )
        print(json.dumps(task.to_dict(), indent=2, allow_nan=False))
        return 0
    return 2

if __name__ == "__main__":
    raise SystemExit(main())
