---
id: migration-guide
version: 0.8.7
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: true
depends_on: [adr-0043]
used_by: []
supersedes: null
---

# Migration Guide — v0.8.6 to v0.8.7

Bootstrap the project control plane:

```bash
python -m runtime.control_plane --root . bootstrap
```

Use task packets for new work instead of informal prompts when release-level evidence is required.
