---
id: release-validation
version: 0.8.7
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: true
depends_on: [adr-0042, adr-0043]
used_by: []
supersedes: null
---

# Release Validation — v0.8.7

Required commands:

```bash
python runtime/validation/unified_validation.py . validation-report.json
python -m runtime.control_plane --root . bootstrap
python runtime/validation/reference/python/run_tests.py
```

Acceptance rule:

- unified validation must not hide reference-validator findings;
- control-plane bootstrap must pass;
- tests must pass.


## Executed in package generation

```text
control_plane_bootstrap_rc=0
control_plane_bootstrap={
  "status": "PASS",
  "task_id": "TASK-3C23AB8ED9",
  "skills": 3,
  "agents": 2,
  "evidence_records": 1
}
unified_validation_status=WARNING
unified_validation_recommendation=ACCEPT_WITH_RECOMMENDATIONS
findings=1
known_residual=reference-validator WARNING is preserved by unified governance, not masked as PASS.
```
