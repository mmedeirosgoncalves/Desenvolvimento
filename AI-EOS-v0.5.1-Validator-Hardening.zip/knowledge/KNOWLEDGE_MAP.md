---
id: knowledge-map
version: 0.4.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [canon-map, canon-inclusion-criteria]
used_by: [dependency-graph]
supersedes: null
---

# Knowledge Map

## Purpose

Map Canon domains to Knowledge Packs, Skills and Playbooks.

## Canon to Knowledge

| Canon Domain | Knowledge Pack | Primary Skills |
|---|---|---|
| Architecture | `knowledge/packs/architecture/` | architecture-review |
| Security | `knowledge/packs/security/` | security-review |
| Testing | `knowledge/packs/testing/` | testing-strategy |
| Data | `knowledge/packs/data/` | databricks-engineering, database-design |
| Database | `knowledge/packs/database/` | database-design |
| Cloud | `knowledge/packs/cloud/` | devops-review |
| Databricks | `knowledge/packs/databricks/` | databricks-engineering |
| API | `knowledge/packs/api/` | api-design |
| Legacy | `knowledge/packs/legacy/` | legacy-modernization |
| DevOps | `knowledge/packs/devops/` | devops-review |

## Transitional Note

As of v0.4, Canon is being expanded while existing Knowledge Packs remain operational.

Knowledge Packs should gradually reference Canon instead of duplicating durable concepts.


## Canon-Wide References

Knowledge Packs should reference Canon-wide decision rules and roadmap when adapting Canon content.

- Canon-wide decision rules: `canon/DECISION_RULES.md`
- Canon-wide roadmap: `canon/ROADMAP.md`
