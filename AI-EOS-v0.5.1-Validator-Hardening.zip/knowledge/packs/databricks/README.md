---
id: kp-databricks
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: []
used_by: []
supersedes: null
---

# Databricks Knowledge Pack

## Current Status

Initial knowledge pack.

## Principles

- Prefer Delta Lake for reliability.
- Manage governance through Unity Catalog when available.
- Optimize Spark jobs based on measurement.
- Design pipelines for lineage and observability.

## Future Expansion

This pack should be expanded with:

- domain standards
- checklists
- examples
- anti-patterns
- decision rules
