---
id: kp-architecture
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: []
used_by: []
supersedes: null
---

# Architecture Knowledge Pack

## Current Status

Initial knowledge pack.

## Principles

- Use boundaries to manage complexity.
- Avoid coupling through shared mutable state.
- Prefer reversible decisions when uncertainty is high.
- Document irreversible decisions with ADRs.

## Future Expansion

This pack should be expanded with:

- domain standards
- checklists
- examples
- anti-patterns
- decision rules
