---
id: canon-architecture
version: 0.4.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [canon-map]
used_by: [kp-architecture, skill-architecture]
supersedes: null
---

# Architecture Canon

## Purpose

This Canon domain captures durable engineering knowledge for architecture decisions and practices.

## Maturity

C2 — Operational Guidance.

This domain now includes principles, patterns, anti-patterns and checklist guidance.

## Files

- `PRINCIPLES.md`
- `PATTERNS.md`
- `ANTI_PATTERNS.md`
- `CHECKLIST.md`
- `DECISION_RULES.md`
- `ROADMAP.md`

## Primary Consumers

- Knowledge Packs
- Skills
- Playbooks
- Quality Gates
- Agents
