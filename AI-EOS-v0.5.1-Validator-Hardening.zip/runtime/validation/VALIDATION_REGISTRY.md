---
id: validator-registry
version: 0.5.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [validator-model, validation-automation-levels]
used_by: []
supersedes: null
---

# Validation Registry

## Purpose

Map Validators to Quality Gates and automation levels.

## Registry

| Validator | Level | Quality Gates | Purpose |
|---|---|---|---|
| frontmatter-validator | L2 | QG-009, QG-004 | Validate ids, required metadata and dependency references |
| dependency-graph-validator | L2 | QG-009 | Validate `depends_on` and `supersedes` |
| bootstrap-validator | L2 | QG-009 | Validate files referenced by `AGENTS.md` |
| manifest-validator | L2 | QG-009 | Validate package manifest counts and structure |
| markdown-render-validator | L1 | QG-004 | Detect render issues such as literal escaped newlines |
| content-duplication-validator | L1 | QG-004 | Detect duplicated or near-duplicated documentation |
| canon-structure-validator | L1 | QG-004, QG-001 | Validate Canon structure and SSOT rules |
| version-consistency-validator | L1 | QG-004 | Detect stale version metadata |

## Extension Rule

New validators must be registered here before they are used by release validation.

## v0.5.1 Hardening

Additional validator coverage:

- near-duplicate content detection;
- line-level literal newline detection;
- manifest top-level area validation;
- metadata status/version/date validation;
- negative fixture checks.
