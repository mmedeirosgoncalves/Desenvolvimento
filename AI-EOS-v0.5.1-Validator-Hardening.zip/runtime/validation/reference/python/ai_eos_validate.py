#!/usr/bin/env python3
"""
AI-EOS Reference Validator.

Stdlib-only reference implementation for validating AI-EOS.
"""

from __future__ import annotations

import argparse
import json
import re
import hashlib
import difflib
from pathlib import Path
from collections import defaultdict


STATUS_PASS = "PASS"
STATUS_FAIL = "FAIL"
STATUS_WARNING = "WARNING"
ALLOWED_STATUS = {"active", "historical", "deprecated", "experimental", "draft", "superseded", "removed"}


def parse_front_matter(text: str):
    if not text.startswith("---"):
        return {}, text
    parts = text.split("---", 2)
    if len(parts) < 3:
        return {}, text
    raw = parts[1]
    body = parts[2].lstrip()
    meta = {}
    for line in raw.strip().splitlines():
        if ":" in line:
            key, value = line.split(":", 1)
            meta[key.strip()] = value.strip()
    return meta, body


def parse_list_value(value: str):
    if not value:
        return []
    return re.findall(r"[\w-]+", value)


def markdown_files(root: Path):
    files = []
    root_parts = set(root.parts)
    validating_fixture_root = "fixtures" in root_parts and "tests" in root_parts
    for path in sorted(root.rglob("*.md")):
        parts = set(path.parts)
        # Negative fixtures are test data and must not be part of normal repository validation.
        # When a fixture directory itself is passed as root, include it for tests.
        if not validating_fixture_root and "fixtures" in parts and "tests" in parts and "validation" in parts:
            continue
        files.append(path)
    return files


def collect_ids(root: Path):
    ids = {}
    duplicates = []
    deps = {}
    supersedes = {}
    missing_frontmatter = []
    for path in markdown_files(root):
        rel = str(path.relative_to(root))
        text = path.read_text(encoding="utf-8")
        meta, _ = parse_front_matter(text)
        artifact_id = meta.get("id")
        if not meta or not artifact_id:
            missing_frontmatter.append(rel)
            continue
        if artifact_id in ids:
            duplicates.append({"id": artifact_id, "first": ids[artifact_id], "second": rel})
        ids[artifact_id] = rel
        deps[artifact_id] = parse_list_value(meta.get("depends_on", "[]"))
        sup = meta.get("supersedes", "null")
        if sup and sup != "null":
            supersedes[artifact_id] = sup
    return ids, duplicates, deps, supersedes, missing_frontmatter


def validate_dependency_graph(root: Path):
    ids, duplicates, deps, supersedes, missing_fm = collect_ids(root)
    unresolved = [{"source": aid, "target": d} for aid, ds in deps.items() for d in ds if d not in ids]
    unresolved_supersedes = [{"source": aid, "target": s} for aid, s in supersedes.items() if s not in ids]
    findings = []
    if duplicates:
        findings.append({"severity": "CRITICAL", "message": "Duplicate ids found", "items": duplicates})
    if unresolved:
        findings.append({"severity": "CRITICAL", "message": "Unresolved depends_on references", "items": unresolved})
    if unresolved_supersedes:
        findings.append({"severity": "HIGH", "message": "Unresolved supersedes references", "items": unresolved_supersedes})
    if missing_fm:
        findings.append({"severity": "MEDIUM", "message": "Missing or incomplete front matter", "items": missing_fm})
    return {
        "validator_id": "dependency-graph-validator",
        "status": STATUS_PASS if not duplicates and not unresolved and not unresolved_supersedes else STATUS_FAIL,
        "gates": ["qg-009-dependency-integrity"],
        "evidence": {
            "ids": len(ids),
            "duplicates": len(duplicates),
            "unresolved_dependencies": len(unresolved),
            "unresolved_supersedes": len(unresolved_supersedes),
            "missing_frontmatter": len(missing_fm),
        },
        "findings": findings,
    }


def validate_bootstrap(root: Path):
    agents = root / "AGENTS.md"
    missing = []
    if not agents.exists():
        missing.append("AGENTS.md")
    else:
        text = agents.read_text(encoding="utf-8")
        for match in re.finditer(r"`([^`]+\.md)`", text):
            rel = match.group(1)
            if not (root / rel).exists():
                missing.append(rel)
    return {
        "validator_id": "bootstrap-validator",
        "status": STATUS_PASS if not missing else STATUS_FAIL,
        "gates": ["qg-009-dependency-integrity"],
        "evidence": {"missing_bootstrap_references": len(missing)},
        "findings": [{"severity": "CRITICAL", "message": "Missing bootstrap references", "items": missing}] if missing else [],
    }


def is_literal_newline_allowed(line: str):
    lower = line.lower()
    return ("literal `\\n`" in line or "literal `\\\\n`" in line or "literal \"\\n\"" in line or "escaped newline" in lower or "literal newline" in lower)


def validate_markdown_render(root: Path):
    findings = []
    occurrences = []
    for path in markdown_files(root):
        rel = str(path.relative_to(root))
        text = path.read_text(encoding="utf-8")
        for idx, line in enumerate(text.splitlines(), start=1):
            if "\\n" in line and not is_literal_newline_allowed(line):
                occurrences.append({"file": rel, "line": idx, "text": line[:160]})
        if text.count("```") % 2 != 0:
            findings.append({"severity": "HIGH", "message": "Unclosed code fence", "file": rel})
    if occurrences:
        findings.append({"severity": "MEDIUM", "message": "Literal escaped newlines found", "items": occurrences})
    return {
        "validator_id": "markdown-render-validator",
        "status": STATUS_PASS if not findings else STATUS_WARNING,
        "gates": ["qg-004-documentation"],
        "evidence": {"literal_newline_occurrences": len(occurrences), "findings": len(findings)},
        "findings": findings,
    }


def normalized_body(path: Path, remove_h1: bool = True):
    text = path.read_text(encoding="utf-8")
    _, body = parse_front_matter(text)
    lines = body.splitlines()
    if remove_h1:
        lines = [line for line in lines if not line.strip().startswith("# ")]
    body = "\n".join(lines)
    body = re.sub(r"`[^`]+`", "", body)
    body = re.sub(r"\s+", " ", body.strip().lower())
    return body


def allowed_duplicate_group(group):
    return all(re.match(r"canon/[^/]+/(DECISION_RULES|ROADMAP)\.md$", item) for item in group)


def validate_content_duplication(root: Path):
    groups = defaultdict(list)
    candidates = []
    for path in markdown_files(root):
        rel = str(path.relative_to(root))
        body = normalized_body(path, remove_h1=True)
        if not body:
            continue
        groups[hashlib.sha256(body.encode("utf-8")).hexdigest()].append(rel)
        if len(body) >= 120:
            candidates.append((rel, body))
    exact_duplicates = [items for items in groups.values() if len(items) > 1]
    unexpected_exact = [g for g in exact_duplicates if not allowed_duplicate_group(g)]
    near_duplicates = []
    # Limit near-duplicate comparison to files with similar size for speed and fewer false positives.
    for i, (rel_a, body_a) in enumerate(candidates):
        len_a = len(body_a)
        for rel_b, body_b in candidates[i+1:]:
            len_b = len(body_b)
            if min(len_a, len_b) / max(len_a, len_b) < 0.75:
                continue
            ratio = difflib.SequenceMatcher(None, body_a, body_b).ratio()
            if ratio >= 0.92:
                group = [rel_a, rel_b]
                if not allowed_duplicate_group(group):
                    near_duplicates.append({"files": group, "similarity": round(ratio, 4)})
    findings = []
    if unexpected_exact:
        findings.append({"severity": "MEDIUM", "message": "Unexpected exact duplicate content", "items": unexpected_exact})
    if near_duplicates:
        findings.append({"severity": "LOW", "message": "Near-duplicate content", "items": near_duplicates[:50]})
    return {
        "validator_id": "content-duplication-validator",
        "status": STATUS_PASS if not findings else STATUS_WARNING,
        "gates": ["qg-004-documentation"],
        "evidence": {
            "exact_duplicate_groups": len(exact_duplicates),
            "unexpected_exact_duplicate_groups": len(unexpected_exact),
            "near_duplicate_pairs": len(near_duplicates),
        },
        "findings": findings,
    }


def validate_manifest(root: Path, baseline_root: Path | None = None):
    manifest = root / "PACKAGE_MANIFEST.md"
    findings = []
    actual_md = len(markdown_files(root))
    actual_top = sorted([p.name + "/" for p in root.iterdir() if p.is_dir()])
    declared = None
    listed_top = []
    if not manifest.exists():
        findings.append({"severity": "HIGH", "message": "PACKAGE_MANIFEST.md missing"})
    else:
        text = manifest.read_text(encoding="utf-8")
        match = re.search(r"## Markdown Files\s+(\d+)", text)
        if match:
            declared = int(match.group(1))
            if declared != actual_md:
                findings.append({"severity": "MEDIUM", "message": "Markdown file count mismatch", "declared": declared, "actual": actual_md})
        else:
            findings.append({"severity": "LOW", "message": "Markdown file count not declared"})
        top_section = re.search(r"## Top-Level Areas\s+(.*?)(?:\n## |\Z)", text, re.S)
        if top_section:
            listed_top = re.findall(r"- ([^\n]+/)", top_section.group(1))
            missing_from_manifest = sorted(set(actual_top) - set(listed_top))
            nonexistent_in_manifest = sorted(set(listed_top) - set(actual_top))
            if missing_from_manifest:
                findings.append({"severity": "MEDIUM", "message": "Top-level areas missing from manifest", "items": missing_from_manifest})
            if nonexistent_in_manifest:
                findings.append({"severity": "MEDIUM", "message": "Manifest lists nonexistent top-level areas", "items": nonexistent_in_manifest})
        else:
            findings.append({"severity": "LOW", "message": "Top-Level Areas section missing"})
    if baseline_root and baseline_root.exists():
        current_files = {str(p.relative_to(root)) for p in root.rglob("*") if p.is_file()}
        baseline_files = {str(p.relative_to(baseline_root)) for p in baseline_root.rglob("*") if p.is_file()}
        removed = sorted(baseline_files - current_files)
        if removed:
            findings.append({"severity": "HIGH", "message": "Files removed against baseline", "items": removed})
    return {
        "validator_id": "manifest-validator",
        "status": STATUS_PASS if not findings else STATUS_WARNING,
        "gates": ["qg-009-dependency-integrity"],
        "evidence": {"actual_markdown_files": actual_md, "declared_markdown_files": declared, "actual_top_level_areas": actual_top, "listed_top_level_areas": listed_top},
        "findings": findings,
    }


def validate_version_metadata(root: Path):
    findings = []
    for path in markdown_files(root):
        rel = str(path.relative_to(root))
        meta, _ = parse_front_matter(path.read_text(encoding="utf-8"))
        if not meta:
            continue
        status = meta.get("status")
        if status and status not in ALLOWED_STATUS:
            findings.append({"severity": "LOW", "message": "Unexpected status value", "file": rel, "status": status})
        if not meta.get("version"):
            findings.append({"severity": "LOW", "message": "Missing version metadata", "file": rel})
        if not meta.get("updated"):
            findings.append({"severity": "LOW", "message": "Missing updated metadata", "file": rel})
        if not meta.get("review_date"):
            findings.append({"severity": "LOW", "message": "Missing review_date metadata", "file": rel})
    return {
        "validator_id": "version-consistency-validator",
        "status": STATUS_PASS if not findings else STATUS_WARNING,
        "gates": ["qg-004-documentation"],
        "evidence": {"metadata_findings": len(findings)},
        "findings": findings,
    }


def run(root: Path, baseline_root: Path | None = None):
    validators = [
        validate_dependency_graph(root),
        validate_bootstrap(root),
        validate_markdown_render(root),
        validate_content_duplication(root),
        validate_manifest(root, baseline_root),
        validate_version_metadata(root),
    ]
    has_fail = any(v["status"] == STATUS_FAIL for v in validators)
    has_warning = any(v["status"] == STATUS_WARNING for v in validators)
    if has_fail:
        status = "FAIL"; recommendation = "REJECT"
    elif has_warning:
        status = "WARNING"; recommendation = "ACCEPT_WITH_RECOMMENDATIONS"
    else:
        status = "PASS"; recommendation = "ACCEPT"
    return {
        "release": "AI-EOS",
        "validation_engine": "reference-python",
        "summary": {"status": status, "markdown_files": len(markdown_files(root)), "validators": len(validators), "findings": sum(len(v["findings"]) for v in validators)},
        "validators": validators,
        "recommendation": recommendation,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("root", nargs="?", default=".", help="AI-EOS repository root")
    parser.add_argument("--baseline", help="Optional baseline root for manifest/removal checks")
    parser.add_argument("--json", dest="json_path", help="Write JSON report to path")
    args = parser.parse_args()
    root = Path(args.root).resolve()
    baseline = Path(args.baseline).resolve() if args.baseline else None
    report = run(root, baseline)
    print(json.dumps(report, indent=2, ensure_ascii=False))
    if args.json_path:
        Path(args.json_path).write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    return 0 if report["summary"]["status"] in {"PASS", "WARNING"} else 1


if __name__ == "__main__":
    import argparse
    raise SystemExit(main())
