---
id: validator-hardening
version: 0.5.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [adr-0016, validation-engine]
used_by: []
supersedes: null
---

# Validator Hardening

## Purpose

Document hardening improvements introduced in v0.5.1.

## Improvements

- near-duplicate detection using body normalization and similarity;
- body comparison without front matter and H1 headings;
- line-level literal newline reporting;
- manifest top-level area validation;
- metadata status/version/date validation;
- negative fixtures for known failure modes.

## Blocking Policy

- QG-009 failures remain blocking.
- QG-004 content warnings remain non-blocking until reviewed.
- Metadata inconsistencies are warnings in v0.5.1.

## Future Work

- stronger semantic similarity;
- richer Markdown parsing;
- configurable validator thresholds;
- validator unit tests in CI;
- baseline diff integration.
