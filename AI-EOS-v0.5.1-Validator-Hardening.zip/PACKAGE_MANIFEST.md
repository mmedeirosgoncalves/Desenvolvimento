---
id: package-manifest
version: 0.5.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [validator-hardening, qg-009-dependency-integrity]
used_by: []
supersedes: null
---

# Package Manifest

## Release

AI-EOS v0.5.1 Validator Hardening

## Baseline

AI-EOS v0.5.0 Validation Engine.

## Purpose

This release hardens the Validation Engine to reduce false negatives.

## Entry Point

`AGENTS.md`

## Markdown Files

224

## Test Fixture Markdown Files

9

## Top-Level Areas

- adapters/
- agents/
- architecture/
- canon/
- constitution/
- decision-trees/
- docs/
- evaluation/
- governance/
- harness/
- heuristics/
- knowledge/
- labs/
- multi-agent/
- playbooks/
- runtime/
- skills/
- templates/
- vision/

## Added Files

- architecture/adr/ADR-0016-validator-hardening-strategy.md
- runtime/validation/VALIDATOR_HARDENING.md
- runtime/validation/reference/python/__pycache__/ai_eos_validate.cpython-313.pyc
- runtime/validation/reference/python/tests/README.md
- runtime/validation/reference/python/tests/__pycache__/test_negative_fixtures.cpython-313.pyc
- runtime/validation/reference/python/tests/fixtures/broken-dependency/A.md
- runtime/validation/reference/python/tests/fixtures/duplicate-id/A.md
- runtime/validation/reference/python/tests/fixtures/duplicate-id/B.md
- runtime/validation/reference/python/tests/fixtures/literal-newline/A.md
- runtime/validation/reference/python/tests/fixtures/manifest-inconsistent/A.md
- runtime/validation/reference/python/tests/fixtures/manifest-inconsistent/PACKAGE_MANIFEST.md
- runtime/validation/reference/python/tests/fixtures/near-duplicate/A.md
- runtime/validation/reference/python/tests/fixtures/near-duplicate/B.md
- runtime/validation/reference/python/tests/fixtures/stale-version/A.md
- runtime/validation/reference/python/tests/test_negative_fixtures.py

## Validation Summary

- Baseline files removed: 0
- Duplicate ids: 0
- Unresolved dependencies: 0
- Missing bootstrap references: 0
- Reference validator status: WARNING
- Reference validator recommendation: ACCEPT_WITH_RECOMMENDATIONS
- Negative fixture tests status: PASS

## Status

Recommended for independent review.
