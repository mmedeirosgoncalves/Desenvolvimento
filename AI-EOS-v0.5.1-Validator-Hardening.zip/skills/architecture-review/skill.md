---
id: skill-architecture-review
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [kp-architecture, architectural_heuristics, qg-001-architecture]
used_by: []
supersedes: null
---

# Architecture Review Skill

## Purpose

Evaluate whether a proposed or implemented change fits the system architecture and preserves long-term maintainability.

## Canon Dependencies

- `canon/architecture/`

## Knowledge Dependencies

- `knowledge/packs/architecture/README.md`
- `heuristics/ARCHITECTURAL_HEURISTICS.md`
- `decision-trees/ARCHITECTURE_DECISION_TREE.md`

## Required Gates

- QG-001 Architecture
- QG-004 Documentation
- QG-008 Deployment / Rollback when production impact exists

## Process

1. Identify affected components.
2. Identify existing architectural patterns.
3. Evaluate coupling and cohesion.
4. Evaluate reversibility.
5. Evaluate operational impact.
6. Identify alternatives.
7. Recommend decision.
8. Require ADR if decision is significant.
