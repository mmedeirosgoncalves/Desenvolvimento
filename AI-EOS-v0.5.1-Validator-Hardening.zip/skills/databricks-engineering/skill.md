---
id: skill-databricks-engineering
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [kp-databricks]
used_by: []
supersedes: null
---

# Databricks Engineering Skill

## Status

Initial skill requiring expansion.

## Knowledge Dependency

- `knowledge/packs/databricks/README.md`

## Purpose

Provide basic execution guidance for databricks engineering tasks.

## Maturity Warning

Do not treat this skill as complete domain expertise.

Upgrade using `skills/security-review/` and `skills/architecture-review/` as patterns.
