---
id: readme
version: 0.5.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [validator-hardening, adr-0016]
used_by: []
supersedes: null
---

# AI-EOS v0.5.1 Validator Hardening

AI-EOS is an Artificial Intelligence Engineering Operating System for AI-assisted software engineering.

This release hardens the Validation Engine introduced in v0.5.0.

## Baseline

v0.5.0 Validation Engine.

## What This Release Adds

- improved duplicate detection;
- near-duplicate detection;
- line-level literal newline reporting;
- stronger manifest validation;
- version/status/date metadata validation;
- negative fixtures for known validator failure modes;
- ADR-0016 Validator Hardening Strategy.

## Validation

From the AI-EOS root:

```bash
python runtime/validation/reference/python/ai_eos_validate.py .
python runtime/validation/reference/python/tests/test_negative_fixtures.py
```

## Status

v0.5.1 strengthens the executable validation layer without changing AI-EOS architecture.
