---
id: changelog
version: 0.5.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [adr-0016]
used_by: []
supersedes: null
---

# Changelog

## v0.5.1 — Validator Hardening

### Added

- ADR-0016 — Validator Hardening Strategy.
- `runtime/validation/VALIDATOR_HARDENING.md`
- Negative fixtures for:
  - duplicate id
  - broken dependency
  - literal escaped newline
  - near-duplicate content
  - manifest inconsistency
  - stale metadata
- `runtime/validation/reference/python/tests/test_negative_fixtures.py`
- `runtime/validation/reference/python/tests/README.md`

### Changed

- Python reference validator now:
  - compares body without front matter and H1;
  - detects near-duplicates by similarity;
  - reports literal newline issues by line;
  - validates manifest top-level areas;
  - validates status/version/date metadata;
  - supports optional baseline path.

### Preserved

- All v0.5.0 baseline files.
- All Canon, Knowledge Packs, Skills, Playbooks and Evolution Framework policies.
