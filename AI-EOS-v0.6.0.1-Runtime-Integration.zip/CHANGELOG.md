---
id: changelog
version: 0.6.0.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [adr-0023]
used_by: []
supersedes: null
---

# Changelog

## v0.6.0.1 — Runtime Integration

### Added

- YAML validation for Knowledge Pack manifests and Knowledge Registry.
- Specification Coverage Validator.
- Runtime integration tests for comparators, manifest path normalization and YAML validation.
- ADR-0023 — Runtime Integration Validation.

### Changed

- `ai_eos_validate.py` now imports and uses shared comparator utilities.
- Manifest validation now uses consistent normalized path comparison.
- Validation Engine now scans `.yaml` production artifacts.
- `validation-report.json` regenerated after final package changes.
- RELEASE_VALIDATION distinguishes presence from executable validation.

### Fixed

- Dead-code issue for `core/comparators.py`.
- Manifest validator false positives caused by trailing slash normalization.
- Knowledge Pack YAML artifacts being invisible to Validation Engine.
- Stale validation report in v0.6.0.

## v0.6.0 — Knowledge Pack Foundation

- Introduced Knowledge Pack Foundation.
