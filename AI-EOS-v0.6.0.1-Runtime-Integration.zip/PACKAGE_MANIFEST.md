---
id: package-manifest
version: 0.6.0.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [adr-0023, yaml-validation-spec, package-namespace-policy]
used_by: []
supersedes: null
---

# Package Manifest

## Release

AI-EOS v0.6.0.1 Runtime Integration

## Baseline

AI-EOS v0.6.0 Knowledge Pack Foundation.

## Entry Point

`AGENTS.md`

## Markdown Files

258

## YAML Files

4

## Python Files

9

## Top-Level Areas

- adapters/
- agents/
- architecture/
- canon/
- constitution/
- decision-trees/
- docs/
- evaluation/
- governance/
- harness/
- heuristics/
- knowledge/
- labs/
- multi-agent/
- playbooks/
- runtime/
- skills/
- templates/
- vision/

## Added Files

- architecture/adr/ADR-0023-runtime-integration-validation.md
- knowledge/PACKAGE_NAMESPACE_POLICY.md
- knowledge/package-identities/KP-ARCHITECTURE.md
- knowledge/package-identities/KP-DATABRICKS.md
- knowledge/package-identities/KP-SECURITY-PRINCIPLES.md
- knowledge/package-identities/KP-SECURITY.md
- runtime/validation/SPECIFICATION_COVERAGE_VALIDATOR.md
- runtime/validation/YAML_VALIDATION.md
- runtime/validation/reference/python/core/__pycache__/__init__.cpython-313.pyc
- runtime/validation/reference/python/core/__pycache__/comparators.cpython-313.pyc
- runtime/validation/reference/python/tests/runtime_integration/test_comparators_integration.py
- runtime/validation/reference/python/tests/runtime_integration/test_manifest_path_normalization.py
- runtime/validation/reference/python/tests/runtime_integration/test_yaml_validation.py

## Removed Files

None.
