"""AI-EOS reference validator v0.6.0.1."""
from __future__ import annotations
import argparse, json, re
from pathlib import Path

from path_utils import normalize_path, relative_path
from core.comparators import compare_paths, normalize_document_body, similarity

VALID_PACK_STATUSES = {"draft", "experimental", "validated", "stable", "deprecated", "archived"}
VALID_MATURITY = {"L0", "L1", "L2", "L3", "L4"}

def is_fixture(path: Path) -> bool:
    parts = set(path.parts)
    return "fixtures" in parts and "tests" in parts and "validation" in parts

def markdown_files(root: Path):
    return sorted(p for p in root.rglob("*.md") if not is_fixture(p))

def yaml_files(root: Path):
    return sorted(p for p in root.rglob("*.yaml") if not is_fixture(p))

def parse_front_matter(text: str):
    if not text.startswith("---"):
        return {}, text
    parts = text.split("---", 2)
    if len(parts) < 3:
        return {}, text
    meta = {}
    for line in parts[1].strip().splitlines():
        if ":" in line:
            k, v = line.split(":", 1)
            meta[k.strip()] = v.strip()
    return meta, parts[2].lstrip()

def parse_inline_list(value: str):
    if not value or value.strip() in {"[]", "null", "None"}:
        return []
    value = value.strip()
    if value.startswith("[") and value.endswith("]"):
        inner = value[1:-1].strip()
        return [x.strip().strip("'\"") for x in inner.split(",") if x.strip()]
    return [value.strip().strip("'\"")]

def simple_yaml_load(path: Path):
    data = {}
    current = None
    for raw in path.read_text(encoding="utf-8").splitlines():
        s = raw.strip()
        if not s or s.startswith("#"):
            continue
        if s.startswith("- ") and current:
            if not isinstance(data.get(current), list):
                data[current] = []
            data[current].append(s[2:].strip().strip("'\""))
        elif ":" in s:
            k, v = s.split(":", 1)
            k, v = k.strip(), v.strip()
            current = k
            if v == "":
                data[k] = []
            elif v.startswith("[") and v.endswith("]"):
                inner = v[1:-1].strip()
                data[k] = [x.strip().strip("'\"") for x in inner.split(",") if x.strip()] if inner else []
            else:
                data[k] = v.strip("'\"")
    return data

def finding(findings, validator_id, severity, message, path=None):
    findings.append({"validator_id": validator_id, "severity": severity, "message": message, "path": normalize_path(path) if path else None})

def validate_markdown(root: Path, findings):
    ids, dups, deps = {}, [], {}
    for p in markdown_files(root):
        rel = relative_path(p, root)
        meta, _ = parse_front_matter(p.read_text(encoding="utf-8"))
        idv = meta.get("id")
        if idv:
            if idv in ids:
                dups.append((idv, ids[idv], rel))
            ids[idv] = rel
            deps[idv] = parse_inline_list(meta.get("depends_on", ""))

    unresolved = []
    for src, ds in deps.items():
        for dep in ds:
            if dep and dep not in ids:
                unresolved.append((src, dep))

    for idv, a, b in dups:
        finding(findings, "markdown-metadata-validator", "HIGH", f"Duplicate Markdown id {idv}: {a} and {b}")
    for src, dep in unresolved:
        finding(findings, "markdown-dependency-validator", "HIGH", f"Unresolved Markdown dependency {dep}", src)

    return {"markdown_files": len(markdown_files(root)), "ids": len(ids), "duplicate_ids": len(dups), "unresolved_dependencies": len(unresolved)}

def validate_manifest(root: Path, findings, markdown_count: int):
    p = root / "PACKAGE_MANIFEST.md"
    result = {"declared_markdown_files": None, "actual_markdown_files": markdown_count, "top_level_missing": [], "top_level_nonexistent": []}
    if not p.exists():
        finding(findings, "manifest-validator", "HIGH", "PACKAGE_MANIFEST.md missing")
        return result
    text = p.read_text(encoding="utf-8")
    m = re.search(r"## Markdown Files\s+(\d+)", text)
    if m:
        result["declared_markdown_files"] = int(m.group(1))
        if result["declared_markdown_files"] != markdown_count:
            finding(findings, "manifest-validator", "MEDIUM", f"Markdown count mismatch: declared={result['declared_markdown_files']}, actual={markdown_count}", "PACKAGE_MANIFEST.md")

    listed = set()
    in_top = False
    for line in text.splitlines():
        if line.strip() == "## Top-Level Areas":
            in_top = True
            continue
        if in_top and line.strip().startswith("## "):
            break
        if in_top and line.strip().startswith("- "):
            listed.add(normalize_path(line.strip()[2:]))
    actual = {normalize_path(x.name) for x in root.iterdir() if x.is_dir()}
    if listed:
        result["top_level_missing"] = sorted(actual - listed)
        result["top_level_nonexistent"] = sorted(listed - actual)
        for x in result["top_level_missing"]:
            finding(findings, "manifest-validator", "LOW", f"Top-level area missing from manifest: {x}", "PACKAGE_MANIFEST.md")
        for x in result["top_level_nonexistent"]:
            finding(findings, "manifest-validator", "LOW", f"Manifest lists nonexistent top-level area: {x}", "PACKAGE_MANIFEST.md")
    # exercise shared comparator explicitly
    compare_paths("adapters/", "adapters")
    return result

def validate_yaml(root: Path, findings):
    required = {"id","name","version","owner","status","maturity","review_date","exports","requires","optional","conflicts","tags","depends_on","consumed_by"}
    packages, paths = {}, {}
    for p in yaml_files(root):
        rel = relative_path(p, root)
        data = simple_yaml_load(p)
        if p.name == "package.yaml":
            missing = sorted(required - set(data))
            if missing:
                finding(findings, "yaml-package-validator", "HIGH", f"Missing fields: {missing}", rel)
            pid = data.get("id")
            if pid:
                if pid in packages:
                    finding(findings, "yaml-package-validator", "HIGH", f"Duplicate package id {pid}", rel)
                packages[pid] = data
                paths[pid] = rel
            if data.get("status") and data.get("status") not in VALID_PACK_STATUSES:
                finding(findings, "yaml-package-validator", "MEDIUM", f"Invalid package status {data.get('status')}", rel)
            if data.get("maturity") and data.get("maturity") not in VALID_MATURITY:
                finding(findings, "yaml-package-validator", "MEDIUM", f"Invalid package maturity {data.get('maturity')}", rel)

    registry = root / "runtime/registry/knowledge_registry.yaml"
    entries = []
    if registry.exists():
        current = None
        for raw in registry.read_text(encoding="utf-8").splitlines():
            s = raw.strip()
            if s.startswith("- id:"):
                if current:
                    entries.append(current)
                current = {"id": s.split(":",1)[1].strip().strip("'\"")}
            elif current and s.startswith("path:"):
                current["path"] = s.split(":",1)[1].strip().strip("'\"")
        if current:
            entries.append(current)
        for e in entries:
            eid = e.get("id")
            epath = normalize_path(e.get("path",""))
            if eid not in packages:
                finding(findings, "yaml-registry-validator", "HIGH", f"Registry references unknown package id {eid}", "runtime/registry/knowledge_registry.yaml")
            if not (root / epath).exists():
                finding(findings, "yaml-registry-validator", "HIGH", f"Registry path missing: {epath}", "runtime/registry/knowledge_registry.yaml")
            elif eid in paths and not compare_paths(epath, paths[eid]):
                finding(findings, "yaml-registry-validator", "MEDIUM", f"Registry path mismatch for {eid}: {epath} vs {paths[eid]}", "runtime/registry/knowledge_registry.yaml")
    else:
        finding(findings, "yaml-registry-validator", "HIGH", "knowledge_registry.yaml missing")

    canon_deps = {f"canon-{x.name}" for x in (root/"canon").glob("*") if x.is_dir()} if (root/"canon").exists() else set()
    unresolved = []
    for pid, data in packages.items():
        for req in data.get("requires", []):
            if req not in packages and req not in canon_deps:
                unresolved.append((pid, req))
                finding(findings, "yaml-dependency-validator", "MEDIUM", f"Unresolved package requirement {req}", paths.get(pid))
    return {"yaml_files": len(yaml_files(root)), "packages": len(packages), "registry_entries": len(entries), "unresolved_requires": len(unresolved)}

def validate_spec_coverage(root: Path, findings):
    specs = [
        "knowledge/KNOWLEDGE_PACK_SPEC.md",
        "runtime/registry/KNOWLEDGE_REGISTRY.md",
        "runtime/capability/CAPABILITY_MODEL.md",
        "runtime/dependency/KNOWLEDGE_DEPENDENCY_GRAPH.md",
        "runtime/contracts/KNOWLEDGE_RUNTIME_CONTRACT.md",
        "runtime/context/CONTEXT_BUILDER.md",
    ]
    missing = [x for x in specs if not (root/x).exists()]
    for x in missing:
        finding(findings, "specification-coverage-validator", "LOW", f"Missing specification {x}", x)
    return {"specifications_tracked": len(specs), "specifications_present": len(specs)-len(missing)}

def run(root: str | Path):
    root = Path(root).resolve()
    findings = []
    md = validate_markdown(root, findings)
    manifest = validate_manifest(root, findings, md["markdown_files"])
    yml = validate_yaml(root, findings)
    spec = validate_spec_coverage(root, findings)

    high = sum(1 for f in findings if f["severity"] == "HIGH")
    medium = sum(1 for f in findings if f["severity"] == "MEDIUM")
    low = sum(1 for f in findings if f["severity"] == "LOW")
    status = "FAIL" if high else ("WARNING" if findings else "PASS")
    recommendation = "REJECT" if status == "FAIL" else ("ACCEPT_WITH_RECOMMENDATIONS" if status == "WARNING" else "ACCEPT")

    validators = [
        {"validator_id": "markdown-metadata-validator", "status": "PASS" if md["duplicate_ids"] == 0 else "FAIL", "metrics": md},
        {"validator_id": "markdown-dependency-validator", "status": "PASS" if md["unresolved_dependencies"] == 0 else "FAIL"},
        {"validator_id": "manifest-validator", "status": "WARNING" if manifest["top_level_missing"] or manifest["top_level_nonexistent"] else "PASS", "metrics": manifest},
        {"validator_id": "yaml-package-validator", "status": "PASS" if yml["packages"] else "WARNING", "metrics": yml},
        {"validator_id": "yaml-registry-validator", "status": "PASS" if yml["registry_entries"] else "WARNING"},
        {"validator_id": "yaml-dependency-validator", "status": "PASS" if yml["unresolved_requires"] == 0 else "WARNING"},
        {"validator_id": "specification-coverage-validator", "status": "PASS" if spec["specifications_present"] == spec["specifications_tracked"] else "WARNING", "metrics": spec},
    ]

    return {
        "release": "AI-EOS",
        "validation_engine": "reference-python",
        "version": "0.6.0.1",
        "summary": {
            "status": status,
            "recommendation": recommendation,
            "markdown_files": md["markdown_files"],
            "yaml_files": yml["yaml_files"],
            "findings": len(findings),
            "high": high,
            "medium": medium,
            "low": low
        },
        "validators": validators,
        "findings": findings,
        "recommendation": recommendation,
    }

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("root", nargs="?", default=".")
    parser.add_argument("--output", default="validation-report.json")
    args = parser.parse_args()
    report = run(args.root)
    Path(args.output).write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(report["summary"], indent=2, ensure_ascii=False))
    return 1 if report["summary"]["status"] == "FAIL" else 0

if __name__ == "__main__":
    raise SystemExit(main())
