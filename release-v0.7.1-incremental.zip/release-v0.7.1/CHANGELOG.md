## v0.7.1
- Introduce Consensus Engine MVP
- Add provider abstraction
- Add benchmark integration
- Add CGI/CCI metrics
