v0.7.0 -> v0.7.1 Consensus Engine MVP -> v0.7.2 Consensus Optimization -> v0.8.0 Divergence Engine
