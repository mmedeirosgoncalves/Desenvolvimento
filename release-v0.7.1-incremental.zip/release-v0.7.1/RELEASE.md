# AI-EOS Release v0.7.1

Codename: Consensus Engine MVP

This is an incremental release specification built on top of v0.7.0.
