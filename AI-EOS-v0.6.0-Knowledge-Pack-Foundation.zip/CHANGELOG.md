---
id: changelog
version: 0.6.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [adr-0018, adr-0019, adr-0020, adr-0021, adr-0022]
used_by: []
supersedes: null
---

# Changelog

## v0.6.0 — Knowledge Pack Foundation

### Added

- Maintenance Queue.
- Validation Comparison Contract.
- Shared comparator utility reference implementation.
- Knowledge Pack Specification.
- Knowledge Lifecycle.
- Knowledge Boundaries.
- Knowledge Registry.
- Capability Model.
- Knowledge Dependency Graph.
- Context Model.
- Context Builder.
- Runtime Contracts.
- Knowledge Validators.
- Initial `package.yaml` files for security, architecture and databricks packs.
- ADR-0018 — Canonical Metadata Format.
- ADR-0019 — Knowledge Pack Architecture.
- ADR-0020 — Knowledge Dependency Graph.
- ADR-0021 — Capability Resolution.
- ADR-0022 — Knowledge Runtime Contract.

### Changed

- `AGENTS.md` updated with Knowledge Runtime rule.
- `KNOWLEDGE_MAP.md` updated to map packs to capabilities.
- Roadmap updated for Knowledge Pack Runtime progression.

### Preserved

- All v0.5.2 baseline files.
- Validation Engine.
- Canon.
- Skills.
- Playbooks.
- Quality Gates.
