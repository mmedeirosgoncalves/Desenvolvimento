---
id: agents-entry-point
version: 0.3.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [project-charter, vision, system-architecture, target-architecture, engineering-evolution-policy, review-loop]
used_by: [devin-bootstrap]
supersedes: null
---

# AI-EOS Agent Entry Point

This is the single authoritative entry point for AI agents using AI-EOS.

## Bootstrap Order

1. `README.md`
2. `docs/PROJECT_CHARTER.md`
3. `vision/AI_EOS_VISION.md`
4. `constitution/AI_EOS_CONSTITUTION.md`
5. `canon/CANON_MAP.md`
5. `architecture/SYSTEM_ARCHITECTURE.md`
6. `architecture/TARGET_ARCHITECTURE.md`
7. `architecture/ARCHITECTURE_MODEL_RECONCILIATION.md`
8. `knowledge/KNOWLEDGE_CORE.md`
9. `runtime/RUNTIME_OVERVIEW.md`
10. `runtime/routing/MULTI_AGENT_TRIGGER_POLICY.md`
11. `runtime/quality-gates/QUALITY_GATES.md`
12. `governance/ENGINEERING_EVOLUTION_POLICY.md`
13. `evaluation/REVIEW_LOOP.md`
14. `adapters/devin/DEVIN_BOOTSTRAP_PROMPT.md`

## Operating Rule

For every task:

1. classify the task
2. identify the relevant AI-EOS layer
3. assemble context
4. identify relevant Canon, Knowledge Packs, Skills and Playbooks
5. consult routing and trigger policies
6. decide single-agent or multi-agent mode
7. execute incrementally
8. apply quality gates, including QG-009 Dependency Integrity for releases
9. report assumptions, risks, trade-offs and validation results

## Release Evolution Rule

AI-EOS evolves only by incremental merge.

Never reconstruct the project from scratch.

Never replace the operational baseline with a partial package.

Before producing any release:

1. identify the current baseline
2. inventory existing components
3. preserve operational capabilities
4. document structural changes through ADRs
5. apply regression checks
6. update CHANGELOG, ROADMAP and PACKAGE_MANIFEST
7. provide Migration Guide when compatibility changes

## Path Convention

All paths are relative to the directory containing this `AGENTS.md`.

Recommended installation path:

```text
.ai/AI-EOS/
```

## Architectural Rule

AI-EOS is organized around these layers:

```text
Kernel / Constitution
Canon
Knowledge
Skills
Runtime
Agents / Multi-Agent
Governance
Evaluation
Adapters
Labs
```

No component should be added unless its layer, purpose, dependencies, consumers and roadmap are clear.

## For Canon-related tasks

Load the relevant Canon domain, then the related Knowledge Pack, then the applicable Skill.

Do not duplicate Canon content inside Skills.


## Canon Stabilization Rule

For Canon-related work:

- use `canon/DECISION_RULES.md` as the canonical decision rules source;
- use `canon/ROADMAP.md` as the canonical Canon roadmap;
- do not duplicate Canon-wide rules inside domain documents;
- apply QG-004 Documentation and QG-009 Dependency Integrity before release.


## Validation Engine Rule

For release work, load:

- `runtime/validation/VALIDATION_ENGINE.md`
- `runtime/validation/VALIDATION_REGISTRY.md`
- `runtime/validation/QUALITY_GATE_MAPPING.md`

Before final delivery, run or simulate the Validation Engine and report:

- QG-009 Dependency Integrity
- QG-004 Documentation
- QG-001 Architecture when architecture is affected


## Validator Hardening Rule

For release work, run:

```bash
python runtime/validation/reference/python/ai_eos_validate.py .
python runtime/validation/reference/python/tests/test_negative_fixtures.py
```

Treat QG-009 failures as blocking.

Treat QG-004 content quality findings as warnings unless they indicate broken rendering or undocumented duplication.


## Cross-Platform Validation Rule

Validators must use canonical POSIX-style paths internally.

For validation release work, run:

```bash
python runtime/validation/reference/python/ai_eos_validate.py .
python runtime/validation/reference/python/tests/test_negative_fixtures.py
python runtime/validation/reference/python/tests/reproducibility/test_path_normalization.py
```


## Knowledge Runtime Rule

For Knowledge-related tasks, load:

- `knowledge/KNOWLEDGE_PACK_SPEC.md`
- `runtime/registry/KNOWLEDGE_REGISTRY.md`
- `runtime/capability/CAPABILITY_MODEL.md`
- `runtime/dependency/KNOWLEDGE_DEPENDENCY_GRAPH.md`
- `runtime/context/CONTEXT_BUILDER.md`

Resolve Knowledge Packs through declared capabilities and package metadata.

Do not duplicate Canon inside Skills or Knowledge Packs.
