---
id: package-manifest
version: 0.6.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [knowledge-pack-spec, qg-009-dependency-integrity]
used_by: []
supersedes: null
---

# Package Manifest

## Release

AI-EOS v0.6.0 Knowledge Pack Foundation

## Baseline

AI-EOS v0.5.2 Cross-Platform Validation.

## Purpose

This release introduces Knowledge Packs as the official modular knowledge unit.

## Entry Point

`AGENTS.md`

## Markdown Files

250

## Test Fixture Markdown Files

9

## Top-Level Areas

- adapters/
- agents/
- architecture/
- canon/
- constitution/
- decision-trees/
- docs/
- evaluation/
- governance/
- harness/
- heuristics/
- knowledge/
- labs/
- multi-agent/
- playbooks/
- runtime/
- skills/
- templates/
- vision/

## Added Files

- architecture/adr/ADR-0018-canonical-metadata-format.md
- architecture/adr/ADR-0019-knowledge-pack-architecture.md
- architecture/adr/ADR-0020-knowledge-dependency-graph.md
- architecture/adr/ADR-0021-capability-resolution.md
- architecture/adr/ADR-0022-knowledge-runtime-contract.md
- governance/MAINTENANCE_QUEUE.md
- knowledge/KNOWLEDGE_BOUNDARIES.md
- knowledge/KNOWLEDGE_LIFECYCLE.md
- knowledge/KNOWLEDGE_PACK_SPEC.md
- knowledge/README.md
- knowledge/packs/architecture/package.yaml
- knowledge/packs/databricks/package.yaml
- knowledge/packs/security/README.md
- knowledge/packs/security/package.yaml
- runtime/EXTENSIBILITY_GUIDE.md
- runtime/capability/CAPABILITY_MODEL.md
- runtime/context/CONTEXT_BUILDER.md
- runtime/context/CONTEXT_MODEL.md
- runtime/contracts/CONTEXT_CONTRACT.md
- runtime/contracts/KNOWLEDGE_RUNTIME_CONTRACT.md
- runtime/contracts/PACKAGE_CONTRACT.md
- runtime/dependency/KNOWLEDGE_DEPENDENCY_GRAPH.md
- runtime/registry/KNOWLEDGE_REGISTRY.md
- runtime/registry/knowledge_registry.yaml
- runtime/validation/COMPARISON_CONTRACT.md
- runtime/validation/KNOWLEDGE_VALIDATORS.md
- runtime/validation/reference/python/core/__init__.py
- runtime/validation/reference/python/core/comparators.py

## Validation Summary

- Baseline files removed: 0
- Duplicate ids: 0
- Unresolved dependencies: 0
- Missing bootstrap references: 0
- Reference validator status: WARNING
- Reference validator recommendation: ACCEPT_WITH_RECOMMENDATIONS

## Status

Recommended for independent review.
