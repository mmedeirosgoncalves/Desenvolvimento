"""Shared comparators for AI-EOS validators."""

from __future__ import annotations

import re
import hashlib
from difflib import SequenceMatcher

try:
    from path_utils import normalize_path
except ImportError:
    from ..path_utils import normalize_path


def compare_paths(a: str, b: str) -> bool:
    """Compare paths after canonical normalization."""
    return normalize_path(a) == normalize_path(b)


def normalize_document_body(text: str, remove_h1: bool = True) -> str:
    """Normalize Markdown body for deterministic comparison."""
    if text.startswith("---"):
        parts = text.split("---", 2)
        if len(parts) == 3:
            text = parts[2].lstrip()

    lines = text.splitlines()
    if remove_h1:
        lines = [line for line in lines if not line.strip().startswith("# ")]
    body = "\n".join(lines)
    body = re.sub(r"`[^`]+`", "", body)
    return re.sub(r"\s+", " ", body.strip().lower())


def document_hash(text: str) -> str:
    """Return a stable hash for normalized Markdown content."""
    return hashlib.sha256(normalize_document_body(text).encode("utf-8")).hexdigest()


def similarity(a: str, b: str) -> float:
    """Return deterministic similarity score for normalized Markdown content."""
    return SequenceMatcher(None, normalize_document_body(a), normalize_document_body(b)).ratio()
