---
id: knowledge-map
version: 0.6.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [knowledge-pack-spec, capability-model]
used_by: []
supersedes: null
---

# Knowledge Map

## Purpose

Map Canon domains to Knowledge Packs, capabilities, Skills and Playbooks.

## Knowledge Packs

| Pack | Package ID | Capabilities | Primary Consumers |
|---|---|---|---|
| Security | kp-security | security-review, owasp-risk-evaluation, secure-design | security-review |
| Architecture | kp-architecture | architecture-review, system-design, adr-support | architecture-review |
| Databricks | kp-databricks | databricks-engineering, lakehouse-design, spark-delta | databricks-engineering |

## Relationship

```text
Canon -> Knowledge Pack -> Capability -> Skill / Agent / Runtime
```

## Rule

Knowledge Packs adapt Canon. They must not duplicate Canon wholesale.
