---
id: roadmap
version: 0.6.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [knowledge-runtime-contract]
used_by: []
supersedes: null
---

# AI-EOS Roadmap

## v0.6.0 — Knowledge Pack Foundation

- Introduce Knowledge Pack Specification.
- Introduce Knowledge Registry.
- Introduce Capability Model.
- Introduce Knowledge Dependency Graph.
- Introduce Context Builder.
- Introduce Knowledge Runtime Contracts.

## v0.6.1 — Knowledge Pack Validator Implementation

- Implement package metadata validator.
- Implement registry consistency validator.
- Implement dependency graph validator.
- Add negative fixtures for invalid packs.

## v0.7 — Knowledge Pack Expansion

- Mature 3 to 5 Knowledge Packs.
- Add examples.
- Add decision trees.
- Add checklists.
- Add anti-patterns.
- Align Knowledge Packs with Canon.

## v0.8 — Skill Runtime

- Refactor Skills as application mechanisms.
- Add skill dependency resolution.
- Add skill execution contracts.

## v0.9 — Agent Runtime

- Specialist agent orchestration.
- Consensus protocol.
- Conflict resolution.
- Multi-agent reporting.

## v1.0 — Stable AI-EOS

- Stable architecture.
- Mature Canon.
- Mature Knowledge Packs.
- Mature Skills.
- Runtime protocols.
- Review Engine.
- Vendor adapters.
