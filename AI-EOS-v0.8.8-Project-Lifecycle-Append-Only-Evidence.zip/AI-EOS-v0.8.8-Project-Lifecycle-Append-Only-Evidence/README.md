---
id: readme
version: 0.8.8
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: true
depends_on: [adr-0043, adr-0044]
used_by: []
supersedes: null
---

# AI-EOS v0.8.8 — Project Lifecycle & Append-Only Evidence

This release matures the v0.8.7 Project Control Plane into an operational lifecycle layer.

## Added

- `.ai-eos/control-plane/` as external state location.
- Append-only JSONL evidence ledger.
- Hash-chain verification.
- `ProjectDefinition`, `Milestone`, `RunSession`, `DecisionLog`.
- Lifecycle CLI commands.
- `control-plane-lifecycle-validator`.

## Commands

```bash
python -m runtime.control_plane --root . bootstrap
python -m runtime.control_plane --root . verify-ledger
```
