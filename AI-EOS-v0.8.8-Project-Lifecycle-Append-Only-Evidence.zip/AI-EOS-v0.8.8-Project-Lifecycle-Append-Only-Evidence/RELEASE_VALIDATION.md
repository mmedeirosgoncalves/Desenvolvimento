---
id: release-validation
version: 0.8.8
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: true
depends_on: [adr-0043, adr-0044]
used_by: []
supersedes: null
---

# Release Validation — v0.8.8

Required commands:

```bash
python runtime/validation/unified_validation.py . validation-report.json
python -m runtime.control_plane --root . bootstrap
python -m runtime.control_plane --root . verify-ledger
```


## Executed in package generation

```text
control_plane_bootstrap_rc=0
ledger_verify={
  "status": "PASS",
  "records": 6,
  "last_hash": "663fe53b61e974cae23b9974ece229c13339d2245cfa327621595b09eafac6ee"
}
unified_validation_status=WARNING
unified_validation_recommendation=ACCEPT_WITH_RECOMMENDATIONS
findings=1
```

Global legacy test runner was not executed during packaging because prior runs exceeded the artifact timeout. The release includes targeted lifecycle tests under `runtime/validation/reference/python/tests/control_plane/`.
