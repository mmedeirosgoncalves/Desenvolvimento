---
id: adr-0041
version: 0.8.5
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: false
depends_on: [adr-0039, adr-0040]
used_by: []
supersedes: null
---

# ADR-0041 — Provider Layer Consolidation

Decision: `runtime/providers/` is the canonical provider layer.

Deprecated compatibility layers:
- `runtime/devin/` discovery-only components.
- duplicated provider contracts under `runtime/multi_ai/`.

Migration rule:
- orchestration imports provider contracts only from `runtime.providers`;
- legacy modules may remain as adapters, but must delegate to canonical providers;
- any new provider must implement `ProviderContract`.
