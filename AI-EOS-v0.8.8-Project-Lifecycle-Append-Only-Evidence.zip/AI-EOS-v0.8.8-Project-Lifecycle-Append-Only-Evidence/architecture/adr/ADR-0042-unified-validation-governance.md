---
id: adr-0042
version: 0.8.6
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: false
depends_on: [adr-0025, adr-0041]
used_by: []
supersedes: null
---

# ADR-0042 — Unified Validation Governance

## Decision

`runtime/validation/unified_validation.py` is the single source of truth for release validation.

The final release status must be the worst status across:

- runtime integration validation;
- runtime callgraph validation;
- runtime coverage validation;
- strict JSON validation;
- reference validator output;
- document freshness validation;
- validation authenticity check.

## Rule

A release cannot report `PASS` while any included validator reports `WARNING` or `FAIL`.

## Rationale

Earlier releases allowed partitioned truthfulness: runtime validation could report `PASS` while the reference validator still reported `WARNING`. This creates ambiguous release state and undermines reproducibility.

## External-agent nomenclature

References to external comparative systems must use neutral nomenclature such as `External Agent System` or `external audit`. Project nicknames are not release taxonomy.
