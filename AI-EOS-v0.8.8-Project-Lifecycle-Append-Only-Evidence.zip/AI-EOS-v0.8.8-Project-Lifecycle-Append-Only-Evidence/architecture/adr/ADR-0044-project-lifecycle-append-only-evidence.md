---
id: adr-0044
version: 0.8.8
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: false
depends_on: [adr-0043]
used_by: []
supersedes: null
---

# ADR-0044 — Project Lifecycle and Append-Only Evidence

## Decision

Move control-plane state out of `runtime/` and introduce lifecycle objects plus append-only JSONL evidence with hash chaining.

## Rationale

The v0.8.7 audit identified mutable state inside runtime, a mutable JSON ledger, and lack of project/run/decision lifecycle.

## Consequences

Runtime code remains portable; evidence integrity can be verified; project work now has owners, milestones, runs and decisions.
