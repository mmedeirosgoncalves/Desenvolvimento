---
id: adr-0037
version: 0.8.3
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: false
depends_on: [adr-0036]
used_by: []
supersedes: null
---

# ADR-0037 — Adaptive Multi-Agent Pipeline

## Status

Accepted.

## Context

The External Agent System package and its critique of AI-EOS v0.8.0 expose useful operational patterns: dynamic roster, role-based council, workspace isolation, adaptive routing, outcome memory and concrete trigger policies.

## Decision

AI-EOS absorbs these patterns natively while preserving ProviderContract, ConsensusEngine, quality gates and audit trail.

```text
TaskProfile -> AdaptiveRouter -> ProviderRegistry -> isolated provider execution
-> ConsensusEngine -> HumanReviewGate -> Codegen -> QualityGates -> LearningRegistry
```

## Non-goals

- Do not import External Agent System code.
- Do not use a fixed chairman as source of truth.
- Do not allow direct writes to canonical repository during consensus.
