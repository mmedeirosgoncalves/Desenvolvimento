---
id: adr-0043
version: 0.8.8
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: false
depends_on: [adr-0042]
used_by: []
supersedes: null
---

# ADR-0043 — Project Lifecycle & Append-Only Evidence

## Decision

Introduce a Project Control Plane with task packets, evidence ledger, skill registry and agent definitions.

## Rationale

The v0.8.6 audit showed that unified validation is necessary but not sufficient. The system needs a control layer that makes work units, evidence, skills and agent permissions explicit before runtime execution.

## Consequences

- Releases can now be audited as controlled work, not only as code snapshots.
- Skills become structured assets with triggers, inputs, outputs and risks.
- Agent behavior is bounded by explicit allowed skills and denied actions.
- Evidence is recorded with hashes.

## Non-goals

This release does not implement real provider execution, long-term memory or adaptive learning. It creates the control-plane foundation those features need.
