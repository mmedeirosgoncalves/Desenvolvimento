---
id: external agent system-audit
version: 0.8.3
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: true
depends_on: [adr-0037]
used_by: []
supersedes: null
---

# External Agent System Audit

## Source

Uploaded package: `external agent system-skill 3.zip`

```text
sha256: 1bb2b549af3fbd8850fc6a4fbd5c32ecabab991923a4338bae45115df4507438
```

## Inventory

```json
{
  "package": "external agent system-skill 3.zip",
  "files": 11,
  "markdown": 8,
  "python": 1,
  "json": 0,
  "sha256": "1bb2b549af3fbd8850fc6a4fbd5c32ecabab991923a4338bae45115df4507438",
  "hits": {
    "dynamic_roster": [
      "external agent system/INSTALL.md",
      "external agent system/agents/external agent system-gemini/AGENT.md",
      "external agent system/agents/external agent system-gpt/AGENT.md",
      "external agent system/agents/external agent system-opus/AGENT.md",
      "external agent system/agents/external agent system-swe/AGENT.md",
      "external agent system/skills/external agent system/README.md",
      "external agent system/skills/external agent system/SKILL.md",
      "external agent system/skills/external agent system/consolidar.md",
      "external agent system/skills/external agent system/consolidar.py"
    ],
    "isolation": [
      "external agent system/agents/external agent system-gemini/AGENT.md",
      "external agent system/agents/external agent system-gpt/AGENT.md",
      "external agent system/agents/external agent system-opus/AGENT.md",
      "external agent system/agents/external agent system-swe/AGENT.md",
      "external agent system/skills/external agent system/README.md",
      "external agent system/skills/external agent system/consolidar.md",
      "external agent system/skills/external agent system/consolidar.py"
    ],
    "consolidation": [
      "external agent system/INSTALL.md",
      "external agent system/skills/external agent system/README.md",
      "external agent system/skills/external agent system/SKILL.md",
      "external agent system/skills/external agent system/consolidar.md",
      "external agent system/skills/external agent system/consolidar.py"
    ],
    "routing": [
      "external agent system/INSTALL.md",
      "external agent system/agents/external agent system-gemini/AGENT.md",
      "external agent system/agents/external agent system-gpt/AGENT.md",
      "external agent system/agents/external agent system-opus/AGENT.md",
      "external agent system/agents/external agent system-swe/AGENT.md",
      "external agent system/skills/external agent system/README.md",
      "external agent system/skills/external agent system/SKILL.md",
      "external agent system/skills/external agent system/consolidar.md",
      "external agent system/skills/external agent system/consolidar.py"
    ],
    "security": [
      "external agent system/agents/external agent system-gemini/AGENT.md",
      "external agent system/agents/external agent system-gpt/AGENT.md",
      "external agent system/agents/external agent system-opus/AGENT.md",
      "external agent system/agents/external agent system-swe/AGENT.md",
      "external agent system/skills/external agent system/README.md",
      "external agent system/skills/external agent system/SKILL.md",
      "external agent system/skills/external agent system/consolidar.md",
      "external agent system/skills/external agent system/consolidar.py"
    ],
    "memory": [
      "external agent system/INSTALL.md",
      "external agent system/skills/external agent system/SKILL.md",
      "external agent system/skills/external agent system/consolidar.md",
      "external agent system/skills/external agent system/consolidar.py"
    ]
  }
}
```

## What AI-EOS should absorb

1. Dynamic roster of models/agents.
2. Provider decoupled from model.
3. Role-based council instead of fixed LLM list.
4. Isolated workspaces per agent.
5. Separate artifacts per agent before consolidation.
6. Adaptive routing by difficulty and risk.
7. Outcome history by task type.
8. Trigger policies and templates as first-class artifacts.

## What AI-EOS should not copy

1. Fixed chairman as source of truth.
2. Direct agent writes to the canonical repository.
3. Devin-specific skill coupling.
4. Peer review as replacement for structured consensus.

## External critique

The critique of v0.8.0 was useful: it correctly identified overclaiming around “runtime” maturity. Later releases added executable runtime pieces; v0.8.3 adds the missing adaptive pipeline primitives.
