---
id: quality-gates
version: 0.7.3
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-07
review_date: 2026-10-06
depends_on: []
used_by: []
supersedes: null
---

# Quality Gates

Each task must state which gates were applied.

## Status Values

- PASS
- FAIL
- NOT_APPLICABLE
- NOT_VERIFIED

## Gates

- QG-001 Architecture
- QG-002 Security
- QG-003 Tests
- QG-004 Documentation
- QG-005 Observability
- QG-006 Data Integrity
- QG-007 Legacy Compatibility
- QG-008 Deployment / Rollback
- QG-009 Dependency Integrity
- QG-010 Independent Execution
- QG-011 Consensus Metrics
- QG-012 Experiment Reproducibility
- QG-013 Human Decision Required
- QG-014 Evidence Completeness
- QG-015 Consensus Execution Entrypoint

- QG-016 Multi-AI Runtime Foundation

- QG-017 Devin AI Discovery

- QG-018 Devin CLI Provider

- QG-019 Adaptive Routing
- QG-020 Workspace Isolation
- QG-021 Learning Registry
- QG-020 Runtime Integration
- QG-021 Validation Authenticity
- QG-022 Runtime Coverage
- QG-023 Runtime Call Graph
- QG-024 Provider Availability
- QG-025 Validation Truthfulness
- QG-026 Provider Layer Consolidation
- QG-027 Unified Validation Governance
- QG-028 Document Freshness
- QG-029 Project Control Plane
- QG-030 Evidence Ledger Integrity
- QG-031 Skill Registry Completeness
- QG-032 Project Lifecycle Integrity
- QG-033 Append-Only Evidence Hash Chain
- QG-034 Runtime State Separation