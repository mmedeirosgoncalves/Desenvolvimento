from __future__ import annotations
import ast, json
from pathlib import Path
from typing import Any

REQUIRED_RUNTIME_TOUCHPOINTS = {
    "AdaptiveRouting": {"module": "runtime.multi_ai.adaptive_routing", "symbols": ["select_agents", "AgentProfile", "TaskProfile"]},
    "WorkspaceIsolation": {"module": "runtime.multi_ai.workspace_isolation", "symbols": ["create_agent_workspace"]},
    "LearningRegistry": {"module": "runtime.multi_ai.learning_registry", "symbols": ["append_outcome", "ProviderOutcome"]},
    "ProviderRegistry": {"module": "runtime.providers.provider_registry", "symbols": ["ProviderRegistry"]},
    "ProviderContract": {"module": "runtime.providers.provider_contract", "symbols": ["ProviderRequest", "ProviderResponse"]},
    "RuntimeOrchestrator": {"module": "runtime.orchestrator.orchestrator", "symbols": ["run_task"]},
    "DevinCliProvider": {"module": "runtime.providers.devin_cli_provider", "symbols": ["DevinCliProvider"]},
}

def _module_to_path(root: Path, module: str) -> Path:
    return root.joinpath(*module.split(".")).with_suffix(".py")

def _defined_symbols(path: Path) -> set[str]:
    if not path.exists():
        return set()
    try:
        tree = ast.parse(path.read_text(encoding="utf-8"))
    except SyntaxError:
        return set()
    return {node.name for node in tree.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))}

def _used_symbols(root: Path) -> set[str]:
    out: set[str] = set()
    for path in root.rglob("*.py"):
        if "__pycache__" in path.parts:
            continue
        try:
            tree = ast.parse(path.read_text(encoding="utf-8"))
        except SyntaxError:
            continue
        for node in ast.walk(tree):
            if isinstance(node, ast.Name):
                out.add(node.id)
            elif isinstance(node, ast.Attribute):
                out.add(node.attr)
    return out

def analyze(root: str = ".") -> dict[str, Any]:
    base = Path(root).resolve()
    used = _used_symbols(base)
    details, missing = [], []
    for label, spec in REQUIRED_RUNTIME_TOUCHPOINTS.items():
        path = _module_to_path(base, spec["module"])
        defined = _defined_symbols(path)
        symbols = set(spec["symbols"])
        defined_ok = symbols.intersection(defined)
        used_ok = symbols.intersection(used)
        status = "PASS" if path.exists() and defined_ok and used_ok else "FAIL"
        if status != "PASS":
            missing.append(label)
        details.append({"label": label, "module": spec["module"], "exists": path.exists(), "defined_symbols": sorted(defined_ok), "used_symbols": sorted(used_ok), "status": status})
    coverage = (len(REQUIRED_RUNTIME_TOUCHPOINTS) - len(missing)) / len(REQUIRED_RUNTIME_TOUCHPOINTS)
    return {"method": "ast_definition_and_usage", "required_touchpoints": len(REQUIRED_RUNTIME_TOUCHPOINTS), "covered_touchpoints": len(REQUIRED_RUNTIME_TOUCHPOINTS) - len(missing), "missing_touchpoints": missing, "runtime_coverage": coverage, "coverage_percent": round(coverage * 100, 2), "threshold_percent": 95.0, "status": "PASS" if coverage >= 0.95 and not missing else "FAIL", "details": details}

def write_coverage(path: str, root: str = ".") -> dict[str, Any]:
    data = analyze(root)
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, indent=2, sort_keys=True, allow_nan=False), encoding="utf-8")
    return data

if __name__ == "__main__":
    import sys
    write_coverage(sys.argv[1] if len(sys.argv) > 1 else "reports/runtime-coverage.json", sys.argv[2] if len(sys.argv) > 2 else ".")
