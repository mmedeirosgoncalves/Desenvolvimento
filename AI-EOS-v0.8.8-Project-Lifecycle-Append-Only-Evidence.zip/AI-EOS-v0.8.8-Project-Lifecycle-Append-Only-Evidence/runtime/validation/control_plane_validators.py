from __future__ import annotations
import json, subprocess, sys, tempfile
from pathlib import Path

def validate_control_plane(root: str | Path = ".") -> dict:
    root = Path(root).resolve()
    required = [
        "runtime/control_plane/models.py",
        "runtime/control_plane/control_plane.py",
        "runtime/control_plane/ledger.py",
        "runtime/control_plane/registry.py",
        "runtime/control_plane/PROJECT_LIFECYCLE.md",
        "runtime/control_plane/EVIDENCE_LEDGER.md",
    ]
    missing = [p for p in required if not (root / p).exists()]
    if missing:
        return {"validator_id": "control-plane-lifecycle-validator", "status": "FAIL", "missing": missing}
    with tempfile.TemporaryDirectory() as td:
        proc = subprocess.run([sys.executable, "-m", "runtime.control_plane", "--root", td, "bootstrap"], cwd=str(root), capture_output=True, text=True, timeout=30)
        if proc.returncode != 0:
            return {"validator_id": "control-plane-lifecycle-validator", "status": "FAIL", "stderr": proc.stderr, "stdout": proc.stdout}
        payload = json.loads(proc.stdout)
        state_path = Path(payload["state_path"])
        ok = (
            payload.get("status") == "PASS"
            and payload.get("skills", 0) >= 4
            and payload.get("agents", 0) >= 2
            and payload.get("evidence_records", 0) >= 5
            and payload.get("ledger_chain", {}).get("status") == "PASS"
            and ".ai-eos" in str(state_path)
        )
        return {"validator_id": "control-plane-lifecycle-validator", "status": "PASS" if ok else "WARNING", "metrics": payload}
