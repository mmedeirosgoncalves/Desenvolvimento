from __future__ import annotations
import json, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from runtime.validation.unified_validation import build_unified_report

def build(root: str = ".", out: str = "validation-report.json") -> dict:
    return build_unified_report(root, out)

if __name__ == "__main__":
    root = sys.argv[1] if len(sys.argv) > 1 else "."
    out = sys.argv[2] if len(sys.argv) > 2 else "validation-report.json"
    print(json.dumps(build(root, out), indent=2, allow_nan=False))
