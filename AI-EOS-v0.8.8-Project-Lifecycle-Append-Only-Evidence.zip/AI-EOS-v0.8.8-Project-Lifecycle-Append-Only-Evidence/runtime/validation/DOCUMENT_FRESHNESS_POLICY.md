---
id: document-freshness-policy
version: 0.8.6
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: false
depends_on: [adr-0042]
used_by: []
supersedes: null
---

# Document Freshness Policy

Release documents that declare `release_document: true` must either:

1. match the current `VERSION`; or
2. be explicitly marked historical / superseded.

Deprecated project nicknames must not appear in release documents. Use neutral terms:

- `External Agent System`;
- `external audit`;
- `comparative agent pipeline`.

This avoids embedding private or informal nomenclature into public project artifacts.
