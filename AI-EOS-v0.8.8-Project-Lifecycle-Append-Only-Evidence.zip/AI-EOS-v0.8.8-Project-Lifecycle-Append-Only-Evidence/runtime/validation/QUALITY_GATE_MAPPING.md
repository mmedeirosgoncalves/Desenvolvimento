---
id: quality-gate-mapping
version: 0.7.3
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-07
review_date: 2026-10-06
depends_on: [validator-registry, quality-gates]
used_by: []
supersedes: null
---

# Quality Gate Mapping

## QG-009 Dependency Integrity

Validators:

- frontmatter-validator
- dependency-graph-validator
- bootstrap-validator
- manifest-validator

Automation level:

- L2

## QG-004 Documentation

Validators:

- markdown-render-validator
- content-duplication-validator
- canon-structure-validator
- version-consistency-validator

Automation level:

- L1

## QG-001 Architecture

Validators:

- canon-structure-validator

Automation level:

- L0/L1

## Rule

A Quality Gate may depend on multiple Validators.

A Validator may support multiple Quality Gates.


## QG-015 Consensus Execution Entrypoint

Validators:

- consensus-execution-entrypoint-validator
- test-runner-validator
- strict-json-validator
- cli-input-validator

Automation level:

- L2


## QG-016 Multi-AI Runtime Foundation

Validators:

- multi-ai-runtime-validator
- multi-ai-smoke-test-validator

Automation level:

- L2


## QG-017 Devin AI Discovery

Validators:

- devin-discovery-validator
- devin-access-policy-validator

Automation level:

- L2


## QG-018 Devin CLI Provider

Validators:

- devin-cli-provider-validator
- devin-cli-fail-closed-validator

Automation level:

- L2


## QG-019 Adaptive Routing

Validators:

- adaptive-routing-validator

Automation level:

- L2


## QG-020 Workspace Isolation

Validators:

- workspace-isolation-validator

Automation level:

- L2


## QG-021 Learning Registry

Validators:

- learning-registry-validator

Automation level:

- L2


## QG-020 Runtime Integration

Validators:
- runtime-integration-validator


## QG-021 Validation Authenticity

Validators:
- validation-authenticity-validator


## QG-022 Runtime Coverage

Validators:
- runtime-coverage-validator


## QG-023 Runtime Call Graph

Validators:
- runtime-callgraph-validator


## QG-024 Provider Availability

Validators:
- provider-availability-validator


## QG-025 Validation Truthfulness

Validators:
- validation-truthfulness-validator


## QG-026 Provider Layer Consolidation

Validators:
- provider-layer-consolidation-validator


## QG-027 Unified Validation Governance

Validators:
- unified-validation-governance-validator


## QG-028 Document Freshness

Validators:
- document-freshness-validator


## QG-029 Project Control Plane

Validators:
- control-plane-foundation-validator


## QG-030 Evidence Ledger Integrity

Validators:
- control-plane-foundation-validator


## QG-031 Skill Registry Completeness

Validators:
- control-plane-foundation-validator


## QG-032 Project Lifecycle Integrity

Validators:
- control-plane-lifecycle-validator


## QG-033 Append-Only Evidence Hash Chain

Validators:
- control-plane-lifecycle-validator


## QG-034 Runtime State Separation

Validators:
- control-plane-lifecycle-validator
