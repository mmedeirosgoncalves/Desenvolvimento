from pathlib import Path
from runtime.control_plane.control_plane import ProjectControlPlane

def test_control_plane_bootstrap_uses_external_state_and_hash_chain(tmp_path):
    cp = ProjectControlPlane(tmp_path)
    result = cp.bootstrap()
    assert result["status"] == "PASS"
    assert ".ai-eos" in result["state_path"]
    assert "runtime/control_plane/state" not in result["state_path"].replace("\\", "/")
    assert result["ledger_chain"]["status"] == "PASS"
    assert (Path(result["state_path"]) / "evidence-ledger.jsonl").exists()

def test_ledger_tampering_is_detected(tmp_path):
    cp = ProjectControlPlane(tmp_path)
    cp.bootstrap()
    ledger = cp.state / "evidence-ledger.jsonl"
    lines = ledger.read_text(encoding="utf-8").splitlines()
    lines[0] = lines[0].replace("project-created", "tampered")
    ledger.write_text("\n".join(lines) + "\n", encoding="utf-8")
    assert cp.ledger.verify_chain()["status"] == "FAIL"
