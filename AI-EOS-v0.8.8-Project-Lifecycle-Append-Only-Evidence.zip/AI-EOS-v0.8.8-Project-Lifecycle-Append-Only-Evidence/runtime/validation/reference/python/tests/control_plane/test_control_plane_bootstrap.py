from runtime.control_plane.control_plane import ProjectControlPlane

def test_control_plane_bootstrap(tmp_path):
    cp = ProjectControlPlane(tmp_path)
    result = cp.bootstrap()
    assert result["status"] == "PASS"
    assert result["skills"] >= 3
    assert result["agents"] >= 2
    assert result["evidence_records"] >= 1

def test_task_packet_requires_acceptance(tmp_path):
    cp = ProjectControlPlane(tmp_path)
    try:
        cp.create_task(objective="x", scope="y", acceptance_criteria=[])
    except ValueError as exc:
        assert "acceptance_criteria" in str(exc)
    else:
        raise AssertionError("expected ValueError")
