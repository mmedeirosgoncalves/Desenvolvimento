from __future__ import annotations
import json, hashlib
from pathlib import Path
from typing import Any
from .models import EvidenceRecord, utc_now

def _stable_hash(obj: Any) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, ensure_ascii=False, allow_nan=False).encode("utf-8")).hexdigest()

class EvidenceLedger:
    """Append-only JSONL ledger with hash chaining."""
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self.path.touch()

    def read(self) -> list[dict[str, Any]]:
        return [json.loads(line) for line in self.path.read_text(encoding="utf-8").splitlines() if line.strip()]

    def last_hash(self) -> str:
        records = self.read()
        return records[-1]["record_hash"] if records else "GENESIS"

    def append(self, record: EvidenceRecord) -> list[dict[str, Any]]:
        item = record.to_dict()
        item["previous_hash"] = self.last_hash()
        item["ledger_timestamp"] = utc_now()
        item["record_hash"] = _stable_hash({k: v for k, v in item.items() if k != "record_hash"})
        with self.path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(item, sort_keys=True, ensure_ascii=False, allow_nan=False) + "\n")
        return self.read()

    def for_task(self, task_id: str) -> list[dict[str, Any]]:
        return [r for r in self.read() if r.get("task_id") == task_id]

    def verify_chain(self) -> dict[str, Any]:
        previous = "GENESIS"
        count = 0
        for record in self.read():
            if record.get("previous_hash") != previous:
                return {"status": "FAIL", "reason": "previous_hash mismatch", "index": count}
            expected = _stable_hash({k: v for k, v in record.items() if k != "record_hash"})
            if record.get("record_hash") != expected:
                return {"status": "FAIL", "reason": "record_hash mismatch", "index": count}
            previous = record["record_hash"]
            count += 1
        return {"status": "PASS", "records": count, "last_hash": previous}
