from __future__ import annotations
import json
from pathlib import Path
from typing import Any
from .models import SkillDefinition, AgentDefinition

class JsonRegistry:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self.path.write_text("[]", encoding="utf-8")

    def read(self) -> list[dict[str, Any]]:
        return json.loads(self.path.read_text(encoding="utf-8"))

    def upsert(self, key: str, value: str, item: dict[str, Any]) -> None:
        data = self.read()
        data = [x for x in data if x.get(key) != value]
        data.append(item)
        self.path.write_text(json.dumps(data, indent=2, sort_keys=True, allow_nan=False), encoding="utf-8")

class SkillRegistry(JsonRegistry):
    def add_skill(self, skill: SkillDefinition) -> None:
        errors = skill.validate()
        if errors:
            raise ValueError("; ".join(errors))
        self.upsert("skill_id", skill.skill_id, skill.to_dict())

class AgentRegistry(JsonRegistry):
    def add_agent(self, agent: AgentDefinition) -> None:
        errors = agent.validate()
        if errors:
            raise ValueError("; ".join(errors))
        self.upsert("agent_id", agent.agent_id, agent.to_dict())
