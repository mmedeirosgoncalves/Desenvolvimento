"""AI-EOS Project Control Plane.

The control plane is the execution governance layer above providers and consensus.
It models task packets, evidence ledgers, skill registry and agent definitions.
"""
