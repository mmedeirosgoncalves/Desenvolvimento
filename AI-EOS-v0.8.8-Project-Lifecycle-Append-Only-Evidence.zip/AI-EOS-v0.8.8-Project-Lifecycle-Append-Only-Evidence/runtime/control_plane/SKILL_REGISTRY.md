---
id: skill-registry
version: 0.8.8
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: false
depends_on: [adr-0043]
used_by: []
supersedes: null
---

# Skill Registry

Skills declare triggers, inputs, outputs and risks.
