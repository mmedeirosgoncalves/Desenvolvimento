from __future__ import annotations
import argparse, json
from .control_plane import ProjectControlPlane

def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="python -m runtime.control_plane")
    parser.add_argument("--root", default=".")
    sub = parser.add_subparsers(dest="cmd", required=True)
    sub.add_parser("bootstrap")
    sub.add_parser("verify-ledger")
    p = sub.add_parser("create-project"); p.add_argument("--name", required=True); p.add_argument("--objective", required=True); p.add_argument("--owner", required=True)
    t = sub.add_parser("create-task"); t.add_argument("--objective", required=True); t.add_argument("--scope", required=True); t.add_argument("--project-id"); t.add_argument("--acceptance", action="append", default=[])
    r = sub.add_parser("start-run"); r.add_argument("--project-id", required=True); r.add_argument("--task-id", required=True)
    d = sub.add_parser("log-decision"); d.add_argument("--project-id", required=True); d.add_argument("--task-id", required=True); d.add_argument("--decision", required=True); d.add_argument("--rationale", required=True); d.add_argument("--reviewer", required=True)
    args = parser.parse_args(argv)
    cp = ProjectControlPlane(args.root)
    if args.cmd == "bootstrap": print(json.dumps(cp.bootstrap(), indent=2, allow_nan=False)); return 0
    if args.cmd == "verify-ledger": print(json.dumps(cp.ledger.verify_chain(), indent=2, allow_nan=False)); return 0
    if args.cmd == "create-project": print(json.dumps(cp.create_project(args.name,args.objective,args.owner).to_dict(), indent=2, allow_nan=False)); return 0
    if args.cmd == "create-task": print(json.dumps(cp.create_task(args.objective,args.scope,project_id=args.project_id,acceptance_criteria=args.acceptance or ["task has explicit acceptance criteria"]).to_dict(), indent=2, allow_nan=False)); return 0
    if args.cmd == "start-run": print(json.dumps(cp.start_run(args.project_id,args.task_id).to_dict(), indent=2, allow_nan=False)); return 0
    if args.cmd == "log-decision": print(json.dumps(cp.log_decision(args.project_id,args.task_id,args.decision,args.rationale,args.reviewer).to_dict(), indent=2, allow_nan=False)); return 0
    return 2

if __name__ == "__main__":
    raise SystemExit(main())
