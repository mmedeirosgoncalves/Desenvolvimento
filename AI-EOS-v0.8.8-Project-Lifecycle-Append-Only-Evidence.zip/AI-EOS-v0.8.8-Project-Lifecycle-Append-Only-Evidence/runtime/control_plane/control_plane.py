from __future__ import annotations
import json
from pathlib import Path
from typing import Any
from .models import TaskPacket, EvidenceRecord, SkillDefinition, AgentDefinition, ProjectDefinition, Milestone, RunSession, DecisionLog
from .ledger import EvidenceLedger
from .registry import SkillRegistry, AgentRegistry

class ProjectControlPlane:
    def __init__(self, root: str | Path = "."):
        self.root = Path(root)
        self.state = self.root / ".ai-eos" / "control-plane"
        self.state.mkdir(parents=True, exist_ok=True)
        self.task_dir = self.state / "tasks"
        self.project_dir = self.state / "projects"
        self.run_dir = self.state / "runs"
        self.decision_dir = self.state / "decisions"
        for d in [self.task_dir, self.project_dir, self.run_dir, self.decision_dir]:
            d.mkdir(exist_ok=True)
        self.ledger = EvidenceLedger(self.state / "evidence-ledger.jsonl")
        self.skills = SkillRegistry(self.state / "skill-registry.json")
        self.agents = AgentRegistry(self.state / "agent-registry.json")

    def _write_json(self, path: Path, payload: dict[str, Any]) -> None:
        path.write_text(json.dumps(payload, indent=2, sort_keys=True, allow_nan=False), encoding="utf-8")

    def create_project(self, name: str, objective: str, owner: str, **kwargs: Any) -> ProjectDefinition:
        project = ProjectDefinition.create(name, objective, owner, **kwargs)
        errors = project.validate()
        if errors: raise ValueError("; ".join(errors))
        self._write_json(self.project_dir / f"{project.project_id}.json", project.to_dict())
        self.ledger.append(EvidenceRecord.from_payload(project.project_id, "project-created", "control-plane", "Project created", project.to_dict()))
        return project

    def create_milestone(self, project_id: str, name: str, acceptance_criteria: list[str], **kwargs: Any) -> Milestone:
        milestone = Milestone.create(project_id, name, acceptance_criteria, **kwargs)
        errors = milestone.validate()
        if errors: raise ValueError("; ".join(errors))
        self._write_json(self.project_dir / f"{project_id}.{milestone.milestone_id}.json", milestone.to_dict())
        self.ledger.append(EvidenceRecord.from_payload(project_id, "milestone-created", "control-plane", f"Milestone created: {name}", milestone.to_dict()))
        return milestone

    def create_task(self, objective: str, scope: str, project_id: str | None = None, **kwargs: Any) -> TaskPacket:
        task = TaskPacket.create(objective, scope, **kwargs)
        errors = task.validate()
        if errors: raise ValueError("; ".join(errors))
        payload = task.to_dict()
        if project_id: payload["project_id"] = project_id
        self._write_json(self.task_dir / f"{task.task_id}.json", payload)
        self.ledger.append(EvidenceRecord.from_payload(task.task_id, "task-created", "control-plane", "Task packet created", payload))
        return task

    def start_run(self, project_id: str, task_id: str) -> RunSession:
        run = RunSession.start(project_id, task_id)
        errors = run.validate()
        if errors: raise ValueError("; ".join(errors))
        self._write_json(self.run_dir / f"{run.run_id}.json", run.to_dict())
        self.ledger.append(EvidenceRecord.from_payload(task_id, "run-started", "control-plane", "Run session started", run.to_dict()))
        return run

    def complete_run(self, run_id: str, status: str = "completed") -> RunSession:
        path = self.run_dir / f"{run_id}.json"
        if not path.exists(): raise FileNotFoundError(run_id)
        run = RunSession(**json.loads(path.read_text(encoding="utf-8")))
        run.complete(status)
        self._write_json(path, run.to_dict())
        self.ledger.append(EvidenceRecord.from_payload(run.task_id, "run-completed", "control-plane", f"Run session {status}", run.to_dict()))
        return run

    def log_decision(self, project_id: str, task_id: str, decision: str, rationale: str, reviewer: str) -> DecisionLog:
        d = DecisionLog.create(project_id, task_id, decision, rationale, reviewer)
        errors = d.validate()
        if errors: raise ValueError("; ".join(errors))
        self._write_json(self.decision_dir / f"{d.decision_id}.json", d.to_dict())
        self.ledger.append(EvidenceRecord.from_payload(task_id, "decision", reviewer, decision, d.to_dict()))
        return d

    def register_default_skills(self) -> None:
        for skill in [
            SkillDefinition("skill.release-audit", "Release Audit", "Evaluate a release using reproducible validation evidence.", ["release","audit","validation"], ["release_package","validation_report"], ["audit_findings","risk_assessment"], ["false_positive","stale_documentation"]),
            SkillDefinition("skill.consensus-execution", "Consensus Execution", "Run provider responses through consensus and human-review gates.", ["multi-ai","consensus","provider"], ["task_packet","provider_responses"], ["consensus_report","review_recommendation"], ["provider_drift","hidden_cost"]),
            SkillDefinition("skill.codegen-control", "Codegen Control", "Convert approved consensus output into implementation steps and testable patches.", ["codegen","implementation","patch"], ["consensus_report","acceptance_criteria"], ["patch_plan","test_plan"], ["side_effects","permission_scope"]),
            SkillDefinition("skill.project-lifecycle", "Project Lifecycle", "Track project, milestones, run sessions and decisions.", ["project","milestone","run","decision"], ["project_definition","task_packet"], ["run_session","decision_log","evidence_records"], ["state_drift","weak_ownership"]),
        ]:
            self.skills.add_skill(skill)

    def register_default_agents(self) -> None:
        for agent in [
            AgentDefinition("agent.release-steward", "Release Steward", "Coordinates release readiness, evidence and validation gates.", ["skill.release-audit","skill.consensus-execution","skill.project-lifecycle"]),
            AgentDefinition("agent.codegen-operator", "Codegen Operator", "Transforms approved task packets into implementation work.", ["skill.codegen-control","skill.project-lifecycle"], review_required_for=["medium","high","critical"]),
        ]:
            self.agents.add_agent(agent)

    def bootstrap(self) -> dict[str, Any]:
        self.register_default_skills()
        self.register_default_agents()
        project = self.create_project("AI-EOS Control Plane Bootstrap", "Initialize project lifecycle and append-only evidence governance.", "AI-EOS Chief Architect", reviewers=["release-steward"])
        milestone = self.create_milestone(project.project_id, "Lifecycle foundation", ["project exists","task exists","run session exists","decision log exists","ledger chain verifies"], status="active")
        task = self.create_task(
            "Bootstrap project lifecycle",
            "Initialize project, milestone, task packet, append-only evidence ledger, skill registry, agent registry, run session and decision log.",
            project_id=project.project_id,
            constraints=["non-destructive","validation-first","state-outside-runtime"],
            required_skills=["skill.release-audit","skill.project-lifecycle"],
            providers=["mock-control-plane"],
            risk="medium",
            acceptance_criteria=["task packet can be created","evidence ledger uses append-only JSONL","ledger hash chain verifies","project definition exists","run session exists","decision log exists"],
        )
        run = self.start_run(project.project_id, task.task_id)
        self.complete_run(run.run_id, "completed")
        decision = self.log_decision(project.project_id, task.task_id, "ACCEPT_WITH_RECOMMENDATIONS", "Lifecycle foundation is operational; provider consolidation remains next.", "release-steward")
        chain = self.ledger.verify_chain()
        return {"status": "PASS" if chain["status"] == "PASS" else "FAIL", "project_id": project.project_id, "milestone_id": milestone.milestone_id, "task_id": task.task_id, "run_id": run.run_id, "decision_id": decision.decision_id, "skills": len(self.skills.read()), "agents": len(self.agents.read()), "evidence_records": len(self.ledger.read()), "ledger_chain": chain, "state_path": str(self.state)}
