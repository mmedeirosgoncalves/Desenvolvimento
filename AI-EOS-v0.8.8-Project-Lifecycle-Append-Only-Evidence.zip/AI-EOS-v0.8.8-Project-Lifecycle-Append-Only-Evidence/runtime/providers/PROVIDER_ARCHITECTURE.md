---
id: provider-architecture
version: 0.8.5
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: false
depends_on: [adr-0041]
used_by: []
supersedes: null
---

# Provider Architecture

Canonical layer: `runtime/providers/`.

Allowed modes:
- `mock`
- `local`
- `api`
- `devin-cli`

Fail-closed rule:
If a provider is unavailable, unauthenticated, or unsupported, it must return or raise a degraded/unavailable state. It must never simulate real model access.
