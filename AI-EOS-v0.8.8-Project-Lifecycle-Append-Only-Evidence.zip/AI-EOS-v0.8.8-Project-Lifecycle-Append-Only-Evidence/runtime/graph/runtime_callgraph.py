from __future__ import annotations
import ast, json
from pathlib import Path
from typing import Any

def module_name(path: Path, root: Path) -> str:
    return ".".join(path.relative_to(root).with_suffix("").parts)

def imported_modules(path: Path) -> set[str]:
    try:
        tree = ast.parse(path.read_text(encoding="utf-8"))
    except SyntaxError:
        return set()
    out: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            out.update(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module:
            out.add(node.module)
    return out

def called_names(path: Path) -> set[str]:
    try:
        tree = ast.parse(path.read_text(encoding="utf-8"))
    except SyntaxError:
        return set()
    names: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            f = node.func
            if isinstance(f, ast.Name):
                names.add(f.id)
            elif isinstance(f, ast.Attribute):
                names.add(f.attr)
    return names

def build_callgraph(root: str = ".") -> dict[str, Any]:
    base = Path(root).resolve()
    py_files = [p for p in base.rglob("*.py") if "__pycache__" not in p.parts]
    modules = {module_name(p, base): p for p in py_files}
    edges = set()
    for mod, path in modules.items():
        for imp in imported_modules(path):
            for target in modules:
                if target == imp or target.endswith("." + imp.split(".")[-1]) or imp.startswith(target + "."):
                    if target != mod:
                        edges.add((mod, target))
    incoming = {m: 0 for m in modules}
    outgoing = {m: 0 for m in modules}
    for src, dst in edges:
        outgoing[src] = outgoing.get(src, 0) + 1
        incoming[dst] = incoming.get(dst, 0) + 1
    orphan_nodes = sorted(
        m for m in modules
        if incoming.get(m, 0) == 0 and outgoing.get(m, 0) == 0
        and not m.endswith("__init__")
        and "tests." not in m
    )
    entry_modules = sorted(
        m for m, p in modules.items()
        if "__main__" in p.read_text(encoding="utf-8", errors="replace")
        or m.endswith(("orchestrator.orchestrator", "ai_eos_validate", "run_tests"))
    )
    return {
        "method": "ast_import_graph",
        "nodes": sorted(modules),
        "edges": [list(e) for e in sorted(edges)],
        "entry_modules": entry_modules,
        "orphan_nodes": orphan_nodes,
        "node_count": len(modules),
        "edge_count": len(edges)
    }

def write_callgraph(path: str, root: str = ".") -> dict[str, Any]:
    data = build_callgraph(root)
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, indent=2, sort_keys=True, allow_nan=False), encoding="utf-8")
    return data

if __name__ == "__main__":
    import sys
    write_callgraph(sys.argv[1] if len(sys.argv) > 1 else "reports/runtime-callgraph.json", sys.argv[2] if len(sys.argv) > 2 else ".")
