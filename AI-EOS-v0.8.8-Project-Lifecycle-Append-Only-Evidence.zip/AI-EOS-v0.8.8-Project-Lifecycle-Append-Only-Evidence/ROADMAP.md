---
id: roadmap
version: 0.8.8
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: true
depends_on: []
used_by: []
supersedes: null
---

# Roadmap

## Completed

- v0.8.7 — Project Control Plane Foundation.
- v0.8.8 — Project Lifecycle & Append-Only Evidence.

## Next

- v0.8.9 — Provider Layer Consolidation.
- v0.9.0 — End-to-End Runtime Execution.
