---
id: migration-guide
version: 0.8.8
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: true
depends_on: [adr-0044]
used_by: []
supersedes: null
---

# Migration Guide — v0.8.7 to v0.8.8

State moved from `runtime/control_plane/state` to `.ai-eos/control-plane`.

Evidence moved from mutable JSON to append-only JSONL:

```text
.ai-eos/control-plane/evidence-ledger.jsonl
```
