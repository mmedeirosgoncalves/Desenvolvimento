---
id: changelog
version: 0.8.8
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: true
depends_on: []
used_by: []
supersedes: null
---

# Changelog

## v0.8.8 — Project Lifecycle & Append-Only Evidence

- Moved state outside runtime.
- Replaced mutable evidence JSON with append-only JSONL.
- Added hash-chain verification.
- Added project lifecycle entities and CLI commands.
- Added lifecycle validator and ADR-0044.
