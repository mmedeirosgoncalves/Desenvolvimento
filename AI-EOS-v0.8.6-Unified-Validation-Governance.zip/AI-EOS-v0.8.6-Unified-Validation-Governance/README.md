---
id: readme
version: 0.8.6
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: true
depends_on: [adr-0038, adr-0039, adr-0040, adr-0041, adr-0042]
used_by: []
supersedes: null
---

# AI-EOS v0.8.6 — Unified Validation Governance

Codename: Unified Truth.

This release addresses the v0.8.5 audit finding of **partitioned truthfulness**.

## What changed

- Added `runtime/validation/unified_validation.py` as the single validation source of truth.
- `build_validation_report.py` now delegates to the unified validation engine.
- Final release status is now the worst status across runtime, reference, document, strict JSON, coverage and authenticity validators.
- Added `document-freshness-validator`.
- Added ADR-0042 and document freshness policy.
- Normalized external comparative-system references to neutral nomenclature: `External Agent System`.

## Baseline

AI-EOS v0.8.5 Validation Truthfulness Hardening.
