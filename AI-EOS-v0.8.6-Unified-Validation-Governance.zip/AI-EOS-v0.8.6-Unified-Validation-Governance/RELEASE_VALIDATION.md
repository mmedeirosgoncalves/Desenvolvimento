---
id: release-validation
version: 0.8.6
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: true
depends_on: [adr-0042]
used_by: []
supersedes: null
---

# Release Validation — v0.8.6

Authoritative command:

```bash
python runtime/validation/unified_validation.py . validation-report.json
```

Compatibility command:

```bash
python runtime/validation/build_validation_report.py . validation-report.json
```

Acceptance rule:

```text
final_status = worst(runtime, callgraph, coverage, strict_json, reference, document_freshness, authenticity)
```
