---
id: migration-guide
version: 0.8.6
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: true
depends_on: [adr-0042]
used_by: []
supersedes: null
---

# Migration Guide — v0.8.5 to v0.8.6

Use only the unified validator for release decisions:

```bash
python runtime/validation/unified_validation.py . validation-report.json
```

`build_validation_report.py` is preserved as a compatibility wrapper.

Do not use hand-authored validation summaries as release authority.
