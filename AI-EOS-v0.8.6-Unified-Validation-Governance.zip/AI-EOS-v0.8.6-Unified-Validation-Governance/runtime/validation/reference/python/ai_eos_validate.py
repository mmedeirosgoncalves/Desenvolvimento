#!/usr/bin/env python3
"""AI-EOS reference validator v0.6.0.2.

Restores the negative-fixture safety net and keeps runtime integration checks.
"""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from difflib import SequenceMatcher

try:
    from path_utils import normalize_path, relative_path
except ImportError:
    def normalize_path(value):
        raw = str(value).replace("\\", "/").strip()
        while "//" in raw:
            raw = raw.replace("//", "/")
        return raw.lstrip("./").strip("/")
    def relative_path(path, root):
        return normalize_path(Path(path).resolve().relative_to(Path(root).resolve()))

try:
    from core.comparators import compare_paths, normalize_document_body, similarity
except ImportError:
    def compare_paths(left, right):
        return normalize_path(left) == normalize_path(right)
    def normalize_document_body(text, remove_h1=True):
        if text.startswith("---"):
            parts = text.split("---", 2)
            if len(parts) == 3:
                text = parts[2].lstrip()
        lines = text.splitlines()
        if remove_h1:
            lines = [line for line in lines if not line.strip().startswith("# ")]
        return re.sub(r"\s+", " ", "\n".join(lines).strip().lower())
    def similarity(left, right):
        return SequenceMatcher(None, normalize_document_body(left), normalize_document_body(right)).ratio()

VALID_STATUSES = {"active", "draft", "deprecated", "archived", "validated", "stable", "experimental"}
VALID_PACK_STATUSES = {"draft", "experimental", "validated", "stable", "deprecated", "archived"}
VALID_MATURITY = {"L0", "L1", "L2", "L3", "L4"}
EXPECTED_RELEASE_VERSION = "0.8.6"

def framework_version(root: Path) -> str:
    version_file = Path(root) / "VERSION"
    if version_file.exists():
        return version_file.read_text(encoding="utf-8").strip()
    return EXPECTED_RELEASE_VERSION

ALLOWED_DUPLICATE_GROUPS = {
    frozenset({
        "canon/api/README.md",
        "canon/architecture/README.md",
        "canon/cloud/README.md",
        "canon/data/README.md",
        "canon/database/README.md",
        "canon/databricks/README.md",
        "canon/devops/README.md",
        "canon/legacy/README.md",
        "canon/security/README.md",
        "canon/testing/README.md",
    }),
    frozenset({
        "canon/api/DECISION_RULES.md",
        "canon/architecture/DECISION_RULES.md",
        "canon/cloud/DECISION_RULES.md",
        "canon/data/DECISION_RULES.md",
        "canon/database/DECISION_RULES.md",
        "canon/databricks/DECISION_RULES.md",
        "canon/devops/DECISION_RULES.md",
        "canon/legacy/DECISION_RULES.md",
        "canon/security/DECISION_RULES.md",
        "canon/testing/DECISION_RULES.md",
    }),
    frozenset({
        "canon/api/ROADMAP.md",
        "canon/architecture/ROADMAP.md",
        "canon/cloud/ROADMAP.md",
        "canon/data/ROADMAP.md",
        "canon/database/ROADMAP.md",
        "canon/databricks/ROADMAP.md",
        "canon/devops/ROADMAP.md",
        "canon/legacy/ROADMAP.md",
        "canon/security/ROADMAP.md",
        "canon/testing/ROADMAP.md",
    })
}

def is_fixture(path: Path) -> bool:
    parts = set(Path(path).parts)
    return "fixtures" in parts and "tests" in parts

def scanning_fixture_root(root: Path) -> bool:
    return "fixtures" in set(Path(root).parts)

def markdown_files(root: Path):
    root = Path(root)
    keep_all = scanning_fixture_root(root)
    return sorted(p for p in root.rglob("*.md") if keep_all or not is_fixture(p))

def yaml_files(root: Path):
    root = Path(root)
    keep_all = scanning_fixture_root(root)
    return sorted(p for p in root.rglob("*.yaml") if keep_all or not is_fixture(p))

def allowed_duplicate_group(group) -> bool:
    normalized = frozenset(normalize_path(x) for x in group)
    if normalized in ALLOWED_DUPLICATE_GROUPS:
        return True
    if len(normalized) == 2:
        names = {Path(x).name for x in normalized}
        parents = {normalize_path(Path(x).parent) for x in normalized}
        # Permit only same canonical document duplicated across canon domains.
        if len(names) == 1 and names.pop() in {"DECISION_RULES.md", "ROADMAP.md"}:
            return all(p.startswith("canon/") and len(p.split("/")) == 2 for p in parents)
    return False

def parse_front_matter(text: str):
    if not text.startswith("---"):
        return {}, text
    parts = text.split("---", 2)
    meta = {}
    if len(parts) >= 3:
        fm_text = parts[1]
        body = parts[2].lstrip()
    else:
        # Legacy negative fixtures may omit the closing delimiter.
        lines = text.splitlines()[1:]
        fm_lines = []
        body_lines = []
        in_body = False
        for line in lines:
            if not in_body and (line.startswith("#") or (line.strip() == "" and fm_lines)):
                in_body = True
            if in_body:
                body_lines.append(line)
            else:
                fm_lines.append(line)
        fm_text = "\n".join(fm_lines)
        body = "\n".join(body_lines)
    for line in fm_text.strip().splitlines():
        if ":" in line:
            k, v = line.split(":", 1)
            meta[k.strip()] = v.strip()
    return meta, body

def parse_inline_list(value: str):
    if not value or value.strip() in {"[]", "null", "None"}:
        return []
    value = value.strip()
    if value.startswith("[") and value.endswith("]"):
        inner = value[1:-1].strip()
        return [x.strip().strip("'\"") for x in inner.split(",") if x.strip()]
    return [value.strip().strip("'\"")]

def simple_yaml_load(path: Path):
    data = {}
    current = None
    for raw in path.read_text(encoding="utf-8").splitlines():
        s = raw.strip()
        if not s or s.startswith("#"):
            continue
        if s.startswith("- ") and current:
            if not isinstance(data.get(current), list):
                data[current] = []
            data[current].append(s[2:].strip().strip("'\""))
        elif ":" in s:
            k, v = s.split(":", 1)
            k, v = k.strip(), v.strip()
            current = k
            if v == "":
                data[k] = []
            elif v.startswith("[") and v.endswith("]"):
                inner = v[1:-1].strip()
                data[k] = [x.strip().strip("'\"") for x in inner.split(",") if x.strip()] if inner else []
            else:
                data[k] = v.strip("'\"")
    return data

def finding(findings, validator_id, severity, message, path=None):
    findings.append({
        "validator_id": validator_id,
        "severity": severity,
        "message": message,
        "path": normalize_path(path) if path else None,
    })

def validate_markdown(root: Path, findings):
    ids = {}
    deps = {}
    duplicates = []
    for p in markdown_files(root):
        rel = relative_path(p, root)
        meta, _ = parse_front_matter(p.read_text(encoding="utf-8"))
        idv = meta.get("id")
        if idv:
            if idv in ids:
                duplicates.append((idv, ids[idv], rel))
            ids[idv] = rel
            deps[idv] = parse_inline_list(meta.get("depends_on", ""))

    unresolved = []
    for src, ds in deps.items():
        for dep in ds:
            if dep and dep not in ids:
                unresolved.append((src, dep))

    if duplicates:
        finding(findings, "markdown-metadata-validator", "HIGH", f"Duplicate ids found: {duplicates}")
    if unresolved:
        finding(findings, "markdown-dependency-validator", "HIGH", f"Unresolved depends_on references: {unresolved}")
    return {"markdown_files": len(markdown_files(root)), "ids": len(ids), "duplicate_ids": len(duplicates), "unresolved_dependencies": len(unresolved)}

def validate_render(root: Path, findings):
    occ = 0
    for p in markdown_files(root):
        rel = relative_path(p, root)
        for i, line in enumerate(p.read_text(encoding="utf-8").splitlines(), 1):
            if "\\n" in line and "literal" not in line.lower() and "escaped newline" not in line.lower():
                occ += 1
                finding(findings, "markdown-render-validator", "MEDIUM", f"Literal escaped newlines found at line {i}", rel)
    return {"literal_newline_occurrences": occ}

def validate_duplication(root: Path, findings, threshold: float = 0.92):
    docs = []
    for p in markdown_files(root):
        rel = relative_path(p, root)
        text = p.read_text(encoding="utf-8")
        body = normalize_document_body(text)
        if len(body) >= 40:
            docs.append((rel, text, body))

    exact = {}
    for rel, text, body in docs:
        exact.setdefault(body, []).append(rel)

    unexpected = 0
    for group in exact.values():
        if len(group) > 1 and not allowed_duplicate_group(group):
            unexpected += 1
            finding(findings, "content-duplication-validator", "MEDIUM", f"Unexpected exact duplicate group: {group}")

    near = 0
    # Full near-duplicate scan only for fixture roots or small corpora.
    if scanning_fixture_root(root) or len(docs) <= 50:
        for i, (ra, ta, ba) in enumerate(docs):
            for rb, tb, bb in docs[i+1:]:
                if allowed_duplicate_group([ra, rb]):
                    continue
                if similarity(ta, tb) >= threshold:
                    near += 1
                    finding(findings, "content-duplication-validator", "LOW", f"Near-duplicate content: {ra} <-> {rb}")
    return {"unexpected_exact_duplicate_groups": unexpected, "near_duplicate_pairs": near, "scanned_files": len(docs)}

def is_release_document(meta: dict) -> bool:
    return str(meta.get("release_document", "false")).strip().lower() == "true"

def validate_version(root: Path, findings):
    expected = framework_version(root)
    invalid_status = 0
    stale_versions = 0
    missing_updated = 0
    missing_release_version = 0
    release_documents = 0

    for p in markdown_files(root):
        rel = relative_path(p, root)
        meta, _ = parse_front_matter(p.read_text(encoding="utf-8"))
        st = meta.get("status")
        if st and st not in VALID_STATUSES:
            invalid_status += 1
            finding(findings, "version-consistency-validator", "MEDIUM", f"Unexpected status value {st}", rel)

        if is_release_document(meta):
            release_documents += 1
            version = meta.get("version")
            if not version:
                missing_release_version += 1
                finding(findings, "version-consistency-validator", "LOW", "Release document missing version field", rel)
            elif version != expected:
                stale_versions += 1
                finding(findings, "version-consistency-validator", "LOW", f"Release document has stale version {version}; expected {expected}", rel)
            if not meta.get("updated"):
                missing_updated += 1
                finding(findings, "version-consistency-validator", "LOW", "Release document missing updated field", rel)

    return {
        "expected_version": expected,
        "release_documents": release_documents,
        "invalid_status": invalid_status,
        "stale_versions": stale_versions,
        "missing_updated": missing_updated,
        "missing_release_version": missing_release_version,
    }

def validate_manifest(root: Path, findings, markdown_count: int):
    p = Path(root) / "PACKAGE_MANIFEST.md"
    result = {"declared_markdown_files": None, "actual_markdown_files": markdown_count, "top_level_missing": [], "top_level_nonexistent": []}
    if not p.exists():
        if not scanning_fixture_root(root):
            finding(findings, "manifest-validator", "HIGH", "PACKAGE_MANIFEST.md missing")
        return result
    text = p.read_text(encoding="utf-8")
    m = re.search(r"## Markdown Files\s+(\d+)", text)
    if m:
        result["declared_markdown_files"] = int(m.group(1))
        if result["declared_markdown_files"] != markdown_count:
            finding(findings, "manifest-validator", "MEDIUM", f"Markdown file count mismatch: declared={result['declared_markdown_files']}, actual={markdown_count}", "PACKAGE_MANIFEST.md")
    listed = set()
    in_top = False
    for line in text.splitlines():
        if line.strip() == "## Top-Level Areas":
            in_top = True
            continue
        if in_top and line.strip().startswith("## "):
            break
        if in_top and line.strip().startswith("- "):
            listed.add(normalize_path(line.strip()[2:]))
    actual = {normalize_path(x.name) for x in Path(root).iterdir() if x.is_dir()}
    if listed:
        result["top_level_missing"] = sorted(actual - listed)
        result["top_level_nonexistent"] = sorted(listed - actual)
        for x in result["top_level_missing"]:
            finding(findings, "manifest-validator", "LOW", f"Top-level area missing from manifest: {x}", "PACKAGE_MANIFEST.md")
        for x in result["top_level_nonexistent"]:
            finding(findings, "manifest-validator", "LOW", f"Manifest lists nonexistent top-level area: {x}", "PACKAGE_MANIFEST.md")
    compare_paths("adapters/", "adapters")
    return result

def validate_yaml(root: Path, findings):
    required = {"id","name","version","owner","status","maturity","review_date","exports","requires","optional","conflicts","tags","depends_on","consumed_by"}
    packages = {}
    paths = {}
    for p in yaml_files(root):
        rel = relative_path(p, root)
        data = simple_yaml_load(p)
        if p.name == "package.yaml":
            missing = sorted(required - set(data))
            if missing:
                finding(findings, "yaml-package-validator", "HIGH", f"Missing package fields: {missing}", rel)
            pid = data.get("id")
            if pid:
                if pid in packages:
                    finding(findings, "yaml-package-validator", "HIGH", f"Duplicate package id {pid}", rel)
                packages[pid] = data
                paths[pid] = rel
            if data.get("status") and data.get("status") not in VALID_PACK_STATUSES:
                finding(findings, "yaml-package-validator", "MEDIUM", f"Invalid package status {data.get('status')}", rel)
            if data.get("maturity") and data.get("maturity") not in VALID_MATURITY:
                finding(findings, "yaml-package-validator", "MEDIUM", f"Invalid package maturity {data.get('maturity')}", rel)

    entries = []
    registry = Path(root) / "runtime/registry/knowledge_registry.yaml"
    if registry.exists():
        current = None
        for raw in registry.read_text(encoding="utf-8").splitlines():
            s = raw.strip()
            if s.startswith("- id:"):
                if current:
                    entries.append(current)
                current = {"id": s.split(":", 1)[1].strip().strip("'\"")}
            elif current and s.startswith("path:"):
                current["path"] = s.split(":", 1)[1].strip().strip("'\"")
        if current:
            entries.append(current)
        for e in entries:
            eid = e.get("id")
            epath = normalize_path(e.get("path", ""))
            if eid not in packages:
                finding(findings, "yaml-registry-validator", "HIGH", f"Registry references unknown package id {eid}", "runtime/registry/knowledge_registry.yaml")
            if epath and not (Path(root) / epath).exists():
                finding(findings, "yaml-registry-validator", "HIGH", f"Registry path missing: {epath}", "runtime/registry/knowledge_registry.yaml")
            elif eid in paths and epath and not compare_paths(epath, paths[eid]):
                finding(findings, "yaml-registry-validator", "MEDIUM", f"Registry path mismatch for {eid}: {epath} vs {paths[eid]}", "runtime/registry/knowledge_registry.yaml")
    elif yaml_files(root) and not scanning_fixture_root(root):
        finding(findings, "yaml-registry-validator", "HIGH", "knowledge_registry.yaml missing")

    canon_deps = {f"canon-{x.name}" for x in (Path(root) / "canon").glob("*") if x.is_dir()} if (Path(root) / "canon").exists() else set()
    unresolved = []
    for pid, data in packages.items():
        for req in data.get("requires", []):
            if req not in packages and req not in canon_deps:
                unresolved.append((pid, req))
                finding(findings, "yaml-dependency-validator", "MEDIUM", f"Unresolved package requirement {req}", paths.get(pid))
    return {"yaml_files": len(yaml_files(root)), "packages": len(packages), "registry_entries": len(entries), "unresolved_requires": len(unresolved)}

def validate_spec_coverage(root: Path, findings):
    specs = [
        "knowledge/KNOWLEDGE_PACK_SPEC.md",
        "runtime/registry/KNOWLEDGE_REGISTRY.md",
        "runtime/capability/CAPABILITY_MODEL.md",
        "runtime/dependency/KNOWLEDGE_DEPENDENCY_GRAPH.md",
        "runtime/contracts/KNOWLEDGE_RUNTIME_CONTRACT.md",
        "runtime/context/CONTEXT_BUILDER.md",
    ]
    present = sum(1 for x in specs if (Path(root) / x).exists())
    if Path(root).name != "fixtures" and present < len(specs) and not scanning_fixture_root(root):
        finding(findings, "specification-coverage-validator", "LOW", f"Specification coverage incomplete: {present}/{len(specs)}")
    return {"specifications_tracked": len(specs), "specifications_present": present}

def validate_qg015(root: Path, findings):
    root = Path(root)
    required = [
        "runtime/consensus/cli.py",
        "runtime/consensus/__main__.py",
        "runtime/consensus/engine.py",
        "runtime/consensus/reporting.py",
        "runtime/quality-gates/QG-015-consensus-execution-entrypoint.md",
        "runtime/consensus/CONSENSUS_INPUT_SCHEMA.json",
    ]
    missing = [x for x in required if not (root / x).exists()]
    for x in missing:
        finding(findings, "consensus-execution-entrypoint-validator", "HIGH", f"Required QG-015 artifact missing: {x}", x)
    docs = [
        root / "runtime/quality-gates/QUALITY_GATES.md",
        root / "runtime/validation/QUALITY_GATE_MAPPING.md",
        root / "runtime/validation/VALIDATION_REGISTRY.md",
    ]
    missing_refs = []
    for doc in docs:
        if doc.exists() and "QG-015" not in doc.read_text(encoding="utf-8"):
            missing_refs.append(relative_path(doc, root))
            finding(findings, "consensus-execution-entrypoint-validator", "HIGH", f"QG-015 missing from {relative_path(doc, root)}", relative_path(doc, root))
    return {"required_artifacts": len(required), "missing_artifacts": len(missing), "missing_registry_refs": len(missing_refs)}

def validate_strict_json_reports(root: Path, findings):
    bad = 0
    files = list(Path(root).rglob("*.json"))
    for p in files:
        rel = relative_path(p, root)
        try:
            text = p.read_text(encoding="utf-8")
            data = json.loads(text)
            if re.search(r'(?<!["A-Za-z0-9_])(?:Infinity|-Infinity|NaN)(?!["A-Za-z0-9_])', text):
                bad += 1
                finding(findings, "strict-json-validator", "HIGH", "Non-standard JSON numeric constant found", rel)
            json.dumps(data, allow_nan=False)
        except ValueError as exc:
            bad += 1
            finding(findings, "strict-json-validator", "HIGH", f"JSON is not strict RFC8259-compatible: {exc}", rel)
    return {"json_files_scanned": len(files), "strict_json_failures": bad}

def validate_qg016(root: Path, findings):
    required = [
        "runtime/multi_ai/provider_contract.py",
        "runtime/multi_ai/provider_registry.py",
        "runtime/multi_ai/orchestrator.py",
        "runtime/multi_ai/consensus_round.py",
        "runtime/multi_ai/human_review_gate.py",
        "runtime/multi_ai/audit_trail.py",
        "runtime/multi_ai/cli.py",
        "runtime/quality-gates/QG-016-multi-ai-runtime-foundation.md",
        "examples/multi_ai/sample_multi_ai_execution.json",
    ]
    missing = [x for x in required if not (Path(root) / x).exists()]
    for x in missing:
        finding(findings, "multi-ai-runtime-validator", "HIGH", f"Required QG-016 artifact missing: {x}", x)
    docs = [
        Path(root) / "runtime/quality-gates/QUALITY_GATES.md",
        Path(root) / "runtime/validation/QUALITY_GATE_MAPPING.md",
        Path(root) / "runtime/validation/VALIDATION_REGISTRY.md",
    ]
    missing_refs = []
    for doc in docs:
        if doc.exists() and "QG-016" not in doc.read_text(encoding="utf-8"):
            missing_refs.append(relative_path(doc, root))
            finding(findings, "multi-ai-runtime-validator", "HIGH", f"QG-016 missing from {relative_path(doc, root)}", relative_path(doc, root))
    return {"required_artifacts": len(required), "missing_artifacts": len(missing), "missing_registry_refs": len(missing_refs)}

def validate_qg017(root: Path, findings):
    required = [
        "runtime/devin/discovery.py",
        "runtime/devin/adapter.py",
        "runtime/devin/access_policy.py",
        "runtime/devin/cli.py",
        "runtime/devin/DEVIN_AI_DISCOVERY.md",
        "runtime/devin/DEVIN_ACCESS_POLICY.md",
        "runtime/quality-gates/QG-017-devin-ai-discovery.md",
        "examples/devin/devin_discovery_config.example.json",
    ]
    missing = [x for x in required if not (Path(root) / x).exists()]
    for x in missing:
        finding(findings, "devin-discovery-validator", "HIGH", f"Required QG-017 artifact missing: {x}", x)
    docs = [
        Path(root) / "runtime/quality-gates/QUALITY_GATES.md",
        Path(root) / "runtime/validation/QUALITY_GATE_MAPPING.md",
        Path(root) / "runtime/validation/VALIDATION_REGISTRY.md",
    ]
    missing_refs = []
    for doc in docs:
        if doc.exists() and "QG-017" not in doc.read_text(encoding="utf-8"):
            missing_refs.append(relative_path(doc, root))
            finding(findings, "devin-discovery-validator", "HIGH", f"QG-017 missing from {relative_path(doc, root)}", relative_path(doc, root))
    policy = Path(root) / "runtime/devin/DEVIN_ACCESS_POLICY.md"
    policy_text = policy.read_text(encoding="utf-8") if policy.exists() else ""
    if "UI visibility alone is insufficient" not in policy_text:
        finding(findings, "devin-access-policy-validator", "HIGH", "Devin access policy does not explicitly reject UI-only execution", "runtime/devin/DEVIN_ACCESS_POLICY.md")
    return {"required_artifacts": len(required), "missing_artifacts": len(missing), "missing_registry_refs": len(missing_refs)}

def run(root: str | Path):
    root = Path(root).resolve()
    findings = []
    md = validate_markdown(root, findings)
    rnd = validate_render(root, findings)
    dup = validate_duplication(root, findings)
    ver = validate_version(root, findings)
    manifest = validate_manifest(root, findings, md["markdown_files"])
    yml = validate_yaml(root, findings)
    spec = validate_spec_coverage(root, findings)
    qg015 = validate_qg015(root, findings)
    strict_json = validate_strict_json_reports(root, findings)
    qg016 = validate_qg016(root, findings)
    qg017 = validate_qg017(root, findings)

    high = sum(1 for f in findings if f["severity"] == "HIGH")
    medium = sum(1 for f in findings if f["severity"] == "MEDIUM")
    low = sum(1 for f in findings if f["severity"] == "LOW")
    status = "FAIL" if high else ("WARNING" if findings else "PASS")
    recommendation = "REJECT" if status == "FAIL" else ("ACCEPT_WITH_RECOMMENDATIONS" if status == "WARNING" else "ACCEPT")

    validators = [
        {"validator_id": "markdown-metadata-validator", "status": "PASS" if md["duplicate_ids"] == 0 else "FAIL", "metrics": md, "findings": "Duplicate ids found" if md["duplicate_ids"] else ""},
        {"validator_id": "markdown-dependency-validator", "status": "PASS" if md["unresolved_dependencies"] == 0 else "FAIL", "metrics": md, "findings": "Unresolved depends_on references" if md["unresolved_dependencies"] else ""},
        {"validator_id": "markdown-render-validator", "status": "PASS" if rnd["literal_newline_occurrences"] == 0 else "WARNING", "metrics": rnd, "findings": "Literal escaped newlines found" if rnd["literal_newline_occurrences"] else ""},
        {"validator_id": "content-duplication-validator", "status": "PASS" if dup["unexpected_exact_duplicate_groups"] == 0 and dup["near_duplicate_pairs"] == 0 else "WARNING", "metrics": dup, "findings": "Near-duplicate content" if dup["near_duplicate_pairs"] or dup["unexpected_exact_duplicate_groups"] else ""},
        {"validator_id": "version-consistency-validator", "status": "PASS" if ver["invalid_status"] == 0 and ver["stale_versions"] == 0 and ver["missing_updated"] == 0 and ver["missing_release_version"] == 0 else "WARNING", "metrics": ver, "findings": ("Unexpected status value" if ver["invalid_status"] else ("stale version" if ver["stale_versions"] else ("missing release version" if ver["missing_release_version"] else ("missing updated" if ver["missing_updated"] else ""))))},
        {"validator_id": "manifest-validator", "status": "WARNING" if manifest["top_level_missing"] or manifest["top_level_nonexistent"] or (manifest["declared_markdown_files"] is not None and manifest["declared_markdown_files"] != manifest["actual_markdown_files"]) else "PASS", "metrics": manifest, "findings": "Markdown file count mismatch" if manifest["declared_markdown_files"] is not None and manifest["declared_markdown_files"] != manifest["actual_markdown_files"] else ""},
        {"validator_id": "yaml-package-validator", "status": "PASS" if yml["packages"] or yml["yaml_files"] == 0 else "WARNING", "metrics": yml},
        {"validator_id": "yaml-registry-validator", "status": "PASS" if yml["registry_entries"] or yml["yaml_files"] == 0 else "WARNING"},
        {"validator_id": "yaml-dependency-validator", "status": "PASS" if yml["unresolved_requires"] == 0 else "WARNING"},
        {"validator_id": "specification-coverage-validator", "status": "PASS" if spec["specifications_present"] == spec["specifications_tracked"] or scanning_fixture_root(root) else "WARNING", "metrics": spec},
        {"validator_id": "consensus-execution-entrypoint-validator", "status": "PASS" if qg015["missing_artifacts"] == 0 and qg015["missing_registry_refs"] == 0 else "FAIL", "metrics": qg015},
        {"validator_id": "strict-json-validator", "status": "PASS" if strict_json["strict_json_failures"] == 0 else "FAIL", "metrics": strict_json},
    ]

    return {
        "release": "AI-EOS",
        "validation_engine": "reference-python",
        "version": framework_version(root),
        "summary": {
            "status": status,
            "recommendation": recommendation,
            "markdown_files": md["markdown_files"],
            "yaml_files": yml["yaml_files"],
            "findings": len(findings),
            "high": high,
            "medium": medium,
            "low": low
        },
        "validators": validators,
        "findings": findings,
        "recommendation": recommendation,
    }

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("root", nargs="?", default=".")
    parser.add_argument("--output", default="validation-report.json")
    args = parser.parse_args()
    report = run(args.root)
    Path(args.output).write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(report["summary"], indent=2, ensure_ascii=False))
    return 1 if report["summary"]["status"] == "FAIL" else 0

if __name__ == "__main__":
    raise SystemExit(main())
