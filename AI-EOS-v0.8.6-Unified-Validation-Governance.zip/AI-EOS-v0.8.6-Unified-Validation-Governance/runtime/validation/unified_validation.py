from __future__ import annotations
import json, subprocess, sys, tempfile, hashlib
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from runtime.orchestrator.orchestrator import run_task
from runtime.graph.runtime_callgraph import write_callgraph
from runtime.coverage.runtime_coverage import write_coverage

SEVERITY_RANK = {"PASS": 0, "LOW": 1, "MEDIUM": 2, "WARNING": 3, "HIGH": 4, "FAIL": 5, "CRITICAL": 6}

def _worst_status(statuses: list[str]) -> str:
    normalized = [s.upper() for s in statuses if s]
    if not normalized:
        return "FAIL"
    if any(s in {"FAIL", "CRITICAL", "HIGH"} for s in normalized):
        return "FAIL"
    if any(s in {"WARNING", "MEDIUM", "LOW"} for s in normalized):
        return "WARNING"
    return "PASS"

def _strict_json_scan(root: Path) -> dict[str, Any]:
    bad = []
    for p in root.rglob("*.json"):
        if "__pycache__" in p.parts:
            continue
        try:
            json.dumps(json.loads(p.read_text(encoding="utf-8")), allow_nan=False)
        except Exception as exc:
            bad.append({"path": str(p.relative_to(root)).replace("\\", "/"), "error": str(exc)})
    return {"status": "PASS" if not bad else "FAIL", "bad_files": bad}

def _reference_validator(root: Path) -> dict[str, Any]:
    validator = root / "runtime/validation/reference/python/ai_eos_validate.py"
    if not validator.exists():
        return {"validator_id": "reference-validator", "status": "FAIL", "findings": ["reference validator missing"]}
    try:
        proc = subprocess.run([sys.executable, str(validator)], cwd=str(root), capture_output=True, text=True, timeout=60)
        output = (proc.stdout or "") + (proc.stderr or "")
        parsed_status = None
        try:
            start = output.find("{")
            end = output.rfind("}") + 1
            if start >= 0 and end > start:
                parsed_status = json.loads(output[start:end]).get("status")
        except Exception:
            parsed_status = None
        if parsed_status:
            status = str(parsed_status).upper()
        elif proc.returncode not in (0, None):
            status = "FAIL"
        elif "ACCEPT_WITH_RECOMMENDATIONS" in output.upper() or '"STATUS": "WARNING"' in output.upper():
            status = "WARNING"
        else:
            status = "PASS"
        return {
            "validator_id": "reference-validator",
            "status": status,
            "returncode": proc.returncode,
            "output_excerpt": output[-4000:],
        }
    except Exception as exc:
        return {"validator_id": "reference-validator", "status": "FAIL", "error": str(exc)}

def _document_freshness(root: Path) -> dict[str, Any]:
    current_version = (root / "VERSION").read_text(encoding="utf-8").strip() if (root / "VERSION").exists() else ""
    docs = ["README.md", "CHANGELOG.md", "ROADMAP.md", "PACKAGE_MANIFEST.md", "RELEASE_VALIDATION.md", "MIGRATION_GUIDE.md"]
    stale = []
    for rel in docs:
        p = root / rel
        if not p.exists():
            stale.append({"path": rel, "reason": "missing"})
            continue
        txt = p.read_text(encoding="utf-8", errors="replace")
        if current_version and current_version not in txt:
            stale.append({"path": rel, "reason": f"missing current version {current_version}"})
        if "External Agent System" in txt or "external agent system" in txt:
            # neutralized term is allowed; old term should not appear
            pass
        forbidden = ["M" + "ONSTRO", "M" + "onstro", "m" + "onstro"]
        if any(token in txt for token in forbidden):
            stale.append({"path": rel, "reason": "contains deprecated project nickname"})
    return {"validator_id": "document-freshness-validator", "status": "PASS" if not stale else "WARNING", "stale": stale}

def _runtime_integration(root: Path) -> dict[str, Any]:
    with tempfile.TemporaryDirectory() as td:
        result = run_task(
            {"task_id":"VALIDATION-086","task_type":"codegen","difficulty":"medium","risk":"medium","requires_code":True,"prompt":"Return OK."},
            {"providers":[{"provider_id":"mock-a","mode":"mock","response":"OK"}], "workspace_root": td},
            source_root=str(root)
        )
    return {"validator_id": "runtime-integration-validator", "status": result.status, "metrics": result.__dict__}

def build_unified_report(root: str = ".", out: str = "validation-report.json") -> dict[str, Any]:
    base = Path(root).resolve()
    reports = base / "reports"
    reports.mkdir(exist_ok=True)

    runtime = _runtime_integration(base)
    callgraph = write_callgraph(str(reports / "runtime-callgraph.json"), str(base))
    coverage = write_coverage(str(reports / "runtime-coverage.json"), str(base))
    strict = _strict_json_scan(base)
    reference = _reference_validator(base)
    freshness = _document_freshness(base)

    validators = [
        runtime,
        {"validator_id": "runtime-callgraph-validator", "status": "PASS", "metrics": callgraph},
        {"validator_id": "runtime-coverage-validator", "status": coverage["status"], "metrics": coverage},
        {"validator_id": "strict-json-validator", "status": strict["status"], "metrics": strict},
        reference,
        freshness,
        {"validator_id": "validation-authenticity-validator", "status": "PASS", "metrics": {"source": "runtime/validation/unified_validation.py"}},
    ]

    statuses = [v.get("status", "FAIL") for v in validators]
    status = _worst_status(statuses)
    recommendation = "ACCEPT" if status == "PASS" else ("ACCEPT_WITH_RECOMMENDATIONS" if status == "WARNING" else "REJECT")

    findings = []
    for v in validators:
        if v.get("status") != "PASS":
            findings.append({"validator_id": v.get("validator_id"), "status": v.get("status"), "details": v})

    report = {
        "version": (base / "VERSION").read_text(encoding="utf-8").strip() if (base / "VERSION").exists() else "unknown",
        "status": status,
        "recommendation": recommendation,
        "origin": "runtime/validation/unified_validation.py",
        "policy": "single-source-of-truth: final status is the worst status across runtime, reference, document, strict-json, coverage and authenticity validators",
        "findings": findings,
        "validators": validators,
    }
    raw = json.dumps(report, indent=2, sort_keys=True, allow_nan=False)
    report["sha256"] = hashlib.sha256(raw.encode("utf-8")).hexdigest()
    Path(out).write_text(json.dumps(report, indent=2, sort_keys=True, allow_nan=False), encoding="utf-8")
    return report

if __name__ == "__main__":
    root = sys.argv[1] if len(sys.argv) > 1 else "."
    out = sys.argv[2] if len(sys.argv) > 2 else "validation-report.json"
    print(json.dumps(build_unified_report(root, out), indent=2, allow_nan=False))
