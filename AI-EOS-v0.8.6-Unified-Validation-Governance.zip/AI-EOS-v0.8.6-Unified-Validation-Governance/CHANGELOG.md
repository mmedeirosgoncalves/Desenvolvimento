---
id: changelog
version: 0.8.6
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: true
depends_on: []
used_by: []
supersedes: null
---

# Changelog

## v0.8.6 — Unified Validation Governance

- Introduced unified validation engine.
- Removed split final status between runtime validator and reference validator.
- Added document freshness policy.
- Added ADR-0042.
- Replaced informal external-system naming with neutral release nomenclature.
