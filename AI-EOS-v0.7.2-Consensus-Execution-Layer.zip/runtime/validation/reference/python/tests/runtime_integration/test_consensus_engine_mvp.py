from pathlib import Path
import sys, json, tempfile
ROOT = Path(__file__).resolve().parents[6]
sys.path.insert(0, str(ROOT))
from runtime.consensus.engine import ConsensusEngine, ConsensusInput
from runtime.consensus.provider_interface import ProviderResponse
from runtime.consensus.metrics import consensus_gain_index, consensus_cost_index, consensus_latency_ratio, consensus_agreement_rate
from runtime.consensus.reporting import build_consensus_report, write_consensus_report

responses = [
    ProviderResponse(provider_id="mock-a", task_id="T-001", content="Use a provider abstraction. Add metrics."),
    ProviderResponse(provider_id="mock-b", task_id="T-001", content="Use a provider abstraction. Keep reports deterministic."),
    ProviderResponse(provider_id="mock-c", task_id="T-001", content="Use a provider abstraction. Add tests."),
]
result = ConsensusEngine().build(ConsensusInput(task_id="T-001", responses=responses))
assert result.provider_count == 3
assert any("provider abstraction" in x.lower() for x in result.shared_claims), result
assert result.agreement_rate > 0
assert consensus_gain_index(9.0, [7.0, 8.5, 8.0]) == 0.5
assert consensus_cost_index(10.0, 2.0) == 5.0
assert consensus_latency_ratio(200, 100) == 2.0
assert consensus_agreement_rate(2, 4) == 0.5
report = build_consensus_report("EXEC-001", responses, result)
assert report["version"] == "0.7.2"
with tempfile.TemporaryDirectory() as tmp:
    out = Path(tmp) / "report.json"
    write_consensus_report(out, report)
    loaded = json.loads(out.read_text(encoding="utf-8"))
    assert loaded["execution_id"] == "EXEC-001"
