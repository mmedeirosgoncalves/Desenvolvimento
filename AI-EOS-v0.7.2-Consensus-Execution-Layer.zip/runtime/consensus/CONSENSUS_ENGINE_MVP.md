---
id: consensus-engine-mvp
version: 0.7.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: false
depends_on: []
used_by: []
supersedes: null
---


# Consensus Engine MVP

AI-EOS v0.7.1 introduces the first executable consensus engine.

## Scope

The MVP can:

- accept independent provider responses;
- normalize candidate claims;
- identify shared claims;
- flag simple explicit conflicts;
- generate deterministic JSON reports;
- expose metrics hooks for CGI, CCI, CLR and CAR.

## Non-goals

This MVP does not implement the Divergence Engine, Judge Engine, Adaptive Orchestrator, debate between agents or continuous learning.
