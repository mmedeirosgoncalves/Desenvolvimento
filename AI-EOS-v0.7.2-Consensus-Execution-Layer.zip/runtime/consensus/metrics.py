"""Consensus metrics for AI-EOS v0.7.1."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Sequence

@dataclass(frozen=True)
class ConsensusMetricInput:
    consensus_score: float
    individual_scores: Sequence[float]
    consensus_cost: float = 0.0
    consensus_latency_ms: int = 0
    best_individual_latency_ms: int = 0
    agreement_rate: float = 0.0

def consensus_gain_index(consensus_score: float, individual_scores: Sequence[float]) -> float:
    if not individual_scores:
        raise ValueError("individual_scores must not be empty")
    return float(consensus_score) - max(float(x) for x in individual_scores)

def consensus_cost_index(quality: float, cost: float) -> float:
    if cost <= 0:
        return float("inf") if quality > 0 else 0.0
    return float(quality) / float(cost)

def consensus_latency_ratio(consensus_latency_ms: int, best_individual_latency_ms: int) -> float:
    if best_individual_latency_ms <= 0:
        return float("inf") if consensus_latency_ms > 0 else 1.0
    return float(consensus_latency_ms) / float(best_individual_latency_ms)

def consensus_agreement_rate(shared_claims: int, total_claims: int) -> float:
    if total_claims <= 0:
        return 0.0
    return max(0.0, min(1.0, float(shared_claims) / float(total_claims)))
