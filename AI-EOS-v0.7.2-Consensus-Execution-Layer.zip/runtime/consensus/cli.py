"""Operational entry points for the AI-EOS consensus execution layer.

v0.7.2 turns the v0.7.1 Consensus Engine from a tested library into a
usable local execution capability. The CLI is intentionally deterministic and
network-free: real provider calls remain outside this release, while real
artifacts can be supplied as JSON inputs.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from .engine import ConsensusEngine, ConsensusInput
from .metrics import (
    consensus_gain_index,
    consensus_cost_index,
    consensus_latency_ratio,
    consensus_agreement_rate,
)
from .provider_interface import ProviderRequest, ProviderResponse, MockProvider
from .reporting import build_consensus_report, write_consensus_report


def _load_json(path: str | Path) -> dict[str, Any]:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def _response_from_dict(item: dict[str, Any], fallback_task_id: str) -> ProviderResponse:
    return ProviderResponse(
        provider_id=str(item.get("provider_id") or item.get("id") or "provider"),
        task_id=str(item.get("task_id") or fallback_task_id),
        content=str(item.get("content") or item.get("response") or ""),
        latency_ms=int(item.get("latency_ms", 0) or 0),
        input_tokens=int(item.get("input_tokens", 0) or 0),
        output_tokens=int(item.get("output_tokens", 0) or 0),
        cost=float(item.get("cost", 0.0) or 0.0),
        metadata=item.get("metadata", {}) or {},
    )


def run_consensus_payload(payload: dict[str, Any]) -> dict[str, Any]:
    task_id = str(payload.get("task_id") or payload.get("execution_id") or "TASK-UNSPECIFIED")
    responses = [_response_from_dict(x, task_id) for x in payload.get("responses", [])]

    # Optional offline provider fixture support. This lets the CLI run a real
    # provider abstraction path without any network dependency.
    for item in payload.get("mock_providers", []):
        provider = MockProvider(str(item["provider_id"]), str(item["response_text"]), cost=float(item.get("cost", 0.0) or 0.0))
        request = ProviderRequest(task_id=task_id, prompt=str(payload.get("prompt", "")))
        responses.append(provider.complete(request))

    result = ConsensusEngine().build(ConsensusInput(task_id=task_id, responses=responses))
    report = build_consensus_report(str(payload.get("execution_id") or f"EXEC-{task_id}"), responses, result)

    scores = [float(x) for x in payload.get("individual_scores", [])]
    consensus_score = payload.get("consensus_score")
    if consensus_score is not None and scores:
        report["metrics"] = {
            "CGI": consensus_gain_index(float(consensus_score), scores),
            "CCI": consensus_cost_index(float(consensus_score), float(report["cost"])),
            "CLR": consensus_latency_ratio(result.latency_ms, min([r.latency_ms for r in responses if r.latency_ms > 0] or [0])),
            "CAR": consensus_agreement_rate(len(result.shared_claims), len(result.shared_claims) + sum(len(v) for v in result.unique_claims.values())),
        }
    else:
        report["metrics"] = {
            "CGI": None,
            "CCI": consensus_cost_index(result.agreement_rate, float(report["cost"])),
            "CLR": consensus_latency_ratio(result.latency_ms, min([r.latency_ms for r in responses if r.latency_ms > 0] or [0])),
            "CAR": result.agreement_rate,
        }
    return report


def run_benchmark_suite(path: str | Path, output_dir: str | Path) -> dict[str, Any]:
    suite = _load_json(path)
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    reports = []
    for idx, case in enumerate(suite.get("cases", []), start=1):
        task_id = str(case.get("task_id") or f"CASE-{idx:03d}")
        if "responses" in case or "mock_providers" in case:
            payload = dict(case)
        else:
            claim = case.get("expected_shared_claim", "provider abstraction")
            payload = {
                "execution_id": f"BENCH-{task_id}",
                "task_id": task_id,
                "prompt": case.get("prompt", ""),
                "mock_providers": [
                    {"provider_id": "bench-a", "response_text": f"Use {claim}. Keep reports deterministic."},
                    {"provider_id": "bench-b", "response_text": f"Use {claim}. Add an executable entry point."},
                ],
            }
        report = run_consensus_payload(payload)
        report_path = out / f"{task_id}.consensus-report.json"
        write_consensus_report(report_path, report)
        reports.append({"task_id": task_id, "report_path": str(report_path), "agreement_rate": report["consensus_result"]["agreement_rate"]})
    summary = {
        "benchmark_id": suite.get("benchmark_id", "BENCH-UNSPECIFIED"),
        "version": "0.7.2",
        "case_count": len(reports),
        "reports": reports,
    }
    (out / "benchmark-summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True), encoding="utf-8")
    return summary


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="aieos-consensus", description="AI-EOS consensus execution layer")
    sub = parser.add_subparsers(dest="command", required=True)

    c = sub.add_parser("consensus", help="run consensus over a JSON execution artifact")
    c.add_argument("--input", required=True, help="JSON file with task_id and responses or mock_providers")
    c.add_argument("--output", required=True, help="output JSON report path")

    b = sub.add_parser("benchmark", help="run a benchmark suite through the consensus engine")
    b.add_argument("--suite", required=True, help="benchmark suite JSON path")
    b.add_argument("--output-dir", required=True, help="directory for benchmark reports")

    args = parser.parse_args(argv)
    if args.command == "consensus":
        report = run_consensus_payload(_load_json(args.input))
        write_consensus_report(args.output, report)
        print(json.dumps({"status": "PASS", "output": args.output, "agreement_rate": report["consensus_result"]["agreement_rate"]}, sort_keys=True))
        return 0
    if args.command == "benchmark":
        summary = run_benchmark_suite(args.suite, args.output_dir)
        print(json.dumps({"status": "PASS", "case_count": summary["case_count"], "output_dir": args.output_dir}, sort_keys=True))
        return 0
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
