---
id: consensus-metrics
version: 0.7.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
release_document: false
depends_on: [multi-ai-consensus-experiment]
used_by: []
supersedes: null
---

# Consensus Metrics

Metrics: Consensus Score, Novelty Score, Diversity Score, Evidence Coverage, Risk Coverage and Human Agreement.

High consensus and low novelty must be flagged as possible convergence bias.


## v0.7.1 Executable Metrics

The MVP implements CGI, CCI, CLR and CAR in `runtime/consensus/metrics.py`. These functions are intentionally deterministic and dependency-free so release validation can run offline.
