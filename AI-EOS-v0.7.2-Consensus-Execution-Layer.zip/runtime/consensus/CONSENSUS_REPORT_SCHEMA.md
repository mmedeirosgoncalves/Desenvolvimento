---
id: consensus-report-schema
version: 0.7.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: false
depends_on: []
used_by: []
supersedes: null
---


# Consensus Report Schema

Every consensus execution emits machine-readable JSON with:

- execution id;
- engine and version;
- provider ids;
- individual responses;
- consensus result;
- cost;
- token usage;
- warnings.
