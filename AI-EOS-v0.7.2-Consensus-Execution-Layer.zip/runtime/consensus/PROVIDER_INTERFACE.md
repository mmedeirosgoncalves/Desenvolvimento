---
id: provider-interface
version: 0.7.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: false
depends_on: []
used_by: []
supersedes: null
---


# Provider Interface

All model providers must expose a deterministic local contract:

- `ProviderRequest`
- `ProviderResponse`
- `ProviderInterface.complete()`
- `MockProvider`

The MVP includes a mock provider so tests and benchmarks can run without network access or vendor credentials.
