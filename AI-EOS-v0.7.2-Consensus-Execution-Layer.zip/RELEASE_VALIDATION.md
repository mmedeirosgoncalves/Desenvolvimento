---
id: release-validation
version: 0.7.2
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-07
review_date: 2026-10-07
release_document: true
depends_on: [adr-0027, adr-0028, adr-0029, adr-0030, adr-0031, adr-0032]
used_by: []
supersedes: null
---

# Release Validation — v0.7.2 Consensus Execution Layer

## Scope

This release is an incremental merge over AI-EOS v0.7.1. It preserves the v0.7.1 Consensus Engine MVP and adds an operational execution layer: CLI entry points, sample execution artifact, benchmark runner, QG-015 and ADR-0032.

## Results

| Check | Result | Evidence |
|---|---|---|
| Baseline preservation | PASS | v0.7.1 files preserved; no removed files |
| Package structure | PASS | No nested release-only package; project root retained |
| Version metadata | PASS | `VERSION` = 0.7.2 and release documents aligned |
| Package manifest | PASS | Manifest count aligned with validator-visible Markdown files |
| Python syntax | PASS | test runner imports executable consensus modules |
| Test runner | PASS | 11/11 tests passing |
| Consensus CLI | PASS | `python -m runtime.consensus consensus` writes JSON report |
| Benchmark runner | PASS | `python -m runtime.consensus benchmark` writes per-case reports and summary |
| Consensus Engine MVP | PASS | v0.7.1 engine preserved and callable |
| Provider abstraction | PASS | MockProvider path exercised through CLI |
| Metrics | PASS | CGI, CCI, CLR and CAR preserved |
| Reporting | PASS | Deterministic JSON reports preserved |
| Reference validator | PASS | status=PASS; recommendation=ACCEPT |

## Operational Smoke Commands

```bash
python -m runtime.consensus consensus --input examples/consensus/sample_execution.json --output reports/sample-consensus-report.json
python -m runtime.consensus benchmark --suite experiments/benchmark_suite/mvp_cases.json --output-dir reports/benchmark
python runtime/validation/reference/python/run_tests.py
python runtime/validation/reference/python/ai_eos_validate.py . --output validation-report.json
```

## Test Runner Output

```text
tests/reproducibility/test_path_normalization.py: PASS
tests/runtime_integration/test_allowed_duplicate_group_api.py: PASS
tests/runtime_integration/test_comparators_integration.py: PASS
tests/runtime_integration/test_consensus_engine_mvp.py: PASS
tests/runtime_integration/test_consensus_execution_layer.py: PASS
tests/runtime_integration/test_manifest_path_normalization.py: PASS
tests/runtime_integration/test_multi_ai_consensus_artifacts.py: PASS
tests/runtime_integration/test_release_document_policy.py: PASS
tests/runtime_integration/test_version_consistency_validator.py: PASS
tests/runtime_integration/test_yaml_validation.py: PASS
tests/test_negative_fixtures.py: PASS
PASSED_TESTS=11
```

## Validation Report Summary

```json
{
  "status": "PASS",
  "recommendation": "ACCEPT",
  "markdown_files": 302,
  "yaml_files": 5,
  "findings": 0,
  "high": 0,
  "medium": 0,
  "low": 0
}
```

## v0.7.2 Added Files

- architecture/adr/ADR-0032-consensus-execution-layer.md
- runtime/consensus/CONSENSUS_EXECUTION_LAYER.md
- runtime/consensus/BENCHMARK_RUNNER.md
- runtime/consensus/cli.py
- runtime/consensus/__main__.py
- runtime/quality-gates/QG-015-consensus-execution-entrypoint.md
- examples/consensus/sample_execution.json
- runtime/validation/reference/python/tests/runtime_integration/test_consensus_execution_layer.py

## Residual Scope

- External model providers remain outside the release.
- Divergence Engine remains planned for v0.8.0.
- Judge Engine remains planned after divergence handling.
