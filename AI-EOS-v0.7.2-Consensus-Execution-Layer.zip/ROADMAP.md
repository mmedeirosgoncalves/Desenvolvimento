---
id: roadmap
version: 0.7.2
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-07
release_document: true
review_date: 2026-10-06
depends_on: [knowledge-runtime-contract, adr-0023]
used_by: []
supersedes: null
---

# AI-EOS Roadmap

## v0.7.0 — Multi-AI Consensus Experiment

- Introduced experimental Multi-AI Consensus framework.
- Added Independent Execution Protocol.
- Added Consensus Analyzer, Consensus Metrics and Divergence Report.
- Added Devil's Advocate Protocol.
- Added Human Review Protocol.
- Added experiment templates.
- Added ADR-0027 through ADR-0030.
- Added QG-010 through QG-014.

## v0.6.1.0 — Validation Governance

- Introduced explicit release-document classification using `release_document: true`.
- Added root `VERSION` file as the single framework-version source.
- Removed hardcoded release-document allow-list from the version validator.
- Marked root `README.md` as a release document and aligned its version.
- Added ADR-0026 and RELEASE_DOCUMENT_POLICY.
- Added runtime integration tests for release-document classification.

## v0.6.0.3 — Validation Hygiene

- Removed external environment traceback noise from release validation records.
- Aligned release-level version metadata.
- Extended `version-consistency-validator` to report stale release-document versions.
- Added ADR-0025 Validation Hygiene.
- Added runtime integration test for version metadata consistency.

## v0.6.0.2 — Safety Net + Audit Remediation Governance

- Restored fixture-root detection in the reference validator.
- Restored render, duplication and version validators.
- Preserved `allowed_duplicate_group` compatibility.
- Added in-package validation test runner.
- Added ARP governance: ADR-0024, audit remediation policy, template and decision rules.
- RELEASE_VALIDATION now treats failing tests as release failure.

## v0.6.0.1 — Runtime Integration

- Integrate comparator utilities into executable validator path.
- Validate Knowledge Pack YAML artifacts.
- Validate Knowledge Registry.
- Add Specification Coverage Validator.
- Regenerate validation report.

## v0.6.1 — Knowledge Runtime Validator Expansion

- Add richer negative YAML fixtures.
- Add cycle detection for package dependencies.
- Add capability conflict detection.
- Add registry drift detection.

## v0.7 — Knowledge Pack Expansion

- Populate Knowledge Packs beyond Security.
- Add examples, references and decision trees.

## v0.8 — Skill Runtime

- Refactor Skills as application mechanisms.

## v0.9 — Agent Runtime

- Specialist agent orchestration.

## v1.0 — Stable AI-EOS

- Stable platform.


## v0.7.1 — Consensus Engine MVP

- Implement executable consensus engine.
- Add provider abstraction, metrics, benchmark integration and JSON reporting.
- Preserve v0.7.0 as the baseline and evolve by incremental merge.

## v0.7.2 — Consensus Optimization

- Improve consolidation quality.
- Expand benchmark coverage.
- Harden metrics and failure analysis.


## v0.7.2 — Consensus Execution Layer

The v0.7.2 milestone makes the Consensus Engine callable through an operational CLI and benchmark runner. It prepares v0.8.0 Divergence Engine integration by ensuring there is a real execution flow to extend.

Next: v0.8.0 Divergence Engine.
