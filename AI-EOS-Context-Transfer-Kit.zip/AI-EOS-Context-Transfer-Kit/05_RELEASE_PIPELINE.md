# Pipeline de release

Fluxo usado:
1. partir da última release verificada;
2. receber auditoria;
3. separar achados reais, contrapontos e pontos cegos;
4. definir escopo mínimo;
5. implementar;
6. atualizar VERSION, README, CHANGELOG, ROADMAP, manifest e release validation;
7. rodar validação oficial;
8. empacotar ZIP;
9. pedir auditoria externa;
10. repetir.

Critérios de aceite:
- identidade coerente;
- sem stale docs ativos;
- sem relatório fabricado;
- JSON estrito;
- novos módulos integrados;
- validador oficial respeitado.
