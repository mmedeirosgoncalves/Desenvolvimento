# Decisões do projeto

D-001: O validador oficial é fonte de verdade.

D-002: Relatório manual não substitui validação executável.

D-003: Release identity precisa bater em VERSION, README, CHANGELOG, ROADMAP, manifest e relatório.

D-004: Estado mutável deve ficar fora de runtime.

D-005: Evidência deve ser append-only sempre que possível.

D-006: Módulo órfão não é feature.

D-007: Adapter de provedor deve falhar fechado se acesso não existir.

D-008: Modelos visíveis no Devin Desktop não são automaticamente endpoints programáticos.

D-009: Evitar nomenclatura informal em docs oficiais; usar “External Agent System” quando necessário.
