# Histórico resumido

v0.6.x: knowledge pack, YAML, manifest, validation hygiene.
v0.7.x: consensus engine e execution layer.
v0.8.0: multi-AI runtime foundation.
v0.8.1: discovery adapter.
v0.8.2: Devin CLI provider attempt.
v0.8.3: adaptive multi-agent pipeline.
v0.8.4: runtime integration attempt.
v0.8.5: validation truthfulness.
v0.8.6/v0.8.7: naming cleanup e project control plane.
v0.8.8: project lifecycle e append-only evidence.
