# Memória consolidada da conversa

Preferências da usuária:
- análise crítica;
- clareza sobre limitações;
- foco em release real;
- contrapontos e pontos cegos;
- validação executável;
- evitar confiança fabricada;
- preservar contexto ao mudar de IA.

Workflow estabelecido:
1. usuária traz análise ou print do Devin;
2. assistente interpreta;
3. assistente separa real, aparente e risco;
4. assistente propõe próxima release;
5. assistente gera ZIP;
6. usuária audita externamente;
7. ciclo continua.
