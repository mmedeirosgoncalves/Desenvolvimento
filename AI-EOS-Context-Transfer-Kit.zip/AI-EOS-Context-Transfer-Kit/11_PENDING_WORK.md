# Pendências

Imediatas:
1. Auditar v0.8.8 externamente.
2. Verificar warning do unified_validation.
3. Verificar timeout do test runner global.
4. Definir se v0.8.9 será Provider Layer Consolidation.

Pendências técnicas recorrentes:
- provider layers duplicadas;
- módulos só usados por testes;
- stale docs;
- reports manuais;
- JSON strictness;
- integração real com orchestrator;
- evidência append-only;
- controle de permissões.
