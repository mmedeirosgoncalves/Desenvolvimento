# Roadmap

Concluído/parcial:
- v0.6.x: knowledge pack e validation hygiene;
- v0.7.x: consensus e execution layer;
- v0.8.0: multi-AI runtime foundation;
- v0.8.1–v0.8.5: Devin/provider/validation truthfulness;
- v0.8.7: project control plane foundation;
- v0.8.8: project lifecycle e append-only evidence.

Próxima sugestão:
```text
v0.8.9 — Provider Layer Consolidation
```

Escopo sugerido:
- escolher camada provider canônica;
- deprecar duplicatas;
- integrar provider registry ao orchestrator;
- provar caminho com smoke test;
- atualizar validador oficial.
