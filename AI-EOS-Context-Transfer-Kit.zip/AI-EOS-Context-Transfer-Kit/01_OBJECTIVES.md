# Objetivos do AI-EOS

AI-EOS é um framework portátil, auditável e orientado por evidência para trabalho estruturado com IA.

Objetivos:
- executar múltiplas IAs/provedores;
- coletar respostas independentes;
- normalizar claims;
- detectar consenso e conflito;
- acionar revisão humana;
- orientar geração de código;
- validar artefatos;
- manter trilha de auditoria;
- controlar projetos, tarefas, decisões e evidências.

Não é:
- apenas uma coleção de prompts;
- role-play;
- gerador de relatório verde;
- runtime alegado sem execução;
- documentação vendida como integração.
