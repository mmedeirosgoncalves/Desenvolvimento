# Arquitetura vigente

Camadas principais:
1. consensus runtime;
2. provider layer;
3. multi-AI orchestration;
4. codegen layer;
5. validation layer;
6. project control plane;
7. evidence ledger.

Regra central:
feature só conta se estiver implementada, importada pelo caminho real, testada, validada e documentada.

Maior risco recorrente:
ship tested-but-unwired modules — módulos testados em isolamento, mas não usados pelo runtime.
