# Prompts úteis

## Auditoria externa

```text
Audit this AI-EOS release read-only.
Execute official validation where possible.
Check release identity, stale docs, orphan modules, runtime integration, JSON strictness, provider wiring, and report truthfulness.
Return verdict, real fixes, blockers, risks, and next recommendations.
```

## Criação de release

```text
Create the next AI-EOS release from the last verified package.
Use audit findings.
Implement only the scoped goal.
Do not fabricate green validation.
Update docs and ADRs.
Run official validation.
Package as ZIP.
```
