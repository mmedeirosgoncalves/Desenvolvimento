# Análises externas

Devin encontrou repetidamente:
- mismatch de versão;
- stale docs;
- código morto;
- módulos órfãos;
- validação manual mascarando warning;
- JSON com Infinity;
- duplicação de provider layers;
- runtime integration incompleta.

Crítica externa útil:
AI-EOS tinha boa taxonomia e portabilidade, mas precisava de runtime real, memória, verificação, permissões, evals e adapters.

Aprendizado incorporado:
- skills com metadata;
- gates executáveis;
- guardrails reais;
- workspace isolation;
- decision trees/templates;
- auditoria de divergência.
