# Contexto do projeto

O projeto evoluiu por ciclos de release com auditorias externas, principalmente no Devin.

Padrão recorrente identificado:
- documentação ou módulos eram adicionados;
- relatórios afirmavam progresso;
- mas o código nem sempre estava conectado ao runtime;
- em algumas versões, relatórios mascaravam warnings do validador oficial.

Disciplina adotada:
- auditar cada release;
- confiar no validador oficial;
- procurar stale docs;
- procurar código órfão;
- exigir integração real;
- registrar ADRs e decisões.
