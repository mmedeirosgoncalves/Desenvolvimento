# AI-EOS — Context Transfer Kit

## Como usar

Entregue este ZIP para outra IA antes de pedir continuidade.

Instrução recomendada:

```text
Leia os arquivos deste kit na ordem indicada em INDEX.json.
Depois responda com:
1. entendimento do projeto;
2. estado atual;
3. próximo passo recomendado;
4. riscos, contradições ou premissas obsoletas.

Não crie nova release antes de separar o que é histórico, o que está vigente e qual evidência sustenta a decisão.
```

Este kit é memória operacional consolidada, não transcrição integral.
