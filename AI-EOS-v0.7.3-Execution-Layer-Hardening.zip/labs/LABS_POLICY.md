---
id: labs-policy
version: 0.3.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [target-architecture]
used_by: []
supersedes: null
---

# Labs Policy

Labs contains experimental ideas.

## Rules

1. Labs content is not stable.
2. Labs content must not be required by stable modules.
3. Labs content can graduate only through review and ADR.
4. Experimental concepts must state risks and intended evaluation criteria.
