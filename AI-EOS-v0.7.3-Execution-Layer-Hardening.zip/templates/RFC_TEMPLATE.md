---
id: rfc_template
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: []
used_by: []
supersedes: null
---

# RFC Template

## Summary
## Motivation
## Proposal
## Alternatives
## Risks
## Rollout Plan
## Open Questions
