---
id: risk_assessment_template
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: []
used_by: []
supersedes: null
---

# Risk Assessment Template

## Change
## Risk Areas
## Probability
## Impact
## Mitigations
## Residual Risk
