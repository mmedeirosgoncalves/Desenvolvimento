---
id: release_notes_template
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: []
used_by: []
supersedes: null
---

# Release Notes Template

## Version
## Summary
## Added
## Changed
## Fixed
## Risks
## Migration Notes
