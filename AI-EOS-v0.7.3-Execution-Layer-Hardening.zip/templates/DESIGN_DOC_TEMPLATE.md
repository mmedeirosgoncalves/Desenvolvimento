---
id: design_doc_template
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: []
used_by: []
supersedes: null
---

# Design Document Template

## Context
## Current State
## Proposed Design
## Architecture Diagram
## Components
## Data Flow
## Trade-offs
## Risks
## Rollout
## Rollback
