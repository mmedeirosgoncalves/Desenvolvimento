---
id: architecture_decision_tree
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: []
used_by: []
supersedes: null
---

# Architecture Decision Tree

1. Is there an existing pattern? Use it unless there is a strong reason not to.
2. Is the domain stable? If not, avoid heavy abstraction.
3. Is distribution required? If not, avoid distributed complexity.
4. Can the decision be reversed? If not, require ADR.
