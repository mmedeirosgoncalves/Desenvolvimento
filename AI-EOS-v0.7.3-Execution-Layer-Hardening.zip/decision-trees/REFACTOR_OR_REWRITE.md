---
id: refactor_or_rewrite
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: []
used_by: []
supersedes: null
---

# Refactor or Rewrite

Prefer refactor when business logic is valuable and incremental improvement is possible.
Consider rewrite only when change is unsafe, cost is unsustainable, and migration path is realistic.
