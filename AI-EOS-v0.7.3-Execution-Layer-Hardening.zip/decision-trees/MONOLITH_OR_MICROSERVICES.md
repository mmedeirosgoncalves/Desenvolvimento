---
id: monolith_or_microservices
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: []
used_by: []
supersedes: null
---

# Monolith or Microservices

Prefer modular monolith when team is small or boundaries are unclear.
Consider microservices when boundaries are stable and operational maturity exists.
