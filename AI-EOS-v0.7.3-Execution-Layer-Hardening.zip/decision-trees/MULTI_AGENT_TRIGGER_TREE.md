---
id: multi_agent_trigger_tree
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [multi-agent-trigger-policy]
used_by: []
supersedes: null
---

# Multi-Agent Trigger Tree

Reference `runtime/routing/MULTI_AGENT_TRIGGER_POLICY.md` as the authoritative source. This tree is explanatory only.
