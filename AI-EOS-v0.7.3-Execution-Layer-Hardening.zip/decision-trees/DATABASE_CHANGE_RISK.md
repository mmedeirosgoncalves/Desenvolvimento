---
id: database_change_risk
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: []
used_by: []
supersedes: null
---

# Database Change Risk

Require review if change alters existing data, breaks compatibility, requires downtime, affects multiple services, has hard rollback, or risks data loss.
