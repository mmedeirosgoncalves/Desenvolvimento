---
id: playbook-migration
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: []
used_by: []
supersedes: null
---

# Migration Playbook

## Steps

1. Define source and target.
2. Assess risk.
3. Plan rollout.
4. Plan rollback.
5. Validate.

## Relevant Quality Gates

- QG-006
- QG-008

## Output

- summary
- assumptions
- validation
- risks
- quality gate results
