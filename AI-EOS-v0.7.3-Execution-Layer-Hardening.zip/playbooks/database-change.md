---
id: playbook-database-change
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: []
used_by: []
supersedes: null
---

# Database Change Playbook

## Steps

1. Identify schema impact.
2. Assess compatibility.
3. Plan migration.
4. Plan rollback.
5. Validate data integrity.

## Relevant Quality Gates

- QG-006
- QG-008

## Output

- summary
- assumptions
- validation
- risks
- quality gate results
