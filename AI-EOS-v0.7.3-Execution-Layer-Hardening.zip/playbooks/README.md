---
id: playbooks-index
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: []
used_by: []
supersedes: null
---

# Playbooks Index

Playbooks are procedural guides.

They should reference Skills and Quality Gates when applicable.
