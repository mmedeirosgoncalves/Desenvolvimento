---
id: playbook-api-change
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: []
used_by: []
supersedes: null
---

# Api Change Playbook

## Steps

1. Identify consumers.
2. Define contract change.
3. Assess compatibility.
4. Update docs.
5. Add contract tests.

## Relevant Quality Gates

- QG-001
- QG-002
- QG-003

## Output

- summary
- assumptions
- validation
- risks
- quality gate results
