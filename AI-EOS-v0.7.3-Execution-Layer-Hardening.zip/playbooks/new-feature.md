---
id: playbook-new-feature
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: []
used_by: []
supersedes: null
---

# New Feature Playbook

## Steps

1. Clarify goal.
2. Define scope.
3. Create spec.
4. Implement incrementally.
5. Test.
6. Document.

## Relevant Quality Gates

- QG-001
- QG-003
- QG-004

## Output

- summary
- assumptions
- validation
- risks
- quality gate results
