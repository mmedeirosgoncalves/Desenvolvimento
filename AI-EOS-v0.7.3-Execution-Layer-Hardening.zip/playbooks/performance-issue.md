---
id: playbook-performance-issue
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: []
used_by: []
supersedes: null
---

# Performance Issue Playbook

## Steps

1. Measure.
2. Identify bottleneck.
3. Optimize minimally.
4. Benchmark.
5. Monitor.

## Relevant Quality Gates

- QG-005

## Output

- summary
- assumptions
- validation
- risks
- quality gate results
