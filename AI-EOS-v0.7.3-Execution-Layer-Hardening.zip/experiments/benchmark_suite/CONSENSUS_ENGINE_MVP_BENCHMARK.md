---
id: consensus-engine-mvp-benchmark
version: 0.7.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: false
depends_on: []
used_by: []
supersedes: null
---


# Consensus Engine MVP Benchmark

The initial benchmark verifies that the engine can consolidate overlapping claims from independent responses and produce auditable metrics.

## Baseline

The baseline is the best individual response score.

## Required Metrics

- CGI: Consensus Gain Index.
- CCI: Consensus Cost Index.
- CLR: Consensus Latency Ratio.
- CAR: Consensus Agreement Rate.
