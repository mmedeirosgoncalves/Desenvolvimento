---
id: experiment-lifecycle
version: 0.7.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
release_document: false
depends_on: [multi-ai-consensus-experiment]
used_by: []
supersedes: null
---

# Experiment Lifecycle

```text
planned -> dispatched -> collected -> analyzed -> challenged -> reviewed -> closed
```
