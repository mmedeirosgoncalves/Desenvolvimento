---
id: experiment-result-schema
version: 0.7.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
release_document: false
depends_on: [experiment-lifecycle]
used_by: []
supersedes: null
---

# Experiment Result Schema

```yaml
experiment_id:
objective:
scope:
models:
inputs:
outputs:
consensus_metrics:
divergence_report:
devils_advocate_report:
human_decision:
final_status:
```

Human decision values:

- accept_majority
- accept_minority
- synthesize
- request_iteration
- reject_all
- defer
