---
id: experiments-index
version: 0.7.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
release_document: false
depends_on: [adr-0027]
used_by: []
supersedes: null
---

# Experiments

The experiments layer provides controlled AI-EOS experiments.

v0.7.0 introduces the Multi-AI Consensus Experiment.
