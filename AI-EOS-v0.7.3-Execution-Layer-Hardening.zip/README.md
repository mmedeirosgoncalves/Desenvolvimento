---
id: readme
version: 0.7.3
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: true
depends_on: [adr-0032]
used_by: []
supersedes: null
---

# AI-EOS v0.7.3 — Execution Layer Hardening

AI-EOS v0.7.3 hardens the v0.7.2 Consensus Execution Layer before any Multi-AI runtime expansion.

## Release Objective

This release stabilizes the operational execution layer by enforcing strict JSON compatibility, QG-015 governance integration, CLI input validation, structured CLI errors, deterministic report serialization and updated release documentation.

## Operational Commands

```bash
python -m runtime.consensus consensus --input examples/consensus/sample_execution.json --output reports/sample-consensus-report.json
python -m runtime.consensus benchmark --suite experiments/benchmark_suite/mvp_cases.json --output-dir reports/benchmark
```

## Validation Commands

```bash
python runtime/validation/reference/python/run_tests.py
python runtime/validation/reference/python/ai_eos_validate.py . --output validation-report.json
python -m runtime.consensus consensus --input examples/consensus/sample_execution.json --output reports/sample-consensus-report.json
python -m runtime.consensus benchmark --suite experiments/benchmark_suite/mvp_cases.json --output-dir reports/benchmark
```

## Scope

v0.7.3 preserves the v0.7.2 execution model and hardens its operational boundary. Real external model API calls remain outside this release.
