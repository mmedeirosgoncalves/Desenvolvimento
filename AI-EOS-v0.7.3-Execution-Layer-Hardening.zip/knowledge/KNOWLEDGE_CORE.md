---
id: knowledge-core
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: []
used_by: [agents-entry-point, system-architecture]
supersedes: null
---

# Knowledge Core

The Knowledge Core contains domain-specific engineering knowledge.

It is separate from Skills.

## Purpose

Knowledge Packs define what the agent should know.

Skills define how the agent applies that knowledge.

## Rule

Do not put large bodies of domain knowledge directly inside skills when they can be shared by multiple skills.

## Initial Knowledge Packs

- security
- architecture
- api
- database
- testing
- databricks
- legacy
