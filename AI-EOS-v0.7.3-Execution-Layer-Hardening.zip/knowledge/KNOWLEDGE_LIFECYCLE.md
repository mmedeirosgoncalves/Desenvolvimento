---
id: knowledge-lifecycle
version: 0.6.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [knowledge-pack-spec]
used_by: []
supersedes: null
---

# Knowledge Lifecycle

## Lifecycle States

```text
Draft -> Experimental -> Validated -> Stable -> Deprecated -> Archived
```

## Draft

Initial concept. Not recommended for runtime use.

## Experimental

Structured enough for testing, but not stable.

## Validated

Reviewed and validated against Canon and Quality Gates.

## Stable

Approved for normal Runtime and Skill consumption.

## Deprecated

Still available, but replacement exists or is planned.

## Archived

Retained for historical reference only.

## Promotion Criteria

A Knowledge Pack can only be promoted when:

- metadata is complete;
- dependencies resolve;
- exported capabilities are documented;
- consumers are known or explicitly empty;
- validation reports are available.
