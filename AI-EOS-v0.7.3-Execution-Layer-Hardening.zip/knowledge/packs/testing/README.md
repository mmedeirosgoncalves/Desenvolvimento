---
id: kp-testing
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: []
used_by: []
supersedes: null
---

# Testing Knowledge Pack

## Current Status

Initial knowledge pack.

## Principles

- Test behavior, not implementation details.
- Add regression tests for bugs.
- Balance unit, integration and end-to-end tests.
- Tests should reduce uncertainty.

## Future Expansion

This pack should be expanded with:

- domain standards
- checklists
- examples
- anti-patterns
- decision rules
