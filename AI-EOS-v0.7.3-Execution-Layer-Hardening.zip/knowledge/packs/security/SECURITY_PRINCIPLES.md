---
id: kp-security-principles
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: []
used_by: [skill-security-review]
supersedes: null
---

# Security Principles

## Least Privilege

Grant only the minimum permissions required.

## Defense in Depth

Do not rely on a single control.

## Secure by Default

Unsafe behavior should require explicit opt-in.

## Fail Secure

Failure modes should not expose sensitive data or grant access.

## Complete Mediation

Every access to protected resources should be checked.

## Separation of Duties

Avoid combining conflicting privileges in a single role or component.

## Minimize Sensitive Data

Collect, store and expose only what is necessary.
