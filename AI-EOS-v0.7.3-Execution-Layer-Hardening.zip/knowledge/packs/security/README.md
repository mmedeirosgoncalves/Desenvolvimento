---
id: kp-security-readme
version: 0.6.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [knowledge-pack-spec]
used_by: []
supersedes: null
---

# Security Knowledge Pack

## Purpose

Operational Knowledge Pack for security concerns.

## Metadata

See `package.yaml`.

## Canon Dependencies

- canon-security
