---
id: kp-owasp-top10
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: []
used_by: [skill-security-review]
supersedes: null
---

# OWASP Top 10 Knowledge Pack

Use OWASP Top 10 as a reference taxonomy for web application security risk.

## Risk Categories

1. Broken Access Control
2. Cryptographic Failures
3. Injection
4. Insecure Design
5. Security Misconfiguration
6. Vulnerable and Outdated Components
7. Identification and Authentication Failures
8. Software and Data Integrity Failures
9. Security Logging and Monitoring Failures
10. Server-Side Request Forgery

## Application Guidance

When reviewing a change:

- map findings to categories when applicable
- do not force a category if irrelevant
- prioritize concrete evidence over checklist completion
- assess exploitability and impact separately
