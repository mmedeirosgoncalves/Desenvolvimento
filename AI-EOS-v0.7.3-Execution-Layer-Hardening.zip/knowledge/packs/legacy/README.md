---
id: kp-legacy
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: []
used_by: []
supersedes: null
---

# Legacy Knowledge Pack

## Current Status

Initial knowledge pack.

## Principles

- Legacy code contains business knowledge.
- Modernize incrementally.
- Prefer strangler pattern when replacing large systems.
- Add characterization tests before risky changes.

## Future Expansion

This pack should be expanded with:

- domain standards
- checklists
- examples
- anti-patterns
- decision rules
