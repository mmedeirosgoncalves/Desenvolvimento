---
id: kp-database
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: []
used_by: []
supersedes: null
---

# Database Knowledge Pack

## Current Status

Initial knowledge pack.

## Principles

- Protect data integrity.
- Plan schema migrations.
- Prefer explicit ownership.
- Avoid destructive changes without rollback strategy.

## Future Expansion

This pack should be expanded with:

- domain standards
- checklists
- examples
- anti-patterns
- decision rules
