---
id: knowledge-strategy
version: 0.3.2
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [canon-strategy]
used_by: [skill-model]
supersedes: null
---

# Knowledge Strategy

## Purpose

This document defines how AI-EOS manages the relationship between Canon, Knowledge Packs and Skills.

## Core Principle

```text
Canon -> Knowledge Packs -> Skills -> Playbooks / Runtime
```

## Canon

Canon contains durable engineering knowledge.

Canon should be slow-changing and broadly reusable.

## Knowledge Packs

Knowledge Packs adapt Canon into operational guidance for AI agents.

Knowledge Packs may be more specific and practical than Canon.

## Skills

Skills apply Knowledge Packs to concrete engineering tasks.

Skills should not duplicate Canon.

## Current Transitional State

As of v0.3.2, some mature content still exists primarily in Knowledge Packs, especially security.

This is intentional and transitional.

The Engineering Canon phase will gradually move stable, durable concepts into Canon while preserving operational Knowledge Packs.

## Rules

1. Canon should not depend on Skills.
2. Knowledge Packs may depend on Canon.
3. Skills must reference Knowledge Packs or Canon.
4. Skills must not present immature Knowledge as complete expertise.
5. Operational value must not be reduced during Canon migration.
