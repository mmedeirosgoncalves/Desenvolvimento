---
id: package-namespace-policy
version: 0.6.0.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [knowledge-pack-spec, adr-0023]
used_by: [package-kp-security, package-kp-architecture, package-kp-databricks]
supersedes: null
---

# Package Namespace Policy

## Purpose

Separate Markdown artifact ids from YAML package ids.

## Rule

YAML `package.yaml` ids remain runtime package identifiers, such as `kp-security`.

Markdown documents must not reuse those ids directly. When Markdown needs to reference a package identity, it uses the `package-kp-*` identity anchor.

## Example

- YAML package id: `kp-security`
- Markdown identity anchor: `package-kp-security`

This avoids cross-format ambiguity while preserving traceability.
