---
id: knowledge-boundaries
version: 0.6.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [knowledge-pack-spec]
used_by: []
supersedes: null
---

# Knowledge Pack Boundaries

## Purpose

Define the scope boundaries of Knowledge Packs.

## Rules

A Knowledge Pack should represent one coherent knowledge domain or reusable engineering capability.

Avoid:

- micro-packs with no independent value;
- monolithic packs containing unrelated domains;
- duplication of Canon;
- hidden dependencies;
- undocumented exports.

## Boundary Test

A pack boundary is acceptable when:

- its purpose can be explained in one paragraph;
- it has a stable owner;
- it has explicit dependencies;
- its exported capabilities are reusable;
- its consumers can be identified.

## Examples

Good boundaries:

- security-review
- architecture-review
- databricks-lakehouse
- api-contracts

Weak boundaries:

- miscellaneous-engineering
- all-cloud-knowledge
- temporary-notes
