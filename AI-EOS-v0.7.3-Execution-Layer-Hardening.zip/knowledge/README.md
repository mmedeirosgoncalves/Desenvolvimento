---
id: knowledge-index
version: 0.6.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [knowledge-pack-spec]
used_by: []
supersedes: null
---

# Knowledge

Knowledge is the AI-EOS layer that adapts Canon into operational, modular and consumable Knowledge Packs.

## Key Documents

- `KNOWLEDGE_PACK_SPEC.md`
- `KNOWLEDGE_LIFECYCLE.md`
- `KNOWLEDGE_BOUNDARIES.md`
- `KNOWLEDGE_MAP.md`

## Relationship

```text
Canon -> Knowledge Pack -> Skill -> Agent / Runtime
```
