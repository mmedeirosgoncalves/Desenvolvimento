---
id: failure-knowledge-base
version: 0.7.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: false
depends_on: []
used_by: []
supersedes: null
---


# Failure Knowledge Base

Consensus executions must preserve negative outcomes.

## Categories

- consensus_worse_than_best_individual;
- consensus_equal_to_best_individual;
- false_consensus;
- explicit_conflict;
- high_cost;
- high_latency;
- hallucination;
- regression.
