---
id: package-kp-security-principles
version: 0.6.0.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [package-kp-security]
used_by: [canon-security, skill-security-review]
supersedes: null
---

# Security Principles Package Identity

Markdown identity anchor for the security principles capability exported by the YAML package id `kp-security`.

This avoids reusing YAML package identifiers as Markdown artifact identifiers while preserving traceability.
