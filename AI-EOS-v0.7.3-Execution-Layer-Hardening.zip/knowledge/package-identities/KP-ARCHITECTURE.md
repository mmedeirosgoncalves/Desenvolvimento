---
id: package-kp-architecture
version: 0.6.0.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [knowledge-pack-spec]
used_by: [knowledge-map]
supersedes: null
---

# Architecture Knowledge Pack Identity

Markdown identity anchor for YAML package id `kp-architecture`.

This document prevents Markdown artifact ids from colliding with YAML package ids while preserving cross-reference resolution.
