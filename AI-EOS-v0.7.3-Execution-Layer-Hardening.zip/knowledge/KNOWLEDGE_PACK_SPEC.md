---
id: knowledge-pack-spec
version: 0.6.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [canon-map, knowledge-strategy]
used_by: [knowledge-runtime-contract]
supersedes: null
---

# Knowledge Pack Specification

## Purpose

A Knowledge Pack is the official modular unit of distributable knowledge in AI-EOS.

Knowledge Packs adapt Canon into operational knowledge that can be consumed by Skills, Agents and Runtime components.

## Required Structure

```text
knowledge/packs/<pack-id>/
├── package.yaml
├── README.md
├── PRINCIPLES.md
├── PATTERNS.md
├── CHECKLISTS.md
├── DECISION_TREE.md
└── REFERENCES.md
```

## Required Metadata

Each `package.yaml` must include:

```yaml
id:
name:
version:
owner:
status:
maturity:
review_date:
exports:
requires:
optional:
conflicts:
tags:
depends_on:
consumed_by:
```

## Status Values

- draft
- experimental
- validated
- stable
- deprecated
- archived

## Maturity Levels

- L0 Concept
- L1 Structured
- L2 Validated
- L3 Integrated
- L4 Stable

## Rule

Knowledge Packs must not duplicate Canon. They must reference Canon and adapt it to operational use.
