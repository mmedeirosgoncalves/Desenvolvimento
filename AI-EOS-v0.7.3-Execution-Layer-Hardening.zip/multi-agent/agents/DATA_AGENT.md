---
id: agent-data_agent
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: []
used_by: []
supersedes: null
---

# Data Agent

## Focus

data integrity, model, migration, pipeline risk.

## Output

- findings
- risks
- recommendations
- required gates
