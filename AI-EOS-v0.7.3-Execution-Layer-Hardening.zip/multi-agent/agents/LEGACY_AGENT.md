---
id: agent-legacy_agent
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: []
used_by: []
supersedes: null
---

# Legacy Agent

## Focus

legacy compatibility, modernization, strangler pattern.

## Output

- findings
- risks
- recommendations
- required gates
