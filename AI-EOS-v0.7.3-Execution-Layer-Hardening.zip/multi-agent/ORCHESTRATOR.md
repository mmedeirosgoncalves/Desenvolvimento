---
id: orchestrator
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [multi-agent-trigger-policy]
used_by: []
supersedes: null
---

# Multi-Agent Orchestrator

The Orchestrator coordinates specialist analysis.

## Responsibilities

- define task
- select agents
- distribute context
- require independent analysis
- collect outputs
- send to Consolidator

## Limitation

v0.2 defines protocol, not an executable software runtime.
