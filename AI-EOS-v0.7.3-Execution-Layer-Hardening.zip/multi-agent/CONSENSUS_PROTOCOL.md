---
id: consensus-protocol
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: []
used_by: []
supersedes: null
---

# Consensus Protocol

1. Independent analysis.
2. Conflict identification.
3. Trade-off comparison.
4. Final synthesis.
5. Decision record if significant.
