---
id: agent-contract-model
version: 0.3.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [target-architecture]
used_by: []
supersedes: null
---

# Agent Contract Model

## Definition

An Agent is a role that can be assumed by an AI system.

## Agent Contract

Each Agent must define:

- responsibilities
- required inputs
- produced outputs
- required Canon
- required Knowledge Packs
- required Skills
- Quality Gates
- escalation triggers
- success criteria

## Rule

Agents are not personalities.

Agents are operational roles.
