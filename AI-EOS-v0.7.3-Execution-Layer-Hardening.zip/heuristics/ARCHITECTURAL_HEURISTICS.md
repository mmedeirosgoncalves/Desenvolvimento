---
id: architectural_heuristics
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [engineering-principles]
used_by: []
supersedes: null
---

# Architectural Heuristics

- Do not distribute without need.
- Prefer modular monolith before microservices when boundaries are unclear.
- Use events to decouple, not to hide ownership confusion.
- Avoid shared databases between independent services.
- Every architecture must be explainable.
