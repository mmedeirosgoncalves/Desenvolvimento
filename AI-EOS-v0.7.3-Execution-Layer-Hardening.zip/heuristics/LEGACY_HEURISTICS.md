---
id: legacy_heuristics
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [engineering-principles]
used_by: []
supersedes: null
---

# Legacy Heuristics

- Legacy code contains business knowledge.
- Prefer incremental modernization.
- Do not rewrite without evidence.
- Add characterization tests before risky changes.
- Use strangler pattern for large replacements.
