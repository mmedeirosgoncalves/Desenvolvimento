---
id: security_heuristics
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [engineering-principles]
used_by: []
supersedes: null
---

# Security Heuristics

- Default to least privilege.
- Never expose secrets.
- Validate inputs.
- Separate authentication and authorization.
- Log security events without leaking sensitive data.
