---
id: data_heuristics
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [engineering-principles]
used_by: []
supersedes: null
---

# Data Heuristics

- Integrity over convenience.
- Schema changes require migration strategy.
- Measure before optimizing queries.
- Data ownership must be explicit.
- Governance is part of data architecture.
