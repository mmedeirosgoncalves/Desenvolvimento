---
id: skill-database-design
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [kp-database]
used_by: []
supersedes: null
---

# Database Design Skill

## Status

Initial skill requiring expansion.

## Knowledge Dependency

- `knowledge/packs/database/README.md`

## Purpose

Provide basic execution guidance for database design tasks.

## Maturity Warning

Do not treat this skill as complete domain expertise.

Upgrade using `skills/security-review/` and `skills/architecture-review/` as patterns.
