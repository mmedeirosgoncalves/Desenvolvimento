---
id: skills-index
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [knowledge-core, quality-gates]
used_by: []
supersedes: null
---

# Skills Index

## Mature Skills

- security-review
- architecture-review

## Initial / Needs Expansion

- api-design
- database-design
- databricks-engineering
- legacy-modernization
- testing-strategy

## Rule

A mature skill must reference at least one Knowledge Pack and at least one Quality Gate.
