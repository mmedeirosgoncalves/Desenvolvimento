---
id: skill-security-review-checklist
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [kp-owasp-top10]
used_by: []
supersedes: null
---

# Security Review Checklist

## Authentication

- [ ] Is authentication required?
- [ ] Are unauthenticated paths intentional?
- [ ] Are sessions/tokens handled securely?

## Authorization

- [ ] Are permissions checked server-side?
- [ ] Is object-level authorization enforced?
- [ ] Are admin routes protected?

## Sensitive Data

- [ ] Sensitive data identified.
- [ ] Sensitive data minimized.
- [ ] Sensitive data protected in transit.
- [ ] Logs avoid sensitive data.

## OWASP

- [ ] Broken Access Control considered.
- [ ] Injection considered.
- [ ] Security Misconfiguration considered.
- [ ] Vulnerable Components considered.
- [ ] Logging and Monitoring failures considered.
