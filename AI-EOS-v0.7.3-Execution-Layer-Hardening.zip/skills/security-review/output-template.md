---
id: skill-security-review-output-template
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: []
used_by: []
supersedes: null
---

# Security Review Output Template

## Scope

## Assets

## Trust Boundaries

## Entry Points

## Sensitive Data

## Findings

| Finding | Severity | Evidence | Mitigation | Residual Risk |
|---|---|---|---|---|

## Quality Gates

## Final Recommendation

PASS / PASS_WITH_RECOMMENDATIONS / FAIL
