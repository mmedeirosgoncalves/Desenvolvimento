---
id: skill-security-review
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [package-kp-security-principles, kp-owasp-top10, qg-002-security]
used_by: [dependency-graph]
supersedes: null
---

# Security Review Skill

## Purpose

Identify and assess security risks in software changes, architecture, APIs, infrastructure, data flows and dependencies.

## Canon Dependencies

- `canon/security/`

## Knowledge Dependencies

- `knowledge/packs/security/SECURITY_PRINCIPLES.md`
- `knowledge/packs/security/OWASP_TOP_10.md`

## Required Gates

- QG-002 Security
- QG-005 Observability when logging/monitoring is affected
- QG-006 Data Integrity when data is affected
- QG-008 Deployment / Rollback when infrastructure is affected

## Process

1. Identify assets.
2. Identify trust boundaries.
3. Identify entry points.
4. Identify authentication and authorization impact.
5. Identify sensitive data.
6. Map risks to OWASP categories where applicable.
7. Propose mitigations.
8. Apply quality gates.
9. Escalate if risk is high or unclear.
