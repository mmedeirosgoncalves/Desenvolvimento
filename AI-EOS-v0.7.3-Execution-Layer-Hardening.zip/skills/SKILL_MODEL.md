---
id: skill-model
version: 0.4.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [knowledge-strategy, canon-map, quality-gates]
used_by: [skills-index]
supersedes: null
---

# Skill Model

## Definition

A Skill is a reusable execution capability.

It applies Canon and Knowledge Packs to a specific engineering task.

## Mature Skill Requirements

A mature Skill must define:

- purpose
- when to use
- when not to use
- required Canon
- required Knowledge Packs
- required Quality Gates
- inputs
- process
- outputs
- escalation criteria
- examples

## Rule

Skills should not duplicate Canon.

Skills should reference Canon and Knowledge.

## Formula

```text
Canon + Knowledge Pack + Execution Procedure + Quality Gates = Mature Skill
```
