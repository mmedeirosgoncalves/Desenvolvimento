---
id: skill-architecture-review-checklist
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: []
used_by: []
supersedes: null
---

# Architecture Review Checklist

- [ ] Existing architecture understood.
- [ ] Affected components identified.
- [ ] Boundaries remain clear.
- [ ] Coupling is justified.
- [ ] Alternative designs considered.
- [ ] Operational impact assessed.
- [ ] ADR required? If yes, created or updated.
