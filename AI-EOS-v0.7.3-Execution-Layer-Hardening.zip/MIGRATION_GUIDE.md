---
id: migration-guide
version: 0.7.3
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: true
depends_on: [adr-0032]
used_by: []
supersedes: null
---

# Migration Guide — v0.7.2 to v0.7.3

## Summary

v0.7.3 is a hardening release for the Consensus Execution Layer.

## Required Changes

Consumers of v0.7.2 should update to v0.7.3 because reports no longer emit non-standard JSON constants such as `Infinity`, CLI inputs are validated before execution, malformed payloads return structured errors with non-zero exit codes and QG-015 is now registered in the Quality Gate catalog and validation mapping.

## Report Compatibility

The report shape remains compatible, except that undefined metric values are serialized as `null` rather than `Infinity` or `NaN`.

## CLI Compatibility

Existing valid payloads continue to work. Invalid payloads now fail earlier with structured errors.
