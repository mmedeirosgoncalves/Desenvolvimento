---
id: content-duplication-check
version: 0.4.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [qg-004-documentation, canon-document-policy]
used_by: []
supersedes: null
---

# Content Duplication Check

## Purpose

Detect repeated content that may indicate template reuse, copy-paste documentation or Single Source of Truth violations.

## Inputs

- Markdown files
- File paths
- Front matter ids
- Canon document policy

## Checks

1. Compute exact hashes for normalized file bodies.
2. Identify identical bodies across different files.
3. Compute approximate similarity for documents in the same category.
4. Flag near-duplicates above the configured threshold.
5. Exclude allowed reference stubs when they intentionally point to canonical documents.

## Recommended Thresholds

- Exact duplicate: fail unless explicitly allowed.
- Similarity above 0.92: review.
- Similarity above 0.98: fail unless justified.

## Output

```text
Check: Content Duplication
Status:
Exact Duplicates:
Near Duplicates:
Allowed Exceptions:
Recommendation:
```
