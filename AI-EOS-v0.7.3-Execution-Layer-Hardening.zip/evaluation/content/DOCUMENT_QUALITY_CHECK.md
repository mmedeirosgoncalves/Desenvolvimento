---
id: document-quality-check
version: 0.4.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [qg-004-documentation, framework-health-model]
used_by: []
supersedes: null
---

# Document Quality Check

## Purpose

Assess whether documentation is useful rather than merely present.

## Checks

- document has clear purpose
- document has correct layer
- document has consumers
- document does not overstate maturity
- document provides actionable guidance when expected
- document references canonical sources instead of duplicating them
- document status matches actual maturity

## Output

```text
Check: Document Quality
Status:
Weak Documents:
Overstated Maturity:
Recommended Improvements:
```
