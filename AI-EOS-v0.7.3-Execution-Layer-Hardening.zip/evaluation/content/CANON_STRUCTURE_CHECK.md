---
id: canon-structure-check
version: 0.4.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [canon-document-policy, canon-map]
used_by: []
supersedes: null
---

# Canon Structure Check

## Purpose

Validate that Canon follows the Canon Document Policy.

## Checks

- Canon root documents exist.
- Domain documents exist where expected.
- Single-instance Canon documents are not duplicated.
- Domain extension stubs reference canonical sources.
- Domain-specific documents contain domain-specific content.
- Canon Map references known domains.

## Output

```text
Check: Canon Structure
Status:
Missing:
Duplicated:
Unexpected:
Recommendation:
```
