---
id: markdown-render-check
version: 0.4.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [qg-004-documentation]
used_by: []
supersedes: null
---

# Markdown Render Check

## Purpose

Detect Markdown content likely to render incorrectly.

## Checks

- literal `\n` sequences in prose
- unclosed code fences
- malformed heading hierarchy
- tables with inconsistent column counts
- broken internal Markdown links
- excessive escaped characters
- front matter not closed properly

## Output

```text
Check: Markdown Render
Status:
Findings:
Files:
Recommendation:
```
