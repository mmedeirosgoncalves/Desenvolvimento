---
id: audit-remediation-decision-rules
version: 0.6.0.2
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [audit-remediation-policy, test-gate-policy]
used_by: []
supersedes: null
---

# Audit Remediation Decision Rules

## Order

1. Confirm fact.
2. Classify severity.
3. Identify regression, gap, ambiguity or enhancement.
4. Decide if implementation is required.
5. Select compact or full ARP.
6. Define tests before implementation.
7. Run release gate.

## Blocking Criteria

A finding blocks release when it affects:

- reproducibility;
- baseline preservation;
- dependency integrity;
- executable validation;
- negative fixture detection;
- declared PASS status.
