---
id: review-loop
version: 0.3.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [release-review-protocol, engineering-evolution-policy]
used_by: [agents-entry-point]
supersedes: null
---

# AI-EOS Review Loop

## Purpose

Define the official continuous improvement loop for AI-EOS releases.

## Review Loop

```text
Implementation
  -> Independent Review
  -> Critical Analysis
  -> Requirements
  -> ADRs
  -> Release Plan
  -> Incremental Merge
  -> Regression Check
  -> New Baseline
```

## Independent Review

The independent reviewer may be:

- Devin
- another AI engineering agent
- a human reviewer
- a dedicated review workflow

## Review Input

Reviews may arrive as:

- text
- Markdown
- screenshots
- issue comments
- PR reviews

## Required Review Processing

For every review:

1. extract findings
2. classify findings
3. accept, reject or partially accept findings
4. convert valid findings into requirements
5. decide whether ADRs are required
6. produce release plan
7. preserve previous baseline

## Finding Classification

Each finding must be classified as:

- Correct
- Partially Correct
- Incorrect
- Context-Dependent
- Architectural Trade-off

## Output

Every review cycle must produce:

- executive summary
- accepted requirements
- rejected findings with justification
- ADR recommendations
- roadmap changes
- implementation plan
- residual risks

## Content Review Addendum

Release reviews must include content quality checks:

- Markdown render issues
- duplicate documentation
- unpersonalized templates
- broken references
- Canon Single Source of Truth violations

## Validation Engine Step

Before independent review, run the Validation Engine.

The review process should use the generated report as evidence but not as a substitute for architectural judgment.
