---
id: audit-remediation-proposal-template
version: 0.6.0.2
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [audit-remediation-policy]
used_by: []
supersedes: null
---

# Audit Remediation Proposal Template

## Finding ID

`ARP-YYYY-NNN`

## Status

`proposed | accepted | rejected | deferred | implemented | verified`

## Severity

`critical | high | medium | low`

## Observed Fact

Directly observed behavior.

## Evidence

Logs, screenshots, file paths, stack traces or command output.

## Root-Cause Hypothesis

Likely cause, marked as hypothesis unless proven.

## Confidence

Percentage and evidence basis.

## Suggested Fix

Preferred remediation.

## Alternative Fixes

Viable alternatives.

## Do-Not-Implement Option

When it is acceptable not to implement.

## Architectural Impact

Layers, contracts, runtime, validators or governance affected.

## Required Tests

Tests that must pass.

## Acceptance Criteria

Observable closure criteria.
