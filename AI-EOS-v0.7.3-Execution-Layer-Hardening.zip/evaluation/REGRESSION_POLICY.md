---
id: regression-policy
version: 0.3.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [baseline-policy, migration-policy]
used_by: [review-loop]
supersedes: null
---

# Regression Policy

## Purpose

Prevent AI-EOS releases from losing existing capability.

## Regression Definition

A regression occurs when a release unintentionally:

- removes an operational file
- removes a quality gate
- breaks bootstrap
- invalidates references
- drops Knowledge Packs used by Skills
- removes Playbooks, Templates or Decision Trees without replacement
- makes a mature Skill less useful
- replaces operational content with conceptual content only

## Regression Severity

## Critical

Breaks bootstrap, removes entry point, or makes release unusable.

## High

Removes operational capabilities such as Skills, Quality Gates, Playbooks or Knowledge Packs.

## Medium

Breaks references, dependency metadata or documentation consistency.

## Low

Minor inconsistency, typo, stale roadmap or formatting issue.

## Required Checks

Before release:

- compare file inventory with previous baseline
- identify removed files
- identify renamed files
- check AGENTS.md bootstrap
- check quality gates
- check mature skills
- check Knowledge Pack references
- check ADR coverage for removals

## Rule

If a regression is found, the release must be corrected before delivery or explicitly documented as an intentional breaking change.
