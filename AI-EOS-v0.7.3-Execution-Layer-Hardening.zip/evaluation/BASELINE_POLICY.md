---
id: baseline-policy
version: 0.3.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [engineering-evolution-policy]
used_by: [regression-policy]
supersedes: null
---

# Baseline Policy

## Purpose

Define how AI-EOS selects and advances the official baseline.

## Definition

The baseline is the most recent approved complete release of AI-EOS.

## Current Baseline Rule

A partial package, Vision-only release or experimental branch cannot become baseline unless merged into the complete operational release.

## Baseline Advancement

A release becomes the new baseline only when:

- it preserves previous capabilities
- it passes regression checks
- it has updated CHANGELOG
- it has updated ROADMAP
- it includes required ADRs
- it remains usable through AGENTS.md
- it has no undocumented removals

## Baseline Inputs

A new release must start from:

1. previous approved baseline
2. approved additions
3. approved refactorings
4. approved ADRs

## Forbidden

Do not start a release from:

- a partial package
- a Vision-only package
- a newly generated empty structure
- memory of the previous release
- reconstructed approximations
