---
id: scope
version: 0.3.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [vision]
used_by: []
supersedes: null
---

# AI-EOS Scope

## In Scope

- engineering principles
- architecture governance
- engineering canon
- knowledge packs
- skills
- playbooks
- runtime protocols
- quality gates
- release evaluation
- multi-agent coordination
- vendor adapters

## Out of Scope for Now

- full executable software runtime
- graphical UI
- autonomous production deployment
- replacement of human engineering accountability
- complete coverage of all engineering domains

## Explicit Boundary

AI-EOS may guide agents in writing code, but AI-EOS itself is not yet an executable coding agent.
