---
id: maturity-model
version: 0.3.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [vision]
used_by: []
supersedes: null
---

# AI-EOS Maturity Model

## Level 0 — Prompt Collection

Unstructured prompts and ad hoc instructions.

## Level 1 — Process Scaffold

Reusable process documents, templates and checklists.

## Level 2 — Governed Framework

Single entry point, governance, ADRs, quality gates and release review.

## Level 3 — Knowledge Operating System

Canon and Knowledge Packs provide reusable domain knowledge.

## Level 4 — Runtime-Oriented System

Planner, dispatcher, loaders, validators and review engine coordinate execution.

## Level 5 — Multi-Agent Engineering Platform

Multiple specialist agents collaborate through formal protocols, consensus and validation.

## Current Target

AI-EOS v0.3 targets Level 2 moving toward Level 3.
