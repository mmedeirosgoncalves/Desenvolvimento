---
id: changelog
version: 0.7.3
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: true
depends_on: []
used_by: []
supersedes: null
---

# Changelog

## v0.7.3 — Execution Layer Hardening

- Updated package identity to v0.7.3.
- Removed non-standard `Infinity` and `NaN` JSON emission from consensus reports.
- Enforced strict JSON serialization with `allow_nan=False`.
- Added CLI payload validation and structured error output.
- Integrated QG-015 into the central Quality Gate catalog, mapping and validation registry.
- Added QG-015 reference validation to the reference validator.
- Added strict JSON and invalid payload tests.
- Updated README, Migration Guide, Roadmap, Package Manifest and Release Validation.

## v0.7.2 — Consensus Execution Layer

- Added operational CLI for consensus execution.
- Added benchmark runner.
- Added sample execution artifact and reports.
- Added ADR-0032.
