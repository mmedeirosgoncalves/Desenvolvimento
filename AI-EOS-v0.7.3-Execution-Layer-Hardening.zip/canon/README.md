---
id: canon-index
version: 0.3.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [canon-strategy]
used_by: []
supersedes: null
---

# Engineering Canon

The Canon is the stable knowledge foundation of AI-EOS.

## Domains

- architecture
- security
- testing
- data
- databricks
- cloud
- legacy
- api
- devops

## Relationship to Knowledge Packs

Canon defines durable knowledge.

Knowledge Packs adapt Canon to AI-EOS usage.

## Relationship to Skills

Skills apply Knowledge Packs to tasks.
