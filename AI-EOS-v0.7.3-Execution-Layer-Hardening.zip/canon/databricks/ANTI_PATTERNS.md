---
id: canon-databricks-anti-patterns
version: 0.4.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [canon-databricks-principles]
used_by: []
supersedes: null
---

# Databricks Canon — Anti-Patterns

- Using Spark for small data problems that do not need distributed processing.
- Optimizing Spark jobs without metrics.
- Unmanaged tables without governance strategy.
- Pipelines without checkpointing or replay plan.
- Mixing raw and curated data without clear lifecycle boundaries.
