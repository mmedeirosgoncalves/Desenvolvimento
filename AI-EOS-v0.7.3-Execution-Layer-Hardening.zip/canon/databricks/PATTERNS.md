---
id: canon-databricks-patterns
version: 0.4.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [canon-databricks-principles]
used_by: []
supersedes: null
---

# Databricks Canon — Patterns

## Delta Lake

Use for ACID transactions, schema enforcement and time travel on lakehouse data.

## Medallion Architecture

Use Bronze/Silver/Gold organization when it clarifies data lifecycle.

## Unity Catalog

Use for centralized governance, lineage and access control.

## Structured Streaming

Use for streaming workloads with checkpointing and exactly-once-oriented design.

## Job Workflows

Use to orchestrate repeatable pipelines with operational visibility.

