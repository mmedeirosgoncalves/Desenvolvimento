---
id: canon-databricks-principles
version: 0.4.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [canon-databricks]
used_by: []
supersedes: null
---

# Databricks Canon — Principles

- Databricks solutions should be designed around data reliability, governance and scalable processing.
- Delta Lake should be preferred for transactional lakehouse storage when available.
- Unity Catalog should be used for governance when available.
- Spark optimization should be measurement-driven.
- Pipelines should be observable and replayable.
