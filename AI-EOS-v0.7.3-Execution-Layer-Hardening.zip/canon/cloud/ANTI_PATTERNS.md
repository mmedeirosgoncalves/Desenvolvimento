---
id: canon-cloud-anti-patterns
version: 0.4.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [canon-cloud-principles]
used_by: []
supersedes: null
---

# Cloud Canon — Anti-Patterns

- ClickOps for production infrastructure.
- Broad admin permissions for workloads.
- Ignoring egress and managed service cost.
- No rollback plan for infrastructure changes.
- Monitoring only application code and not cloud dependencies.
