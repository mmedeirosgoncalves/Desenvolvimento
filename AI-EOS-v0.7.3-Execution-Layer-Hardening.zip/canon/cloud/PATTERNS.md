---
id: canon-cloud-patterns
version: 0.4.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [canon-cloud-principles]
used_by: []
supersedes: null
---

# Cloud Canon — Patterns

## Infrastructure as Code

Use to make infrastructure reviewable and repeatable.

## Least Privilege IAM

Use narrowly scoped permissions.

## Multi-AZ Deployment

Use where availability requirements justify it.

## Autoscaling

Use when demand variability and statelessness permit.

## FinOps Tagging

Use to attribute and manage cloud cost.

