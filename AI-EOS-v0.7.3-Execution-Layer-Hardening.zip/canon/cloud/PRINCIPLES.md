---
id: canon-cloud-principles
version: 0.4.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [canon-cloud]
used_by: []
supersedes: null
---

# Cloud Canon — Principles

- Cloud architecture must balance reliability, security, cost and operability.
- IAM is architecture, not configuration detail.
- Managed services reduce some burden but introduce platform coupling.
- Resilience must be designed and tested.
- Cost must be observable.
