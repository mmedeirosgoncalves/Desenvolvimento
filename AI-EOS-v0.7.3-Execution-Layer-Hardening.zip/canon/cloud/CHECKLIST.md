---
id: canon-cloud-checklist
version: 0.4.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [canon-cloud-principles]
used_by: []
supersedes: null
---

# Cloud Canon — Checklist

- [ ] Are permissions minimal?
- [ ] Is infrastructure versioned?
- [ ] Is cost impact understood?
- [ ] Is rollback possible?
- [ ] Are reliability assumptions tested?
