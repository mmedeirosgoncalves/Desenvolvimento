---
id: canon-strategy
version: 0.3.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [target-architecture]
used_by: []
supersedes: null
---

# Engineering Canon Strategy

## Purpose

Canon contains consolidated engineering knowledge.

Canon is slow-changing.

It should represent durable concepts, not project-specific opinions.

## Canon Inclusion Criteria

A concept may enter Canon when it is:

- broadly recognized
- useful across multiple projects
- stable enough to document
- applicable to AI-assisted engineering
- not merely a tool-specific implementation detail

## Canon Examples

- Clean Architecture
- Domain-Driven Design
- OWASP Top 10
- Testing Pyramid
- Contract Testing
- Delta Lake
- Spark
- Lakehouse
- Strangler Pattern
- Infrastructure as Code
- Zero Trust

## Canon Exclusion Criteria

Do not include:

- temporary tool trends
- project-specific conventions
- vendor-specific instructions unless placed under a vendor-specific canon section
- unsupported claims
