---
id: canon-roadmap
version: 0.4.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [canon-map, canon-document-policy]
used_by: [canon-map]
supersedes: null
---

# Canon Roadmap

## Purpose

This is the single canonical roadmap for Engineering Canon development.

Domain-specific Canon roadmaps should reference this document instead of duplicating generic roadmap text.

## Phase C2 — Operational Guidance

Current phase.

Goals:

- principles
- patterns
- anti-patterns
- checklists
- basic decision support

## Phase C3 — Decision Support

Next phase.

Goals:

- worked examples
- deeper decision trees
- trade-off matrices
- domain-specific scenarios
- cross-links to Knowledge Packs
- quality gate mappings

## Phase C4 — Integrated Canon

Later phase.

Goals:

- consumed by mature Skills
- connected to Playbooks
- validated by Evaluation tools
- integrated into Runtime loaders
- measured by Knowledge Coverage

## Domain Extension

A Canon domain may define its own roadmap only when it has domain-specific sequencing needs.

Otherwise, domains should reference this file.
