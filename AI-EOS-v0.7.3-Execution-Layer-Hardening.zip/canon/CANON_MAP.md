---
id: canon-map
version: 0.4.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [canon-index, canon-inclusion-criteria]
used_by: [knowledge-map]
supersedes: null
---

# Canon Map

## Purpose

This map defines the initial Engineering Canon domains and their relationship to AI-EOS execution.

## Domains

| Domain | Purpose | Primary Consumers |
|---|---|---|
| Architecture | System design and structural decisions | architecture-review, api-design, legacy-modernization |
| Security | Secure design and risk evaluation | security-review, api-design, devops-review |
| Testing | Validation strategy and regression protection | testing-strategy, code-review, bug-fix |
| Data | Data integrity, lineage and governance | database-design, databricks-engineering |
| Database | Transactional persistence and schema evolution | database-design, migration |
| Cloud | Cloud-native infrastructure and reliability | devops-review, platform-engineering |
| Databricks | Lakehouse, Spark and Delta practices | databricks-engineering |
| API | Interface design and contracts | api-design, integration-design |
| Legacy | Modernization and compatibility | legacy-modernization, refactoring |
| DevOps | CI/CD, operations and delivery | devops-review, release-engineering |

## Relationship

```text
Canon
  -> Knowledge Packs
  -> Skills
  -> Playbooks
  -> Runtime / Agents
```


## Canon-Wide Documents

- `canon/DECISION_RULES.md`
- `canon/ROADMAP.md`
- `canon/CANON_INCLUSION_CRITERIA.md`

Domain-level decision rules and roadmaps should reference these documents rather than duplicating generic content.
