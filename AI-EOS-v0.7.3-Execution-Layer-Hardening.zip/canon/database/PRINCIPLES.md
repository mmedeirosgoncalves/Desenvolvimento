---
id: canon-database-principles
version: 0.4.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [canon-database]
used_by: []
supersedes: null
---

# Database Canon — Principles

- Transactional integrity must be preserved where required.
- Schema changes are production changes.
- Backward compatibility matters during rollout.
- Indexes should support measured access patterns.
- Database design should reflect ownership and consistency needs.
