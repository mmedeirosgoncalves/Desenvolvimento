---
id: canon-database-patterns
version: 0.4.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [canon-database-principles]
used_by: []
supersedes: null
---

# Database Canon — Patterns

## Expand and Contract Migration

Use for backward-compatible schema evolution.

## Transactional Boundary

Use to define consistency scope.

## Read Model

Use when query needs differ from write model needs.

## Optimistic Concurrency

Use when conflicts are rare but must be detected.

## Database Migration Scripts

Use versioned, repeatable migrations.

