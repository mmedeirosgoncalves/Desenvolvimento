---
id: canon-database-anti-patterns
version: 0.4.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [canon-database-principles]
used_by: []
supersedes: null
---

# Database Canon — Anti-Patterns

- Destructive migrations without backup or rollback.
- Shared database ownership across unrelated services.
- Adding indexes without measuring query patterns.
- Using database triggers to hide business logic without documentation.
- Changing schema and application assumptions in a single irreversible step.
