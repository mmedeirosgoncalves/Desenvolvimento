---
id: canon-database-checklist
version: 0.4.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [canon-database-principles]
used_by: []
supersedes: null
---

# Database Canon — Checklist

- [ ] Is the migration backward-compatible?
- [ ] Is rollback or recovery defined?
- [ ] Is data loss possible?
- [ ] Are indexes justified?
- [ ] Are consumers affected?
