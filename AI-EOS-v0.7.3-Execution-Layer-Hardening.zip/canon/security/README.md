---
id: canon-security
version: 0.4.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [canon-map, package-kp-security-principles, kp-owasp-top10]
used_by: [package-kp-security, skill-security]
supersedes: null
---

# Security Canon

## Purpose

This Canon domain captures durable engineering knowledge for security decisions and practices.

## Maturity

C2 — Operational Guidance.

This domain now includes principles, patterns, anti-patterns and checklist guidance.

## Files

- `PRINCIPLES.md`
- `PATTERNS.md`
- `ANTI_PATTERNS.md`
- `CHECKLIST.md`
- `DECISION_RULES.md`
- `ROADMAP.md`

## Primary Consumers

- Knowledge Packs
- Skills
- Playbooks
- Quality Gates
- Agents
