---
id: canon-security-roadmap
version: 0.4.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [canon-roadmap, canon-security]
used_by: []
supersedes: null
---

# Security Canon — Roadmap

## Canonical Source

Use the canonical Canon roadmap:

- `canon/ROADMAP.md`

## Domain Extension

No domain-specific roadmap is defined for `security` in this release.

If future `security` work requires distinct sequencing, add a domain-specific extension here without duplicating the canonical roadmap.
