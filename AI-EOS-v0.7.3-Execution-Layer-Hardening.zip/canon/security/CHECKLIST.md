---
id: canon-security-checklist
version: 0.4.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [canon-security-principles]
used_by: []
supersedes: null
---

# Security Canon — Checklist

- [ ] Is authentication required and correctly enforced?
- [ ] Is authorization checked server-side?
- [ ] Could sensitive data be exposed?
- [ ] Are secrets protected?
- [ ] Have OWASP-relevant risks been reviewed?
