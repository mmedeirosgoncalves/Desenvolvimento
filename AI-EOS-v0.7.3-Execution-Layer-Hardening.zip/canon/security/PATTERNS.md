---
id: canon-security-patterns
version: 0.4.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [canon-security-principles]
used_by: []
supersedes: null
---

# Security Canon — Patterns

## Defense in Depth

Use multiple independent controls instead of relying on one boundary.

## Zero Trust

Do not assume implicit trust based on network location.

## Centralized Secrets Management

Use controlled secret storage and rotation instead of code or ad hoc environment files.

## Server-Side Authorization

Enforce permissions on the server, never only in the client.

## Security Logging

Log security-relevant events without exposing sensitive content.

