---
id: canon-security-anti-patterns
version: 0.4.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [canon-security-principles]
used_by: []
supersedes: null
---

# Security Canon — Anti-Patterns

- Trusting client-side checks.
- Logging secrets, tokens or sensitive records.
- Using broad cloud permissions for convenience.
- Treating internal APIs as inherently safe.
- Adding dependencies without vulnerability or maintenance review.
