---
id: canon-security-principles
version: 0.4.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [canon-security]
used_by: []
supersedes: null
---

# Security Canon — Principles

- Security must be designed in, not added after implementation.
- Apply least privilege by default.
- Authentication and authorization are separate concerns.
- Sensitive data should be minimized, protected and observable without leakage.
- Failures should be secure by default.
