---
id: canon-architecture-checklist
version: 0.4.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [canon-architecture-principles]
used_by: []
supersedes: null
---

# Architecture Canon — Checklist

- [ ] Are boundaries explicit?
- [ ] Is the chosen architecture proportionate to the problem?
- [ ] Are operational implications understood?
- [ ] Can the decision be reversed?
- [ ] Does the architecture preserve testability?
