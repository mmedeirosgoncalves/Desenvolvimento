---
id: canon-architecture-anti-patterns
version: 0.4.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [canon-architecture-principles]
used_by: []
supersedes: null
---

# Architecture Canon — Anti-Patterns

- Choosing microservices to solve organizational or code quality problems without operational maturity.
- Creating abstractions before variation exists.
- Allowing shared databases to become hidden coupling between services.
- Treating diagrams as more authoritative than code.
- Adding layers that do not reduce coupling or improve clarity.
