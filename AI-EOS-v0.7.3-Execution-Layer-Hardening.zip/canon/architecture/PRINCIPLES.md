---
id: canon-architecture-principles
version: 0.4.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [canon-architecture]
used_by: []
supersedes: null
---

# Architecture Canon — Principles

- Architecture should manage complexity by defining boundaries.
- Architectural decisions must be explainable in business and technical terms.
- Prefer reversible decisions when uncertainty is high.
- Avoid distributed architecture unless operational and domain conditions justify it.
- Architecture should enable change without hiding complexity.
