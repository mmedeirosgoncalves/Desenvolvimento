---
id: canon-architecture-patterns
version: 0.4.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [canon-architecture-principles]
used_by: []
supersedes: null
---

# Architecture Canon — Patterns

## Modular Monolith

Use when domain boundaries are still evolving or operational simplicity matters.

## Clean Architecture

Use to isolate business rules from frameworks and delivery mechanisms.

## Hexagonal Architecture

Use ports and adapters to protect domain logic from infrastructure details.

## Microservices

Use when domain boundaries, team ownership and operational maturity justify distribution.

## Event-Driven Architecture

Use for decoupled workflows, integration and asynchronous processing when event semantics are clear.

