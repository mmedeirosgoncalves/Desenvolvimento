---
id: canon-data-checklist
version: 0.4.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [canon-data-principles]
used_by: []
supersedes: null
---

# Data Canon — Checklist

- [ ] Who owns the data?
- [ ] What consumers depend on it?
- [ ] How is quality measured?
- [ ] How are schema changes handled?
- [ ] Can lineage be traced?
