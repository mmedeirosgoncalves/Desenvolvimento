---
id: canon-data-patterns
version: 0.4.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [canon-data-principles]
used_by: []
supersedes: null
---

# Data Canon — Patterns

## Data Contracts

Use to define expectations between producers and consumers.

## Lineage Tracking

Use to understand downstream impact and audit transformations.

## Data Quality Rules

Use explicit validation rules for completeness, accuracy and consistency.

## Idempotent Pipelines

Use to make retries safe.

## Separation of Raw, Refined and Curated Data

Use to manage lake/lakehouse data lifecycle.

