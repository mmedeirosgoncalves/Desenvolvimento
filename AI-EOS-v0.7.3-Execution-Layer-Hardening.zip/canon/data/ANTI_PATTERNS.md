---
id: canon-data-anti-patterns
version: 0.4.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [canon-data-principles]
used_by: []
supersedes: null
---

# Data Canon — Anti-Patterns

- Unowned shared datasets.
- Silent schema drift.
- Pipelines without replay strategy.
- Metrics without definitions.
- Duplicating data without consistency strategy.
