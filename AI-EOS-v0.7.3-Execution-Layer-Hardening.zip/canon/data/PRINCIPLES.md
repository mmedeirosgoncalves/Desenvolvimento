---
id: canon-data-principles
version: 0.4.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [canon-data]
used_by: []
supersedes: null
---

# Data Canon — Principles

- Data integrity is a first-class architectural concern.
- Data ownership must be explicit.
- Lineage and governance matter as systems scale.
- Schema evolution must be planned.
- Data quality must be observable.
