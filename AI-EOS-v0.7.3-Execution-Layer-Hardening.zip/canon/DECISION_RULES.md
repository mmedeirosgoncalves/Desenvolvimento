---
id: canon-decision-rules
version: 0.4.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [canon-map, canon-document-policy]
used_by: [canon-map]
supersedes: null
---

# Canon Decision Rules

## Purpose

This is the single canonical decision-rules document for the Engineering Canon.

Domain-specific Canon documents must reference this file instead of duplicating the same generic rules.

## Rule 1 — Fit Before Preference

Choose approaches based on problem fit, constraints, context and operational maturity.

Do not choose an approach only because it is fashionable, familiar or technically elegant.

## Rule 2 — Make Trade-offs Explicit

When multiple approaches are viable, compare:

- correctness
- complexity
- maintainability
- operational impact
- reversibility
- cost
- security
- observability
- team maturity

## Rule 3 — Prefer Reversible Decisions Under Uncertainty

When uncertainty is high, prefer designs that allow future correction.

Hard-to-reverse choices require stronger justification and should usually be documented through ADRs.

## Rule 4 — Document Significant Decisions

Record an ADR when a decision affects:

- architecture
- security posture
- operational risk
- data integrity
- long-term maintainability
- public interfaces
- migration paths

## Rule 5 — Domain Extension

A Canon domain may add domain-specific decision guidance only when it materially differs from these common rules.

Domain-specific extensions must reference this document and must not duplicate it.
