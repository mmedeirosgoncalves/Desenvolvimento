---
id: canon-inclusion-criteria
version: 0.4.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [canon-strategy]
used_by: [canon-index]
supersedes: null
---

# Canon Inclusion Criteria

## Purpose

Define when knowledge belongs in the Engineering Canon.

Canon should contain durable engineering knowledge that is reusable across projects, vendors and agents.

## Include Knowledge When It Is

- broadly applicable across projects
- stable or slow-changing
- recognized by professional engineering practice
- useful for architectural or implementation decisions
- reusable by multiple Skills or Knowledge Packs
- not specific to a single repository

## Exclude Knowledge When It Is

- project-specific
- vendor-specific without broad applicability
- experimental
- based on temporary tooling behavior
- better represented as a Playbook procedure
- better represented as a Skill process
- better placed in Labs

## Canon Maturity Levels

### C0 — Placeholder

Topic identified but not developed.

### C1 — Principles

Core principles documented.

### C2 — Operational Guidance

Includes heuristics, anti-patterns and checklists.

### C3 — Decision Support

Includes decision trees, trade-offs and examples.

### C4 — Integrated Canon

Referenced by Knowledge Packs, Skills, Playbooks and Quality Gates.

## Rule

A Canon item should not be called mature unless it reaches at least C3.
