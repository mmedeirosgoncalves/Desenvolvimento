---
id: canon-legacy-checklist
version: 0.4.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [canon-legacy-principles]
used_by: []
supersedes: null
---

# Legacy Canon — Checklist

- [ ] What business behavior must be preserved?
- [ ] What tests protect current behavior?
- [ ] Can migration be incremental?
- [ ] What is the rollback path?
- [ ] Where should anti-corruption boundaries exist?
