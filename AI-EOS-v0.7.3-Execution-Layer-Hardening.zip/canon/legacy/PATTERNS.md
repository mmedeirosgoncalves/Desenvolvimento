---
id: canon-legacy-patterns
version: 0.4.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [canon-legacy-principles]
used_by: []
supersedes: null
---

# Legacy Canon — Patterns

## Strangler Fig Pattern

Use to replace legacy capability incrementally.

## Anti-Corruption Layer

Use to isolate new models from legacy concepts.

## Branch by Abstraction

Use to migrate implementations behind stable interfaces.

## Characterization Tests

Use to capture existing behavior before changing it.

## Parallel Run

Use to compare old and new behavior before cutover.

