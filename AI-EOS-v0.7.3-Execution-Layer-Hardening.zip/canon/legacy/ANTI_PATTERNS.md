---
id: canon-legacy-anti-patterns
version: 0.4.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [canon-legacy-principles]
used_by: []
supersedes: null
---

# Legacy Canon — Anti-Patterns

- Big-bang rewrite without migration path.
- Discarding legacy behavior as irrelevant.
- Refactoring without safety tests.
- Replacing technology without understanding domain behavior.
- Mixing new architecture with legacy coupling without boundaries.
