---
id: canon-legacy-principles
version: 0.4.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [canon-legacy]
used_by: []
supersedes: null
---

# Legacy Canon — Principles

- Legacy systems contain business knowledge.
- Modernization should reduce risk incrementally.
- Rewrite is a last resort, not a default strategy.
- Characterization tests protect unknown behavior.
- Migration should preserve operational continuity.
