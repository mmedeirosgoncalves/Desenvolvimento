---
id: canon-devops-anti-patterns
version: 0.4.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [canon-devops-principles]
used_by: []
supersedes: null
---

# DevOps Canon — Anti-Patterns

- Manual production changes without review.
- Deployments without rollback.
- CI pipelines that are slow, flaky or ignored.
- Observability added only after incidents.
- Secrets stored in pipeline definitions or logs.
