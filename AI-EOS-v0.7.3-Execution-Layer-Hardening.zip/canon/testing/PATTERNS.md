---
id: canon-testing-patterns
version: 0.4.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [canon-testing-principles]
used_by: []
supersedes: null
---

# Testing Canon — Patterns

## Testing Pyramid

Use many fast unit tests, fewer integration tests and targeted end-to-end tests.

## Contract Testing

Use when systems interact through APIs or messages and independent deployment matters.

## Characterization Testing

Use for legacy code before refactoring unknown behavior.

## Golden Master Testing

Use for complex legacy outputs where expected behavior is hard to specify manually.

## Mutation Testing

Use selectively to assess test suite strength.

