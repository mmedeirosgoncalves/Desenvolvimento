---
id: canon-testing-principles
version: 0.4.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [canon-testing]
used_by: []
supersedes: null
---

# Testing Canon — Principles

- Tests reduce uncertainty about behavior.
- Test behavior rather than implementation details when possible.
- Regression tests should be added for confirmed bugs.
- A useful test suite balances speed, confidence and maintainability.
- Untestable code is often poorly designed code.
