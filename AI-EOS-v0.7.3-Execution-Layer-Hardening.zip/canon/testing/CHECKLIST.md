---
id: canon-testing-checklist
version: 0.4.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [canon-testing-principles]
used_by: []
supersedes: null
---

# Testing Canon — Checklist

- [ ] What behavior must be protected?
- [ ] What regression risk exists?
- [ ] Are critical paths tested?
- [ ] Are tests maintainable?
- [ ] Can failures be diagnosed?
