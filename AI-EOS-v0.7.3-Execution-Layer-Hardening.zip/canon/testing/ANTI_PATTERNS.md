---
id: canon-testing-anti-patterns
version: 0.4.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [canon-testing-principles]
used_by: []
supersedes: null
---

# Testing Canon — Anti-Patterns

- Relying only on end-to-end tests.
- Testing private implementation details that change frequently.
- Writing tests that assert mocks rather than meaningful behavior.
- Ignoring flaky tests.
- Treating coverage percentage as sufficient evidence of quality.
