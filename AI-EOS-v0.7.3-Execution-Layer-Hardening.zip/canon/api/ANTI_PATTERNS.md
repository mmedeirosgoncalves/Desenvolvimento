---
id: canon-api-anti-patterns
version: 0.4.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [canon-api-principles]
used_by: []
supersedes: null
---

# API Canon — Anti-Patterns

- Leaking database schema directly through API contracts.
- Returning inconsistent error shapes.
- Breaking consumers without migration plan.
- Using POST for everything without semantics.
- Versioning prematurely instead of preserving compatibility.
