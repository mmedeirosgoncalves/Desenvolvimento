---
id: canon-api-checklist
version: 0.4.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [canon-api-principles]
used_by: []
supersedes: null
---

# API Canon — Checklist

- [ ] Who are the consumers?
- [ ] Is the contract stable?
- [ ] Are errors designed?
- [ ] Is authorization enforced?
- [ ] Is backward compatibility preserved?
