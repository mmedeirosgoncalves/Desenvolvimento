---
id: canon-api-principles
version: 0.4.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [canon-api]
used_by: []
supersedes: null
---

# API Canon — Principles

- APIs are contracts.
- Backward compatibility should be preserved unless a breaking change is intentional.
- Errors are part of the API design.
- Idempotency matters for retries and distributed systems.
- APIs should expose domain concepts, not internal implementation details.
