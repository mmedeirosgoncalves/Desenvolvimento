---
id: canon-api-patterns
version: 0.4.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [canon-api-principles]
used_by: []
supersedes: null
---

# API Canon — Patterns

## REST

Use resource-oriented APIs where HTTP semantics fit.

## GraphQL

Use when clients need flexible querying and schema governance exists.

## gRPC

Use for strongly typed service-to-service communication where appropriate.

## Idempotency Keys

Use for retry-safe operations that create or mutate resources.

## Consumer-Driven Contracts

Use when API consumers deploy independently.

