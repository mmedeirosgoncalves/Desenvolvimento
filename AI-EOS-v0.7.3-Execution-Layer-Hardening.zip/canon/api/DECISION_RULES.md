---
id: canon-api-decision-rules
version: 0.4.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [canon-decision-rules, canon-api]
used_by: []
supersedes: null
---

# Api Canon — Decision Rules

## Canonical Source

Use the canonical decision rules:

- `canon/DECISION_RULES.md`

## Domain Extension

No domain-specific decision rules are defined for `api` in this release.

If future `api` work requires distinct decision logic, add a domain-specific extension here without duplicating the canonical rules.
