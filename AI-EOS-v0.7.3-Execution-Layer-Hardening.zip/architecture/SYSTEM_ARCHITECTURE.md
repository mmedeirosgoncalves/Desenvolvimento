---
id: system-architecture
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [constitution, knowledge-core]
used_by: [agents-entry-point]
supersedes: null
---

# System Architecture

AI-EOS is organized into six conceptual cores.

## 1. Governance Core

Constitution, principles, ADRs and governance.

## 2. Knowledge Core

Domain knowledge, standards, frameworks, domain-specific rules and reference material.

## 3. Reasoning Core

Task classification, routing, escalation, decision trees and heuristics.

## 4. Runtime Core

Operational protocols that coordinate execution.

## 5. Execution Core

Skills, playbooks and templates.

## 6. Integration Core

Adapters for Devin and other AI agents.

## Architectural Principle

```text
Knowledge + Execution = Skill
```

Skills should not duplicate large knowledge bodies.

They should reference Knowledge Packs and define how to apply them.
