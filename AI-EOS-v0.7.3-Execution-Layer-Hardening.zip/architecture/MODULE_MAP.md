---
id: module-map
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [system-architecture]
used_by: []
supersedes: null
---

# Module Map

## Governance

- constitution/
- architecture/adr/
- governance/

## Knowledge

- knowledge/
- knowledge/packs/

## Reasoning

- heuristics/
- decision-trees/
- runtime/routing/

## Runtime

- runtime/
- runtime/quality-gates/

## Execution

- skills/
- playbooks/
- templates/

## Integration

- adapters/
