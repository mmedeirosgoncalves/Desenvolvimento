---
id: layer-responsibilities
version: 0.3.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [target-architecture]
used_by: []
supersedes: null
---

# Layer Responsibilities

## Kernel

Defines non-negotiable rules.

## Canon

Stores consolidated engineering knowledge.

## Knowledge

Adapts Canon to AI-EOS use.

## Skills

Applies Knowledge to tasks.

## Runtime

Coordinates execution.

## Agents

Defines specialist roles.

## Governance

Controls change.

## Evaluation

Measures quality and drift.

## Adapters

Connects AI-EOS to tools.

## Labs

Contains experiments.
