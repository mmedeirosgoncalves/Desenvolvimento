---
id: dependency-rules
version: 0.3.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [target-architecture]
used_by: []
supersedes: null
---

# Dependency Rules

## Allowed Direction

```text
Kernel
  -> Canon
  -> Knowledge
  -> Skills
  -> Runtime
  -> Agents
  -> Evaluation
  -> Adapters
```

This is conceptual, not a strict import graph.

## Rules

1. Skills may depend on Knowledge and Canon.
2. Knowledge may depend on Canon.
3. Canon should not depend on Skills.
4. Kernel should remain minimal.
5. Adapters may depend on everything needed to operate.
6. Labs must not be required by stable modules.
7. Evaluation may inspect all layers.

## Anti-Patterns

- Skills duplicating Canon.
- Adapters defining core rules.
- Labs becoming implicit production dependencies.
- Multiple files defining the same operational rule.
