---
id: adr-0027
version: 0.7.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
release_document: false
depends_on: [adr-0026]
used_by: []
supersedes: null
---

# ADR-0027 — Multi-AI Experiment Framework

## Status

Accepted

## Context

AI-EOS needs to test whether multiple AI systems working independently produce better engineering outcomes than a single AI system.

## Decision

AI-EOS introduces a Multi-AI Consensus Experiment framework.

The framework distributes the same scope to multiple AI systems, collects independent outputs, compares them, and produces convergence/divergence evidence for human review.

It does not automatically select a winning solution.

## Consequences

- consensus can be evaluated empirically;
- minority solutions are preserved;
- human review remains central;
- operational cost increases.
