---
id: adr-0010
version: 0.3.2
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [architecture-model-reconciliation]
used_by: []
supersedes: null
---

# ADR-0010 — Reconcile System and Target Architecture Documents

## Status

Accepted

## Context

After merging v0.2 and v0.3, AI-EOS retained two architecture documents:

- `SYSTEM_ARCHITECTURE.md`
- `TARGET_ARCHITECTURE.md`

Independent review identified that both were active and referenced by bootstrap, but their relationship was not formally defined.

## Decision

AI-EOS will treat `TARGET_ARCHITECTURE.md` as the current target architecture and `SYSTEM_ARCHITECTURE.md` as the historical/transitional operational architecture inherited from v0.2.

A reconciliation document will define this relationship.

## Consequences

Positive:

- removes ambiguity
- preserves historical context
- avoids another destructive consolidation
- supports incremental migration

Negative:

- two architecture documents still coexist
- future consolidation remains necessary
