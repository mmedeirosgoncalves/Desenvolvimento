---
id: adr-0018
version: 0.6.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [knowledge-pack-spec]
used_by: []
supersedes: null
---

# ADR-0018 — Canonical Metadata Format

## Status

Accepted

## Context

Knowledge Packs require structured metadata for registry, dependency resolution and context assembly.

Candidate formats were YAML, TOML and JSON.

## Decision

AI-EOS will use YAML as the canonical metadata format for Knowledge Pack manifests.

## Rationale

YAML was selected because it is human-readable, supports comments, is widely used for infrastructure and CI/CD configuration, and is suitable for nested metadata.

## Alternatives

### JSON

Pros: strict, ubiquitous, easy to parse.

Cons: no comments, less readable for humans, noisy diffs.

### TOML

Pros: readable, stricter than YAML.

Cons: less common in AI and infrastructure workflows; less convenient for nested structures.

## Consequences

Positive:

- readable package manifests;
- easy manual editing;
- good alignment with infrastructure conventions.

Negative:

- YAML parsing inconsistencies must be controlled;
- reference implementations must avoid unsafe YAML loading.
