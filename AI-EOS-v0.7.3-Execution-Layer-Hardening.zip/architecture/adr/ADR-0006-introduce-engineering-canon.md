---
id: adr-0006
version: 0.3.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [canon-strategy]
used_by: []
supersedes: null
---

# ADR-0006 — Introduce Engineering Canon

## Status

Accepted

## Context

Previous reviews found that Knowledge Packs were immature and that Skills risked duplicating knowledge.

## Decision

Introduce Canon as a stable layer of consolidated engineering knowledge.

Knowledge Packs will adapt Canon to AI-EOS.

Skills will apply Knowledge Packs.

## Consequences

Positive:

- reduces duplication
- improves reuse
- supports deeper expertise
- creates a stable knowledge base

Negative:

- requires more governance
- requires careful distinction between Canon and Knowledge
