---
id: adr-0021
version: 0.6.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [capability-model]
used_by: []
supersedes: null
---

# ADR-0021 — Capability Resolution

## Status

Accepted

## Context

Agents and Skills should request capabilities rather than specific files whenever possible.

## Decision

Knowledge Packs will declare capabilities through exports, requirements, optional dependencies and conflicts.

Runtime components will resolve capabilities into ordered Knowledge Packs.

## Consequences

Positive:

- reduces hard-coded file dependencies;
- enables future package selection;
- supports context assembly.

Negative:

- capability naming requires governance;
- ambiguous providers must be handled.
