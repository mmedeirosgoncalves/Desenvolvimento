---
id: adr-0017
version: 0.5.2
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [validator-hardening, validation-engine]
used_by: []
supersedes: null
---

# ADR-0017 — Cross-Platform Validation Determinism

## Status

Accepted

## Context

The v0.5.1 Validation Engine hardened duplication, manifest, metadata and negative-fixture checks.

Independent execution on Windows found a cross-platform reproducibility defect in the duplicate allow-list logic.

The root cause was path comparison using POSIX-style regular expressions while Windows path strings used backslashes.

## Decision

AI-EOS validators must normalize paths into a canonical POSIX representation before any comparison, hashing, matching, regex, allow-list or report output.

The Python reference implementation will introduce `path_utils.py` and all path-sensitive validation logic must use it.

## Rules

1. Internal validator paths must use `/`.
2. Validators must not rely on `os.sep` for logical comparisons.
3. Validators must not rely on raw `Path.__str__()` output for matching.
4. Reported file paths should be canonical and stable across operating systems.
5. Tests must cover Windows-style, POSIX-style and mixed path separators.

## Consequences

Positive:

- reproducible validation across operating systems;
- reduced false positives;
- path logic centralized;
- future validators have a clear contract.

Negative:

- additional abstraction layer;
- existing validators must be reviewed for direct path handling;
- full filesystem case-sensitivity behavior remains a future concern.
