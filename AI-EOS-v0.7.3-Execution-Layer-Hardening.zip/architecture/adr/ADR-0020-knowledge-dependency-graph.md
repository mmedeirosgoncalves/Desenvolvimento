---
id: adr-0020
version: 0.6.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [knowledge-dependency-graph]
used_by: []
supersedes: null
---

# ADR-0020 — Knowledge Dependency Graph

## Status

Accepted

## Context

Knowledge Packs may depend on other packs and Canon domains.

Without an explicit dependency graph, Runtime loading order and context assembly become ambiguous.

## Decision

AI-EOS will maintain a deterministic Knowledge Dependency Graph.

The graph resolves dependencies using declared package metadata.

## Rules

- cycles are invalid;
- missing dependencies are invalid;
- conflicts must be reported;
- dependency order must be deterministic;
- optional dependencies must not block loading unless explicitly required.

## Consequences

Positive:

- deterministic context assembly;
- better validation;
- predictable Runtime behavior.

Negative:

- requires dependency metadata discipline;
- graph validation becomes part of release validation.
