---
id: adr-0008
version: 0.3.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [engineering-evolution-policy]
used_by: []
supersedes: null
---

# ADR-0008 — Incremental Evolution Policy

## Status

Accepted

## Context

Independent review found that AI-EOS releases could regress when a new phase was generated as a standalone package instead of being merged into the previous operational baseline.

This created a risk that Vision-oriented releases could accidentally replace operational assets such as Playbooks, Quality Gates, Skills, Templates, Decision Trees and Knowledge Packs.

## Decision

AI-EOS evolves exclusively by incremental merge.

Every release must start from the immediately previous approved baseline.

No release may reduce operational capability unless the reduction is intentional and documented through:

- ADR
- CHANGELOG
- Migration Guide
- supersedes metadata
- architectural justification

## Consequences

Positive:

- prevents accidental regressions
- preserves operational capability
- improves release continuity
- makes reviews more reliable
- supports long-term product evolution

Negative:

- releases require more validation
- deep refactors require migration planning
- package generation becomes more complex
