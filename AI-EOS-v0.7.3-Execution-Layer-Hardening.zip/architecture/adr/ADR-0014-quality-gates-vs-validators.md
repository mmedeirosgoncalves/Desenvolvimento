---
id: adr-0014
version: 0.5.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [validator-model, quality-gates]
used_by: []
supersedes: null
---

# ADR-0014 — Separate Quality Gates from Validators

## Status

Accepted

## Context

Quality Gates and validation mechanisms were previously described together.

This creates ambiguity: a quality criterion is not the same thing as the tool that measures evidence for that criterion.

## Decision

AI-EOS formally separates Quality Gates from Validators.

## Definitions

A Quality Gate defines a quality criterion.

A Validator collects evidence and measures conformance.

A Quality Gate may use multiple Validators.

A Validator may feed multiple Quality Gates.

## Consequences

Positive:

- cleaner architecture
- validators become reusable
- gates remain stable even if implementations change
- better support for multiple execution environments

Negative:

- requires a registry mapping Validators to Gates
- introduces another abstraction layer
