---
id: adr-0005
version: 0.3.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [target-architecture]
used_by: []
supersedes: null
---

# ADR-0005 — Adopt Layered Product Architecture

## Status

Accepted

## Context

AI-EOS evolved from scaffold to governed framework. Continued growth requires clearer top-level boundaries.

## Decision

Adopt the following top-level layers:

- Kernel
- Canon
- Knowledge
- Skills
- Runtime
- Agents
- Governance
- Evaluation
- Adapters
- Labs

## Consequences

Positive:

- clearer architecture
- better extensibility
- better separation of concerns
- easier future runtime design

Negative:

- larger structure
- requires migration from earlier layouts
