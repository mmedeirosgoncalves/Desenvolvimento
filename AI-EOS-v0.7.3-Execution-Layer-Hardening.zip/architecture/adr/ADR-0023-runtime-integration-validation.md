---
id: adr-0023
version: 0.6.0.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [adr-0022, knowledge-validators]
used_by: []
supersedes: null
---

# ADR-0023 — Runtime Integration Validation

## Status

Accepted

## Context

The v0.6.0 independent audit found a gap between specified Knowledge Runtime concepts and executable validation.

## Decision

Runtime-facing contracts must be either implemented, validated, or explicitly deferred.

Presence checks must not be reported as full executable validation.

## Consequences

- Validation covers YAML production artifacts.
- Shared comparators must be used by validators.
- `validation-report.json` must be regenerated after final package changes.
