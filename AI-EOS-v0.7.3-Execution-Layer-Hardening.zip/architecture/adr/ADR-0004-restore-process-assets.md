---
id: adr-0004
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [governance]
used_by: []
supersedes: null
---

# ADR-0004 — Restore Removed Process Assets

## Status

Accepted

## Context

v0.1.1 repaired the framework but removed useful artifacts from v0.1, including heuristics, decision trees, templates and harness material.

This created a capability regression.

## Decision

Restore useful process assets and classify them under the correct architectural modules.

## Consequences

Positive:

- restores useful guidance
- preserves previous value
- reduces regression risk

Negative:

- increases file count
- requires governance to prevent duplication
