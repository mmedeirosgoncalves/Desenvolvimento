---
id: adr-0022
version: 0.6.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [knowledge-runtime-contract]
used_by: []
supersedes: null
---

# ADR-0022 — Knowledge Runtime Contract

## Status

Accepted

## Context

AI-EOS needs a stable contract between Knowledge Packs and Runtime consumers.

## Decision

AI-EOS will define a Knowledge Runtime Contract that specifies package discovery, metadata loading, dependency resolution and context bundle assembly.

## Non-Goals

The v0.6 contract does not include:

- semantic search;
- embeddings;
- RAG;
- LLM-based reranking;
- adaptive context optimization.

## Consequences

Positive:

- stable foundation for future Runtime;
- clear boundaries;
- deterministic loading.

Negative:

- initial resolver is limited to declared metadata;
- semantic relevance is deferred.
