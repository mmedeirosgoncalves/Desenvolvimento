---
id: adr-0026
version: 0.7.3
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-07
review_date: 2026-10-06
release_document: true
depends_on: [adr-0025, release-document-policy]
used_by: []
supersedes: null
---

# ADR-0026 — Release Document Classification

## Status

Accepted

## Context

The v0.6.0.3 audit found that the version-consistency validator relied on a hardcoded allow-list of release documents. The list excluded `README.md`, which remained stale.

A naive fix would add `README.md` to the list. That would fix the instance but preserve the architectural defect.

## Decision

AI-EOS will identify release documents through explicit front-matter metadata:

```yaml
release_document: true
```

The reference validator must discover release documents by metadata, not by a hardcoded filename allow-list.

The framework version must be read from a single source: the root `VERSION` file.

## Consequences

- `README.md` is included as a release document by explicit policy.
- Validators become policy-driven instead of filename-driven.
- Informational documents can remain outside release version validation.
- Future release documents can opt in without code changes.
