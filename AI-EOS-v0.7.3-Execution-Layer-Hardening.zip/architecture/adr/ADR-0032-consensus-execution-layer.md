---
id: adr-0032
version: 0.7.3
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: true
depends_on: [adr-0031]
used_by: []
supersedes: null
---

# ADR-0032 Consensus Execution Layer

## Decision

AI-EOS v0.7.2 promotes the Consensus Engine MVP from a tested library to an operational execution layer. The release adds deterministic CLI entry points for consensus execution and benchmark execution while keeping real vendor orchestration out of scope.

## Rationale

The v0.7.1 audit found that the engine existed and worked but was only exercised through tests. A product capability must be callable by an operator or another system, not only by a test harness.

## Consequences

- Consensus can be executed from JSON artifacts.
- Benchmark suites can generate report artifacts.
- The future Divergence Engine can plug into a real execution flow.
- Network providers remain excluded until provider governance is hardened.

