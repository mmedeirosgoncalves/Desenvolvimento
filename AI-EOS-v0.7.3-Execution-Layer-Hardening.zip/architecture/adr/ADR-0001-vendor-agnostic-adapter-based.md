---
id: adr-0001
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: []
used_by: []
supersedes: null
---

# ADR-0001 — Vendor-Agnostic Adapter-Based Architecture

## Status

Accepted

## Context

AI-EOS should support Devin first but not depend on Devin.

## Decision

Keep core logic vendor-agnostic and isolate tool-specific behavior in adapters.

## Consequences

- More reusable
- Less vendor lock-in
- Requires adapter maintenance
