---
id: adr-0003
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [knowledge-core]
used_by: []
supersedes: null
---

# ADR-0003 — Separate Knowledge Core from Execution Core

## Status

Accepted

## Context

Reviews showed that skills were either shallow or duplicative.

Embedding all domain knowledge directly in skills creates duplication and makes maintenance harder.

## Decision

Introduce Knowledge Core.

Skills will reference Knowledge Packs and define how to apply them.

## Consequences

Positive:

- less duplication
- clearer maturity model
- easier reuse across skills
- better long-term scaling

Negative:

- more architecture
- requires dependency management
