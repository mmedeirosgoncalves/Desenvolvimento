---
id: adr-0009
version: 0.3.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [baseline-policy]
used_by: []
supersedes: null
---

# ADR-0009 — Baseline Release Policy

## Status

Accepted

## Context

AI-EOS generated a v0.3 Vision package that was architecturally useful but not a complete successor to the v0.2 operational baseline.

This showed the need to distinguish partial conceptual releases from complete operational baselines.

## Decision

Only complete releases that preserve operational capability may become the next AI-EOS baseline.

Vision documents, experiments and partial packages may inform future releases but do not replace the baseline until merged.

## Consequences

Positive:

- avoids parallel release lines
- clarifies what future work starts from
- preserves continuity
- formalizes baseline advancement

Negative:

- requires explicit merge process
- requires release validation
