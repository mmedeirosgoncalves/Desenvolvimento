---
id: adr-0012
version: 0.4.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [canon-document-policy]
used_by: []
supersedes: null
---

# ADR-0012 — Canonical Documentation Policy

## Status

Accepted

## Context

Independent review of v0.4 found that Engineering Canon introduced real domain knowledge, but also duplicated generic `DECISION_RULES.md` and `ROADMAP.md` content across all Canon domains.

This created a Single Source of Truth violation.

The same review also found rendering defects in `PATTERNS.md` files caused by literal `\n` sequences.

## Decision

AI-EOS will adopt a Canonical Documentation Policy.

Canon-wide documents must exist once at Canon root.

Domain documents may reference Canon-wide documents and may add extensions only when the domain materially requires them.

Duplicate generic content across domains is prohibited.

## Consequences

Positive:

- reduces duplication
- strengthens Single Source of Truth
- improves maintainability
- prepares Canon for Knowledge Pack expansion
- makes review easier

Negative:

- domain documents become more referential
- future domain-specific decision logic requires explicit extension discipline

## Impact

### Canon

Canon now has root-level:

- `canon/DECISION_RULES.md`
- `canon/ROADMAP.md`

Domain-level `DECISION_RULES.md` and `ROADMAP.md` files are retained as reference stubs to preserve paths and avoid removals.

### Skills

Skills should reference Canon root documents and domain documents instead of copying durable knowledge.

### Knowledge Packs

Knowledge Packs should adapt Canon content operationally and should not duplicate Canon-wide rules.
