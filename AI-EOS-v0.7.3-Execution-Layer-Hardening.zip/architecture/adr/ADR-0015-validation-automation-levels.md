---
id: adr-0015
version: 0.5.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [validation-automation-levels]
used_by: []
supersedes: null
---

# ADR-0015 — Validation Automation Levels

## Status

Accepted

## Context

Not all quality concerns should be automated equally.

Some checks are objective and safe to automate. Others require architectural judgment.

## Decision

AI-EOS defines three automation levels.

## Levels

### L0 — Manual

Checklist-based. Requires human or agent judgment.

### L1 — Semi-Automated

Validator collects objective evidence, but final interpretation remains human/agent-mediated.

### L2 — Automated / Blocking

Validator can determine pass/fail and block release when failing.

## Initial Classification

- QG-009 Dependency Integrity: L2
- QG-004 Documentation: L1
- QG-001 Architecture: L0/L1

## Consequences

Positive:

- avoids premature automation of judgment-heavy gates
- enables strong blocking for objective graph integrity
- creates a gradual automation path

Negative:

- mixed levels require reporting discipline
- L1 may still depend on reviewer quality
