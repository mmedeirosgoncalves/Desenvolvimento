---
id: adr-0019
version: 0.6.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [knowledge-pack-spec]
used_by: []
supersedes: null
---

# ADR-0019 — Knowledge Pack Architecture

## Status

Accepted

## Context

AI-EOS requires a modular way to distribute knowledge without duplicating Canon or embedding domain knowledge inside Skills.

## Decision

Knowledge Packs are the official unit of distributable operational knowledge in AI-EOS.

Skills, Agents and Runtime components consume Knowledge Packs.

Knowledge Packs adapt Canon but must not duplicate Canon wholesale.

## Consequences

Positive:

- modular knowledge distribution;
- versioned knowledge;
- explicit dependencies;
- reusable capabilities;
- reduced duplication.

Negative:

- requires registry and resolver;
- pack lifecycle must be governed;
- pack metadata quality becomes important.
