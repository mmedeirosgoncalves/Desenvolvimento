---
id: adr-0013
version: 0.5.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [validation-engine-contract]
used_by: []
supersedes: null
---

# ADR-0013 — Validation Engine Contract and Python Reference Implementation

## Status

Accepted

## Context

AI-EOS Quality Gates became increasingly precise, but validation remained dependent on manual or external scripts.

Independent review identified this as the next structural gap: the framework specifies what should be validated but does not yet provide an executable validator.

At the same time, AI-EOS must remain vendor-agnostic and language-agnostic.

## Decision

AI-EOS will define a vendor-agnostic and language-agnostic Validation Engine contract.

AI-EOS will also provide a Python reference implementation for validating the AI-EOS repository itself.

## Scope

The Python implementation is a reference validator, not a mandatory runtime dependency for all AI-EOS adopters.

Other implementations may be created in other languages if they satisfy the same contract.

## Consequences

Positive:

- turns manual gates into executable checks
- validates AI-EOS itself
- preserves language-agnostic architecture
- provides an implementation template for future adapters

Negative:

- Python may become a practical dependency for the AI-EOS repository
- validators can overfit to Markdown structure
- automated checks may detect form more easily than substantive quality
