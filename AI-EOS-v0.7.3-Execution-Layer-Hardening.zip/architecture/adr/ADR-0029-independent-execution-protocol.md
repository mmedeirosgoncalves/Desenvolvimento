---
id: adr-0029
version: 0.7.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
release_document: false
depends_on: [adr-0027]
used_by: []
supersedes: null
---

# ADR-0029 — Independent Execution Protocol

## Status

Accepted

## Decision

Each AI system must receive the same scope, same context bundle and same output template.

Agents must not see responses from other agents before submitting their own proposal.

## Consequences

- experiments become more reproducible;
- contamination risk is reduced;
- all model outputs must be preserved.
