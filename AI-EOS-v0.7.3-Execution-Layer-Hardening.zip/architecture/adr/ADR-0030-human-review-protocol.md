---
id: adr-0030
version: 0.7.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
release_document: false
depends_on: [adr-0028, adr-0029]
used_by: []
supersedes: null
---

# ADR-0030 — Human Review Protocol

## Status

Accepted

## Decision

Human review is mandatory for v0.7.0 experiment closure.

The reviewer may accept the majority view, accept a minority solution, synthesize a solution, request another experiment or reject all proposals.
