---
id: adr-0016
version: 0.5.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [validation-engine, validator-model]
used_by: []
supersedes: null
---

# ADR-0016 — Validator Hardening Strategy

## Status

Accepted

## Context

AI-EOS v0.5.0 introduced the first executable Validation Engine. Independent review confirmed that it executes and reproduces release validation, but identified possible false negatives: exact-only duplicate detection, broad literal newline exclusions, partial manifest validation, no metadata consistency validation and no negative fixtures.

## Decision

AI-EOS will harden the reference validator incrementally.

The Validation Engine must evolve through stronger evidence collection, explicit negative fixtures, improved manifest checks, metadata checks and clear false positive / false negative policy.

## False Positive Policy

For subjective or ambiguous checks, prefer `WARNING` over `FAIL`.

## False Negative Policy

Known historical defect classes must be converted into executable checks or negative fixtures.

## Negative Fixture Policy

Every validator that detects a historical defect class should have at least one negative fixture demonstrating detection.

## Consequences

Positive:

- reduces repeated review defects;
- makes validation more reproducible;
- improves confidence in releases;
- prevents historical regressions.

Negative:

- validators become more complex;
- warnings may require reviewer interpretation;
- fixture maintenance becomes part of framework maintenance.
