---
id: adr-0031
version: 0.7.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: false
depends_on: [adr-0028, adr-0027]
used_by: [consensus-engine-mvp]
supersedes: null
---

# ADR-0031 — Evidence-driven Engineering

## Decision

Starting in v0.7.1, every executable consensus feature must ship with a benchmark, baseline and measurable evidence.

## Rationale

The v0.7.0 audit confirmed that documentation and protocols alone are insufficient to claim executable consensus capability. The next step must pair implementation with metrics.

## Consequences

- Consensus Engine MVP is implemented as a small deterministic module.
- CGI, CCI, CLR and CAR are first-class release outputs.
- Future Divergence and Judge engines must add their own benchmarks and validation evidence.
