---
id: adr-0002
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: []
used_by: []
supersedes: null
---

# ADR-0002 — Transition from Documentation Framework to Operational Runtime

## Status

Accepted

## Context

v0.1 behaved mostly as documentation scaffold.

## Decision

AI-EOS will evolve toward an operational engineering runtime.

## Consequences

Runtime Core becomes a major roadmap item.
