---
id: dependency-graph
version: 0.4.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [agents-entry-point, canon-map, skill-security-review, skill-architecture-review]
used_by: []
supersedes: null
---

# Dependency Graph

This file records the high-level dependency relationships between AI-EOS artifacts.

## Bootstrap Graph

```text
AGENTS.md
  -> README.md
  -> docs/PROJECT_CHARTER.md
  -> vision/AI_EOS_VISION.md
  -> constitution/AI_EOS_CONSTITUTION.md
  -> canon/CANON_MAP.md
  -> architecture/SYSTEM_ARCHITECTURE.md
  -> architecture/TARGET_ARCHITECTURE.md
  -> architecture/ARCHITECTURE_MODEL_RECONCILIATION.md
  -> knowledge/KNOWLEDGE_CORE.md
  -> runtime/RUNTIME_OVERVIEW.md
  -> runtime/routing/MULTI_AGENT_TRIGGER_POLICY.md
  -> runtime/quality-gates/QUALITY_GATES.md
  -> governance/ENGINEERING_EVOLUTION_POLICY.md
  -> evaluation/REVIEW_LOOP.md
  -> adapters/devin/DEVIN_BOOTSTRAP_PROMPT.md
```

## Canon Graph

```text
canon/CANON_MAP.md
  -> canon/architecture/
  -> canon/security/
  -> canon/testing/
  -> canon/data/
  -> canon/database/
  -> canon/cloud/
  -> canon/databricks/
  -> canon/api/
  -> canon/legacy/
  -> canon/devops/
```

## Skill Graph

```text
skills/security-review/
  -> canon/security/
  -> knowledge/packs/security/
  -> runtime/quality-gates/QG-002-SECURITY.md

skills/architecture-review/
  -> canon/architecture/
  -> knowledge/packs/architecture/
  -> runtime/quality-gates/QG-001-ARCHITECTURE.md
```

## Governance Graph

```text
architecture/adr/
  -> governance/
  -> evaluation/
  -> RELEASE_VALIDATION.md
```
