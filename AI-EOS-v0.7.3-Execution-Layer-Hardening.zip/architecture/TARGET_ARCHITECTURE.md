---
id: target-architecture
version: 0.3.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [vision]
used_by: [agents-entry-point]
supersedes: null
---

# AI-EOS Target Architecture

AI-EOS is organized into ten top-level layers.

```text
AI-EOS
├── Kernel
├── Canon
├── Knowledge
├── Skills
├── Runtime
├── Agents
├── Governance
├── Evaluation
├── Adapters
└── Labs
```

## 1. Kernel

Stable core principles and rules.

Contains:

- constitution
- first principles
- engineering principles
- quality gates
- trigger policy
- routing rules

## 2. Canon

Consolidated engineering knowledge.

Contains slow-changing, widely accepted engineering concepts.

Examples:

- Clean Architecture
- Domain-Driven Design
- OWASP
- Testing Pyramid
- Lakehouse
- Delta Lake
- Spark
- Strangler Pattern

## 3. Knowledge

AI-EOS-specific adaptation of Canon.

Knowledge Packs translate Canon into operational guidance for AI agents.

## 4. Skills

Skills apply Knowledge Packs to tasks.

Skills should be small, procedural and dependent on Knowledge Packs.

## 5. Runtime

Runtime coordinates execution.

Future components:

- planner
- dispatcher
- context loader
- canon loader
- knowledge loader
- skill loader
- quality engine
- consensus engine
- reporter
- state machine

## 6. Agents

Agent role contracts.

Each agent defines:

- responsibilities
- inputs
- outputs
- required knowledge
- quality gates
- runtime hooks

## 7. Governance

Decision control, ADRs, versioning, change management and removal policy.

## 8. Evaluation

Release review, dependency validation, knowledge coverage, skill maturity and framework health.

## 9. Adapters

Vendor-specific integration.

Examples:

- Devin
- Cursor
- Claude Code
- Codex
- Gemini CLI

## 10. Labs

Experimental concepts.

Nothing from Labs becomes core without review and ADR.
