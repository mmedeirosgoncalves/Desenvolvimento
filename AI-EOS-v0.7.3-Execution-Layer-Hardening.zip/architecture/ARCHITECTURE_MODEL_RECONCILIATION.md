---
id: architecture-model-reconciliation
version: 0.3.2
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [system-architecture, target-architecture]
used_by: [agents-entry-point]
supersedes: null
---

# Architecture Model Reconciliation

## Purpose

AI-EOS currently contains two architecture documents inherited from different phases:

- `architecture/SYSTEM_ARCHITECTURE.md`
- `architecture/TARGET_ARCHITECTURE.md`

This document defines their relationship.

## Current Architecture

`architecture/TARGET_ARCHITECTURE.md` is the current target architecture.

It defines the long-term layered model:

```text
Kernel / Constitution
Canon
Knowledge
Skills
Runtime
Agents / Multi-Agent
Governance
Evaluation
Adapters
Labs
```

## Historical Architecture

`architecture/SYSTEM_ARCHITECTURE.md` is retained as the v0.2 operational architecture.

It describes the earlier operating model and remains useful for understanding the evolution of AI-EOS.

## Status

- `TARGET_ARCHITECTURE.md`: current target architecture
- `SYSTEM_ARCHITECTURE.md`: historical / transitional architecture

## Rule

New architectural work should reference `TARGET_ARCHITECTURE.md`.

Operational compatibility work may reference `SYSTEM_ARCHITECTURE.md` when preserving v0.2 behavior.

## Future Migration

A future release may consolidate these documents after the Engineering Canon phase begins.

That consolidation must be documented through ADR and migration notes.
