---
id: devin-usage
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: []
used_by: []
supersedes: null
---

# Devin Usage

Recommended instruction:

```text
Read `.ai/AI-EOS/AGENTS.md` and follow AI-EOS for this task.
```

Do not ask Devin to read every file.

Ask it to load only relevant Knowledge Packs, Skills and Playbooks.
