---
id: migration-policy
version: 0.3.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [engineering-evolution-policy]
used_by: []
supersedes: null
---

# Migration Policy

## Purpose

Define how AI-EOS handles replacement, deprecation and removal of components.

## Default Rule

Do not remove.

Prefer:

1. Add
2. Refactor
3. Deprecate
4. Replace
5. Remove only when justified

## Deprecation Requirements

A deprecated component must include:

- reason
- replacement
- migration path
- expected removal version
- affected consumers

## Removal Requirements

A removal requires:

- ADR
- CHANGELOG entry
- Migration Guide
- supersedes metadata
- replacement or explicit justification
- regression review

## Migration Guide Requirements

A migration guide must state:

- previous component
- new component
- reason for change
- affected paths
- manual actions required
- compatibility risks
- validation steps

## Forbidden Changes

The following are forbidden without migration documentation:

- deleting operational files
- changing bootstrap paths
- renaming top-level layers
- moving skills without redirects or notes
- removing quality gates
- removing Knowledge Packs used by mature skills
