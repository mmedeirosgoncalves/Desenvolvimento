---
id: adr-policy
version: 0.3.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [governance]
used_by: []
supersedes: null
---

# ADR Policy

## When to Create an ADR

Create an ADR when:

- architecture changes
- module boundaries change
- a new top-level layer is added
- a component is removed
- a decision is hard to reverse
- governance rules change

## ADR Required Sections

- Status
- Context
- Decision
- Consequences
- Alternatives
- Risks
