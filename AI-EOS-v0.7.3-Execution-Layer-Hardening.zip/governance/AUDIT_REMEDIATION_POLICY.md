---
id: audit-remediation-policy
version: 0.6.0.2
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [adr-0024]
used_by: []
supersedes: null
---

# Audit Remediation Policy

## Purpose

Convert audit feedback into implementable work without treating auditor suggestions as automatically binding.

## Principles

1. Separate fact from inference.
2. Treat proposed fixes as proposals.
3. Require acceptance criteria before implementation.
4. Require regression tests for behavioral fixes.
5. Allow a justified do-not-implement decision.
6. Use compact ARP for small fixes and full ARP for structural changes.

## ARP Status

- proposed
- accepted
- rejected
- deferred
- implemented
- verified

## Compact ARP

Use for low-risk fixes:

- Finding
- Evidence
- Proposed fix
- Required tests
- Acceptance criteria

## Full ARP

Use for structural changes:

- Finding ID
- Observed fact
- Evidence
- Root-cause hypothesis
- Confidence
- Suggested fix
- Alternatives
- Do-not-implement option
- Architectural impact
- Regression risk
- Required tests
- Acceptance criteria
