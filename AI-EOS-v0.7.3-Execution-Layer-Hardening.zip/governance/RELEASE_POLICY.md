---
id: release-policy
version: 0.3.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [engineering-evolution-policy]
used_by: [review-loop]
supersedes: null
---

# Release Policy

## Purpose

Define the required structure and acceptance criteria for every AI-EOS release.

## Required Release Artifacts

Every release must include:

- `AGENTS.md`
- `README.md`
- `CHANGELOG.md`
- `ROADMAP.md`
- `PACKAGE_MANIFEST.md`
- updated ADRs when applicable
- updated dependency graph when applicable
- release review notes or instructions
- migration guide when compatibility changes

## Release Types

## Patch Release

Small fix, no architectural change.

## Minor Release

Adds capabilities, expands knowledge, improves skills or changes non-breaking structure.

## Major Release

Changes top-level architecture, deprecates modules or introduces incompatible changes.

## Release Acceptance Criteria

A release is acceptable only if:

- it starts from the current baseline
- it preserves existing operational capability
- it documents all structural changes
- it updates the roadmap
- it updates the changelog
- it passes regression review
- it is usable through `AGENTS.md`

## Release Output

Each release should produce:

- complete project ZIP
- summary of changes
- list of ADRs created
- known limitations
- recommended next step
