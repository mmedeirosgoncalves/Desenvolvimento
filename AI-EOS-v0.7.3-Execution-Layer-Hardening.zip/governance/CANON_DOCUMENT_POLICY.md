---
id: canon-document-policy
version: 0.4.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [engineering-evolution-policy, canon-map]
used_by: [canon-decision-rules, canon-roadmap]
supersedes: null
---

# Canon Document Policy

## Purpose

Define how Canon documentation avoids duplication while preserving domain-specific extensibility.

## Single-Instance Canon Documents

The following Canon documents must exist only once at Canon root:

- `canon/CANON_MAP.md`
- `canon/CANON_INCLUSION_CRITERIA.md`
- `canon/DECISION_RULES.md`
- `canon/ROADMAP.md`

These documents define shared Canon-wide rules.

## Domain-Level Documents

The following documents may exist per Canon domain:

- `README.md`
- `PRINCIPLES.md`
- `PATTERNS.md`
- `ANTI_PATTERNS.md`
- `CHECKLIST.md`

These documents should contain domain-specific knowledge.

## Domain Extension Documents

A domain may contain local versions of common documents only as extension stubs.

Allowed extension stubs:

- `DECISION_RULES.md`
- `ROADMAP.md`

These must reference the canonical document and may add domain-specific extensions only when necessary.

They must not duplicate canonical content.

## Duplication Rule

Do not copy the same generic content into multiple Canon domains.

Use references.

## Reuse Rule

When a concept applies to all domains, place it at Canon root.

When a concept applies only to one domain, place it inside that domain.

When a concept applies to several but not all domains, create a shared Canon document and reference it.

## Future Impact

Skills and Knowledge Packs must reference Canon documents instead of copying Canon content.
