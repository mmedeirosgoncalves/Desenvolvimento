---
id: maintenance-queue
version: 0.6.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [engineering-evolution-policy, validation-path-contract]
used_by: []
supersedes: null
---

# Maintenance Queue

## Purpose

Track non-blocking findings from independent reviews and route them into the next roadmap release.

## Current Items

### MQ-0018 — Manifest Validator Normalization

- Origin: Devin review of v0.5.2
- Category: Infrastructure Maintenance
- Severity: Low
- Status: Addressed in v0.6.0
- Resolution: Manifest path comparisons now rely on canonical normalization utilities.

### MQ-0019 — Shared Normalization Utilities

- Origin: Devin review of v0.5.2
- Category: Infrastructure Maintenance
- Severity: Medium
- Status: Addressed in v0.6.0
- Resolution: Validators use shared normalization helpers.

### MQ-0020 — Shared Comparator Utilities

- Origin: Devin review of v0.5.2
- Category: Infrastructure Maintenance
- Severity: Medium
- Status: Addressed in v0.6.0
- Resolution: Introduced comparator utility specification and reference implementation.

### MQ-0021 — Cross-Validator Normalization Contract

- Origin: Devin review of v0.5.2
- Category: Infrastructure Maintenance
- Severity: Medium
- Status: Addressed in v0.6.0
- Resolution: Validation path and comparison contracts extended for all validators.

## Rule

Non-blocking maintenance items should be incorporated into the next roadmap release unless they become blocking.
