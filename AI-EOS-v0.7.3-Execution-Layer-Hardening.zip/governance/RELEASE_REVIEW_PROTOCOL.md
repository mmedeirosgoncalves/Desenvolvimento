---
id: release-review-protocol
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [governance, dependency-graph]
used_by: []
supersedes: null
---

# Release Review Protocol

Every release must be reviewed before it is considered complete.

## Review Dimensions

- Bootstrap works
- Paths are consistent
- No duplicated operational rules
- No undocumented removals
- Quality gates are defined
- Skills are not falsely advertised as mature
- Knowledge dependencies are declared
- Known limitations are explicit

## Required Output

```text
Release:
Reviewer:
Scope:
Findings:
Regressions:
Quality Gates:
Recommendation:
```
