---
id: engineering-evolution-policy
version: 0.3.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [governance, baseline-policy]
used_by: [agents-entry-point]
supersedes: null
---

# Engineering Evolution Policy

## Purpose

This policy defines how AI-EOS evolves as a long-term engineering product.

It exists to prevent accidental regressions, parallel product lines, undocumented removals and loss of operational capability between releases.

## Core Rule

AI-EOS evolves by incremental merge.

AI-EOS does not evolve by reconstruction.

Every release must start from the immediately previous approved baseline.

## Evolution Modes

A change must be classified as one of:

- Addition
- Refactoring
- Consolidation
- Deprecation
- Replacement
- Removal

Implicit removal is prohibited.

## Preservation Rule

A release must preserve all operational capabilities from the previous baseline unless a removal is explicitly approved through:

- ADR
- CHANGELOG entry
- Migration Guide
- `supersedes` metadata
- architectural justification
- replacement or deprecation plan

## Baseline Rule

The most recent approved release is the only valid starting point for the next release.

Vision documents, experiments and partial packages must not replace the operational baseline unless explicitly merged.

## Impact Analysis

Before adding or modifying components, identify:

- what already exists
- what is being added
- what is being changed
- what is being superseded
- what consumers are affected
- what dependencies are affected
- what release documentation must be updated

## Required Release Checks

Every release must answer:

- Did any file disappear?
- Did any operational capability disappear?
- Did any bootstrap path change?
- Did any dependency become invalid?
- Did any skill lose its Knowledge Pack?
- Did any quality gate become unavailable?
- Did any removal happen without ADR?

If the answer is yes to any regression question, the release must be corrected before delivery.

## Relationship to Other Policies

- `RELEASE_POLICY.md` defines release structure.
- `MIGRATION_POLICY.md` defines how replacement and removal work.
- `evaluation/REGRESSION_POLICY.md` defines regression detection.
- `evaluation/BASELINE_POLICY.md` defines baseline selection.
