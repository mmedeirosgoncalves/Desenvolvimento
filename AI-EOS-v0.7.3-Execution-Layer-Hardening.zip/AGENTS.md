---
id: agents-entry-point
version: 0.7.3
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: true
depends_on: []
used_by: []
supersedes: null
---

# AGENTS

## Release

AI-EOS v0.7.3 — Execution Layer Hardening.

## Required Validation Flow

Agents must run:

```bash
python runtime/validation/reference/python/run_tests.py
python runtime/validation/reference/python/ai_eos_validate.py . --output validation-report.json
python -m runtime.consensus consensus --input examples/consensus/sample_execution.json --output reports/sample-consensus-report.json
python -m runtime.consensus benchmark --suite experiments/benchmark_suite/mvp_cases.json --output-dir reports/benchmark
```

## Review Rule

Do not call a release complete unless VERSION, Package Manifest, Release Validation, Changelog and executable validation agree.
