---
id: governance
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [adr-0004]
used_by: []
supersedes: null
---

# Governance

AI-EOS is governed as a living engineering framework.

## Rules

1. Every structural change must be justified.
2. Every major decision must be recorded as an ADR.
3. No useful capability should be removed without a recorded reason.
4. Documentation must remain synchronized with architecture.
5. Skills must declare whether they are mature or placeholders.
6. Every release must include independent architectural review.

## Removal Policy

If an artifact is removed, the release must document:

- what was removed
- why it was removed
- whether it will return
- what replaces it
- whether the removal reduces capability
