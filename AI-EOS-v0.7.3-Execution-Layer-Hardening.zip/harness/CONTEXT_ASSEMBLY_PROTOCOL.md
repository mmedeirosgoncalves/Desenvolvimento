---
id: context-assembly-protocol
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [harness-model]
used_by: []
supersedes: null
---

# Context Assembly Protocol

## Steps

1. Identify task type.
2. Identify affected system areas.
3. Load relevant code.
4. Load relevant tests.
5. Load relevant architecture docs.
6. Load relevant Knowledge Packs.
7. Load relevant Skills and Playbooks.
8. Declare assumptions.
9. Identify quality gates.

## Avoid

- loading every file blindly
- ignoring current code
- relying on outdated docs
- mixing unrelated context
