---
id: harness-model
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [knowledge-core]
used_by: []
supersedes: null
---

# Harness Model

Harness is the support, control and safety structure that channels AI capabilities into useful engineering work.

## Components

- task
- codebase
- tests
- architecture
- specifications
- knowledge packs
- skills
- playbooks
- quality gates
- operational constraints

## Principle

A good harness does not eliminate AI creativity.

It directs it.
