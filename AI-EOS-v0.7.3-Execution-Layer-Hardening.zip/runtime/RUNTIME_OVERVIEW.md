---
id: runtime-overview
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [system-architecture]
used_by: []
supersedes: null
---

# Runtime Overview

Runtime Core coordinates AI-EOS execution.

v0.2 still defines runtime protocols rather than executable software.

## Components

- routing
- quality gates
- future planner
- future dispatcher
- future context loader
- future skill loader
- future knowledge router

## Rule

Runtime behavior should be operational, not merely descriptive.
