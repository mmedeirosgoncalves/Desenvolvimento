---
id: consensus-benchmark-runner
version: 0.7.3
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: true
depends_on: [adr-0032]
used_by: []
supersedes: null
---

# Consensus Benchmark Runner

The benchmark runner executes each case in a benchmark suite through the Consensus Engine and writes one JSON report per case plus a `benchmark-summary.json`.

The runner is intentionally minimal: it validates that the engine can process benchmark artifacts end-to-end. Statistical comparison, provider routing and adaptive orchestration remain future work.

