---
id: consensus-input-schema
version: 0.7.3
status: active
owner: AI-EOS Chief Architect
created: 2026-07-07
updated: 2026-07-07
review_date: 2026-10-07
release_document: false
depends_on: [consensus-execution-layer]
used_by: []
supersedes: null
---

# Consensus Input Schema

v0.7.3 defines an explicit payload contract for the consensus CLI.

Required:

- `task_id`
- at least one of `responses` or `mock_providers`

Invalid payloads must return structured CLI errors and non-zero exit codes.
