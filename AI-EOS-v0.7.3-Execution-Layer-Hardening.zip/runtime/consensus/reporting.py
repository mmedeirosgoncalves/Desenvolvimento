"""JSON reporting for consensus executions."""
from __future__ import annotations
from pathlib import Path
from typing import Any
import json
import math
from dataclasses import asdict, is_dataclass
from .engine import ConsensusResult
from .provider_interface import ProviderResponse

def _strict_value(value: Any) -> Any:
    if isinstance(value, float):
        if math.isnan(value) or math.isinf(value):
            return None
        return value
    if isinstance(value, dict):
        return {str(k): _strict_value(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_strict_value(v) for v in value]
    if is_dataclass(value):
        return _strict_value(asdict(value))
    return value

def build_consensus_report(execution_id: str, responses: list[ProviderResponse], result: ConsensusResult) -> dict:
    report = {
        "execution_id": execution_id,
        "engine": "consensus-engine-mvp",
        "version": "0.7.3",
        "providers": [r.provider_id for r in responses],
        "individual_responses": [r.__dict__ for r in responses],
        "consensus_result": result.to_dict(),
        "cost": sum(float(r.cost) for r in responses),
        "token_usage": {
            "input_tokens": sum(int(r.input_tokens) for r in responses),
            "output_tokens": sum(int(r.output_tokens) for r in responses),
        },
        "warnings": result.warnings,
    }
    report["consensus_result"]["version"] = "0.7.3"
    return _strict_value(report)

def strict_json_dumps(data: dict) -> str:
    return json.dumps(_strict_value(data), indent=2, sort_keys=True, allow_nan=False)

def write_consensus_report(path: str | Path, report: dict) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(strict_json_dumps(report), encoding="utf-8")
