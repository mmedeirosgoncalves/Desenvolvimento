"""Provider abstraction for the Consensus Engine MVP.

The MVP keeps external model execution outside the package. Real providers and
mock providers must implement the same deterministic interface so that the
consensus pipeline can be tested without network access or vendor dependency.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Mapping, Protocol
import time

@dataclass(frozen=True)
class ProviderRequest:
    task_id: str
    prompt: str
    metadata: Mapping[str, str] = field(default_factory=dict)

@dataclass(frozen=True)
class ProviderResponse:
    provider_id: str
    task_id: str
    content: str
    latency_ms: int = 0
    input_tokens: int = 0
    output_tokens: int = 0
    cost: float = 0.0
    metadata: Mapping[str, str] = field(default_factory=dict)

class ProviderInterface(Protocol):
    provider_id: str
    def complete(self, request: ProviderRequest) -> ProviderResponse:
        """Return one independent response for a request."""

class MockProvider:
    """Deterministic provider for tests and offline benchmark execution."""
    def __init__(self, provider_id: str, response_text: str, *, cost: float = 0.0):
        self.provider_id = provider_id
        self.response_text = response_text
        self.cost = cost

    def complete(self, request: ProviderRequest) -> ProviderResponse:
        start = time.perf_counter()
        latency_ms = int((time.perf_counter() - start) * 1000)
        words = self.response_text.split()
        return ProviderResponse(
            provider_id=self.provider_id,
            task_id=request.task_id,
            content=self.response_text,
            latency_ms=latency_ms,
            input_tokens=len(request.prompt.split()),
            output_tokens=len(words),
            cost=self.cost,
            metadata={"provider_type": "mock"},
        )
