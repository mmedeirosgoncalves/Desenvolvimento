"""Operational entry points for the AI-EOS consensus execution layer.

v0.7.3 hardens the v0.7.2 CLI by validating payloads and emitting strict JSON.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from .engine import ConsensusEngine, ConsensusInput
from .metrics import (
    consensus_gain_index,
    consensus_cost_index,
    consensus_latency_ratio,
    consensus_agreement_rate,
)
from .provider_interface import ProviderRequest, ProviderResponse, MockProvider
from .reporting import build_consensus_report, write_consensus_report, strict_json_dumps

EXIT_OK = 0
EXIT_INVALID_INPUT = 1
EXIT_IO_ERROR = 2
EXIT_INTERNAL_ERROR = 3

class ConsensusCLIError(Exception):
    def __init__(self, code: str, message: str, exit_code: int = EXIT_INVALID_INPUT):
        super().__init__(message)
        self.code = code
        self.message = message
        self.exit_code = exit_code

    def to_dict(self) -> dict[str, str]:
        return {"status": "FAIL", "code": self.code, "message": self.message}

def _load_json(path: str | Path) -> dict[str, Any]:
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ConsensusCLIError("INVALID_JSON", f"Invalid JSON: {exc.msg}", EXIT_INVALID_INPUT)
    except OSError as exc:
        raise ConsensusCLIError("INPUT_READ_ERROR", str(exc), EXIT_IO_ERROR)
    if not isinstance(data, dict):
        raise ConsensusCLIError("INVALID_INPUT", "Input payload must be a JSON object", EXIT_INVALID_INPUT)
    return data

def validate_payload(payload: dict[str, Any]) -> None:
    if not isinstance(payload, dict):
        raise ConsensusCLIError("INVALID_INPUT", "Input payload must be an object")
    task_id = payload.get("task_id") or payload.get("execution_id")
    if not isinstance(task_id, str) or not task_id.strip():
        raise ConsensusCLIError("INVALID_INPUT", "task_id is required")
    responses = payload.get("responses", []) or []
    mock_providers = payload.get("mock_providers", []) or []
    if not isinstance(responses, list):
        raise ConsensusCLIError("INVALID_INPUT", "responses must be an array")
    if not isinstance(mock_providers, list):
        raise ConsensusCLIError("INVALID_INPUT", "mock_providers must be an array")
    if len(responses) + len(mock_providers) == 0:
        raise ConsensusCLIError("INVALID_INPUT", "responses or mock_providers are required")
    seen: set[str] = set()
    for idx, item in enumerate(responses):
        if not isinstance(item, dict):
            raise ConsensusCLIError("INVALID_INPUT", f"responses[{idx}] must be an object")
        provider_id = str(item.get("provider_id") or item.get("id") or "").strip()
        content = str(item.get("content") or item.get("response") or "").strip()
        if not provider_id:
            raise ConsensusCLIError("INVALID_INPUT", f"responses[{idx}].provider_id is required")
        if provider_id in seen:
            raise ConsensusCLIError("INVALID_INPUT", f"duplicate provider_id: {provider_id}")
        seen.add(provider_id)
        if not content:
            raise ConsensusCLIError("INVALID_INPUT", f"responses[{idx}].content is required")
    for idx, item in enumerate(mock_providers):
        if not isinstance(item, dict):
            raise ConsensusCLIError("INVALID_INPUT", f"mock_providers[{idx}] must be an object")
        provider_id = str(item.get("provider_id") or "").strip()
        response_text = str(item.get("response_text") or "").strip()
        if not provider_id:
            raise ConsensusCLIError("INVALID_INPUT", f"mock_providers[{idx}].provider_id is required")
        if provider_id in seen:
            raise ConsensusCLIError("INVALID_INPUT", f"duplicate provider_id: {provider_id}")
        seen.add(provider_id)
        if not response_text:
            raise ConsensusCLIError("INVALID_INPUT", f"mock_providers[{idx}].response_text is required")

def _response_from_dict(item: dict[str, Any], fallback_task_id: str) -> ProviderResponse:
    return ProviderResponse(
        provider_id=str(item.get("provider_id") or item.get("id") or "provider"),
        task_id=str(item.get("task_id") or fallback_task_id),
        content=str(item.get("content") or item.get("response") or ""),
        latency_ms=int(item.get("latency_ms", 0) or 0),
        input_tokens=int(item.get("input_tokens", 0) or 0),
        output_tokens=int(item.get("output_tokens", 0) or 0),
        cost=float(item.get("cost", 0.0) or 0.0),
        metadata=item.get("metadata", {}) or {},
    )

def run_consensus_payload(payload: dict[str, Any]) -> dict[str, Any]:
    validate_payload(payload)
    task_id = str(payload.get("task_id") or payload.get("execution_id"))
    responses = [_response_from_dict(x, task_id) for x in payload.get("responses", [])]

    for item in payload.get("mock_providers", []):
        provider = MockProvider(str(item["provider_id"]), str(item["response_text"]), cost=float(item.get("cost", 0.0) or 0.0))
        request = ProviderRequest(task_id=task_id, prompt=str(payload.get("prompt", "")))
        responses.append(provider.complete(request))

    result = ConsensusEngine().build(ConsensusInput(task_id=task_id, responses=responses))
    report = build_consensus_report(str(payload.get("execution_id") or f"EXEC-{task_id}"), responses, result)

    scores = [float(x) for x in payload.get("individual_scores", [])]
    consensus_score = payload.get("consensus_score")
    best_latency = min([r.latency_ms for r in responses if r.latency_ms > 0] or [0])
    if consensus_score is not None and scores:
        report["metrics"] = {
            "CGI": consensus_gain_index(float(consensus_score), scores),
            "CCI": consensus_cost_index(float(consensus_score), float(report["cost"])),
            "CLR": consensus_latency_ratio(result.latency_ms, best_latency),
            "CAR": consensus_agreement_rate(len(result.shared_claims), len(result.shared_claims) + sum(len(v) for v in result.unique_claims.values())),
        }
    else:
        report["metrics"] = {
            "CGI": None,
            "CCI": consensus_cost_index(result.agreement_rate, float(report["cost"])),
            "CLR": consensus_latency_ratio(result.latency_ms, best_latency),
            "CAR": result.agreement_rate,
        }
    strict_json_dumps(report)
    return report

def run_benchmark_suite(path: str | Path, output_dir: str | Path) -> dict[str, Any]:
    suite = _load_json(path)
    if not isinstance(suite.get("cases", []), list):
        raise ConsensusCLIError("INVALID_BENCHMARK", "benchmark cases must be an array")
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    reports = []
    for idx, case in enumerate(suite.get("cases", []), start=1):
        if not isinstance(case, dict):
            raise ConsensusCLIError("INVALID_BENCHMARK", f"cases[{idx}] must be an object")
        task_id = str(case.get("task_id") or f"CASE-{idx:03d}")
        if "responses" in case or "mock_providers" in case:
            payload = dict(case)
            payload.setdefault("task_id", task_id)
        else:
            claim = case.get("expected_shared_claim", "provider abstraction")
            payload = {
                "execution_id": f"BENCH-{task_id}",
                "task_id": task_id,
                "prompt": case.get("prompt", ""),
                "mock_providers": [
                    {"provider_id": "bench-a", "response_text": f"Use {claim}. Keep reports deterministic."},
                    {"provider_id": "bench-b", "response_text": f"Use {claim}. Add an executable entry point."},
                ],
            }
        report = run_consensus_payload(payload)
        report_path = out / f"{task_id}.consensus-report.json"
        write_consensus_report(report_path, report)
        reports.append({"task_id": task_id, "report_path": str(report_path), "agreement_rate": report["consensus_result"]["agreement_rate"]})
    summary = {
        "benchmark_id": suite.get("benchmark_id", "BENCH-UNSPECIFIED"),
        "version": "0.7.3",
        "case_count": len(reports),
        "reports": reports,
    }
    (out / "benchmark-summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True, allow_nan=False), encoding="utf-8")
    return summary

def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="aieos-consensus", description="AI-EOS consensus execution layer")
    sub = parser.add_subparsers(dest="command", required=True)

    c = sub.add_parser("consensus", help="run consensus over a JSON execution artifact")
    c.add_argument("--input", required=True, help="JSON file with task_id and responses or mock_providers")
    c.add_argument("--output", required=True, help="output JSON report path")

    b = sub.add_parser("benchmark", help="run a benchmark suite through the consensus engine")
    b.add_argument("--suite", required=True, help="benchmark suite JSON path")
    b.add_argument("--output-dir", required=True, help="directory for benchmark reports")

    args = parser.parse_args(argv)
    try:
        if args.command == "consensus":
            report = run_consensus_payload(_load_json(args.input))
            write_consensus_report(args.output, report)
            print(json.dumps({"status": "PASS", "output": args.output, "agreement_rate": report["consensus_result"]["agreement_rate"]}, sort_keys=True, allow_nan=False))
            return EXIT_OK
        if args.command == "benchmark":
            summary = run_benchmark_suite(args.suite, args.output_dir)
            print(json.dumps({"status": "PASS", "case_count": summary["case_count"], "output_dir": args.output_dir}, sort_keys=True, allow_nan=False))
            return EXIT_OK
    except ConsensusCLIError as exc:
        print(json.dumps(exc.to_dict(), sort_keys=True, allow_nan=False))
        return exc.exit_code
    except Exception as exc:
        print(json.dumps({"status": "FAIL", "code": "INTERNAL_ERROR", "message": str(exc)}, sort_keys=True, allow_nan=False))
        return EXIT_INTERNAL_ERROR
    return 2

if __name__ == "__main__":
    raise SystemExit(main())
