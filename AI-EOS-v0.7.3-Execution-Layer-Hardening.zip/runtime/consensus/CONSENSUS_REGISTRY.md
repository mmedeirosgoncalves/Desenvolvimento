---
id: consensus-registry
version: 0.7.3
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-07
review_date: 2026-10-06
release_document: false
depends_on: [multi-ai-consensus-experiment]
used_by: []
supersedes: null
---

# Consensus Registry

Experimental registry for Multi-AI Consensus components.
