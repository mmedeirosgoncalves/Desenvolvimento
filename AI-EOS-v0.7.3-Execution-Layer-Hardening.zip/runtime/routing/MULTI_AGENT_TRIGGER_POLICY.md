---
id: multi-agent-trigger-policy
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: []
used_by: [agents-entry-point]
supersedes: null
---

# Multi-Agent Trigger Policy

This is the single authoritative source for multi-agent escalation.

## Default Mode

Use single-agent mode for simple, local, low-risk tasks.

## Trigger Conditions

Activate multi-agent mode when the task involves:

- architectural decision
- security-sensitive change
- authentication or authorization
- database schema change
- data migration
- data pipeline
- cloud infrastructure
- CI/CD pipeline change
- production impact
- legacy modernization
- distributed systems
- performance-critical path
- hard-to-rollback change
- high ambiguity
- multiple viable solution paths
- Databricks, Spark or Lakehouse architecture

## Uncertainty Rule

If impact is uncertain, escalate.

False positives are preferable to false negatives.
