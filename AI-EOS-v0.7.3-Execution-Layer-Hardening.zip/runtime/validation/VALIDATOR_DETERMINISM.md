---
id: validator-determinism
version: 0.7.3
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-07
review_date: 2026-10-06
depends_on: [validation-path-contract]
used_by: []
supersedes: null
---

# Validator Determinism

## Purpose

Define deterministic behavior requirements for AI-EOS validators.

## Rule

Given the same logical repository content, validators should produce the same logical result regardless of:

- operating system;
- path separator;
- directory traversal order;
- locale;
- supported filesystem path style.

## Deterministic Output Requirements

Validators must:

- sort discovered files;
- use canonical paths in reports;
- avoid environment-specific ordering;
- normalize paths before comparisons;
- emit stable status values;
- separate deterministic findings from environment-specific diagnostics.

## Current Scope

v0.5.2 addresses separator-based determinism.

Future releases may address:

- filesystem case sensitivity;
- Unicode normalization;
- symlinks;
- permission differences;
- locale-dependent sorting.
