---
id: knowledge-validators
version: 0.7.3
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-07
review_date: 2026-10-06
depends_on: [validation-engine, knowledge-pack-spec]
used_by: []
supersedes: null
---

# Knowledge Validators

## Purpose

Define validators for Knowledge Runtime and Knowledge Packs.

## Validators

### Package Metadata Validator

Checks required `package.yaml` fields.

### Capability Integrity Validator

Checks that exported capabilities are valid and uniquely resolvable.

### Dependency Graph Validator

Checks missing dependencies, cycles and conflicts.

### Lifecycle Consistency Validator

Checks status and maturity transitions.

### Registry Consistency Validator

Checks that registry entries point to existing packages.

## Automation Level

Initial level: L1.

Future releases may promote specific checks to L2.
