---
id: validation-comparison-contract
version: 0.7.3
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-07
review_date: 2026-10-06
depends_on: [validation-path-contract, maintenance-queue]
used_by: []
supersedes: null
---

# Validation Comparison Contract

## Purpose

Define how validators compare paths, documents and metadata.

## Rules

- Paths must be normalized before comparison.
- Document bodies must be compared without front matter.
- Generic H1 headings should not drive duplicate detection.
- Document comparison must be deterministic.
- Validators must not reimplement path or document comparison logic.

## Reference Implementation

The Python reference implementation provides shared helpers in:

```text
runtime/validation/reference/python/core/comparators.py
```

## Maintenance Queue Coverage

This contract resolves:

- MQ-0018
- MQ-0019
- MQ-0020
- MQ-0021
