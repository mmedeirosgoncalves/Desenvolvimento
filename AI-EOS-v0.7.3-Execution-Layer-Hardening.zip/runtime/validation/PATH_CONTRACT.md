---
id: validation-path-contract
version: 0.7.3
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-07
review_date: 2026-10-06
depends_on: [adr-0017, validation-engine]
used_by: []
supersedes: null
---

# Validation Path Contract

## Purpose

Define the canonical path rules for AI-EOS validators.

## Canonical Representation

All internal validator paths must use POSIX-style separators:

```text
canon/api/README.md
```

## Rules

- Normalize `\` to `/`.
- Collapse repeated separators.
- Remove leading `./`.
- Do not use `os.sep` for logical matching.
- Do not compare raw `Path.__str__()` output.
- Do not write regexes that depend on the operating system separator.
- Use canonical paths in validation reports.

## Applies To

- allow-lists
- regex matching
- hashing
- duplicate detection
- manifest validation
- bootstrap validation
- dependency report output

## Non-Goal

This contract does not fully solve case-sensitive vs case-insensitive filesystem behavior. That is a future hardening item.
