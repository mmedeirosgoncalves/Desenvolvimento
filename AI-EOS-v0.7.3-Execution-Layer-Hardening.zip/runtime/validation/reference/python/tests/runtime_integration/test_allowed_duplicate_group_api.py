from pathlib import Path
import sys, importlib.util
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
spec = importlib.util.spec_from_file_location("ai_eos_validate", ROOT / "ai_eos_validate.py")
v = importlib.util.module_from_spec(spec)
spec.loader.exec_module(v)

assert hasattr(v, "allowed_duplicate_group")
assert v.allowed_duplicate_group(["canon/api/DECISION_RULES.md", "canon/security/DECISION_RULES.md"]) is True
assert v.allowed_duplicate_group(["canon/api/ROADMAP.md", "canon/security/ROADMAP.md"]) is True
assert v.allowed_duplicate_group(["canon/api/README.md", "canon/security/README.md"]) is False
assert v.allowed_duplicate_group(["x/A.md", "x/B.md"]) is False
