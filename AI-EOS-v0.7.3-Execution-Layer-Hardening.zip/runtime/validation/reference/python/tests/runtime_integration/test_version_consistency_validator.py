from pathlib import Path
import sys, tempfile, importlib.util
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
spec = importlib.util.spec_from_file_location("ai_eos_validate", ROOT / "ai_eos_validate.py")
v = importlib.util.module_from_spec(spec)
spec.loader.exec_module(v)

def version_validator(report):
    return next(x for x in report["validators"] if x["validator_id"] == "version-consistency-validator")

with tempfile.TemporaryDirectory() as tmp:
    root = Path(tmp)
    (root / "VERSION").write_text("0.6.1.0\n", encoding="utf-8")
    (root / "CHANGELOG.md").write_text("""---
id: changelog
version: 0.0.1
status: active
updated: 2026-07-06
review_date: 2026-10-06
release_document: true
depends_on: []
---

# Changelog
""", encoding="utf-8")
    report = v.run(root)
    vv = version_validator(report)
    assert vv["status"] == "WARNING", report
    assert "stale version" in str(vv).lower(), report
