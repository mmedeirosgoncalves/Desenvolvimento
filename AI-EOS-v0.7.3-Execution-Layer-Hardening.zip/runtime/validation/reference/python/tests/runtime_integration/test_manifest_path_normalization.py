from pathlib import Path
import sys
import importlib.util, tempfile
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
spec = importlib.util.spec_from_file_location("ai_eos_validate", ROOT / "ai_eos_validate.py")
v = importlib.util.module_from_spec(spec)
spec.loader.exec_module(v)
with tempfile.TemporaryDirectory() as tmp:
    root = Path(tmp)
    (root/"adapters").mkdir()
    (root/"canon").mkdir()
    (root/"PACKAGE_MANIFEST.md").write_text("# Package Manifest\n\n## Markdown Files\n\n1\n\n## Top-Level Areas\n\n- adapters/\n- canon/\n", encoding="utf-8")
    (root/"README.md").write_text("# Test\n", encoding="utf-8")
    findings = []
    r = v.validate_manifest(root, findings, 1)
    assert r["top_level_missing"] == []
    assert r["top_level_nonexistent"] == []
