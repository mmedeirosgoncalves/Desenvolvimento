from pathlib import Path
import sys, json
ROOT = Path(__file__).resolve().parents[6]
sys.path.insert(0, str(ROOT))
from runtime.consensus.cli import run_consensus_payload
from runtime.consensus.reporting import strict_json_dumps

payload = {
    "execution_id":"EXEC-STRICT",
    "task_id":"T-STRICT",
    "mock_providers":[
        {"provider_id":"a", "response_text":"Use strict JSON."},
        {"provider_id":"b", "response_text":"Use strict JSON."}
    ],
}
report = run_consensus_payload(payload)
text = strict_json_dumps(report)
assert "Infinity" not in text
assert "NaN" not in text
json.loads(text)
