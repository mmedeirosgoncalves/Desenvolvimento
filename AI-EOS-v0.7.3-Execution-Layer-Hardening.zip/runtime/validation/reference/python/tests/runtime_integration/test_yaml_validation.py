from pathlib import Path
import sys
import importlib.util, tempfile
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
spec = importlib.util.spec_from_file_location("ai_eos_validate", ROOT / "ai_eos_validate.py")
v = importlib.util.module_from_spec(spec)
spec.loader.exec_module(v)
with tempfile.TemporaryDirectory() as tmp:
    root = Path(tmp)
    (root/"canon/security").mkdir(parents=True)
    (root/"knowledge/packs/security").mkdir(parents=True)
    (root/"runtime/registry").mkdir(parents=True)
    (root/"knowledge/packs/security/package.yaml").write_text("""
id: kp-security
name: Security Pack
version: "0.1.0"
owner: AI-EOS
status: validated
maturity: L2
review_date: 2026-10-06
exports:
  - security-review
requires:
  - canon-security
optional: []
conflicts: []
tags:
  - security
depends_on:
  - canon-security
consumed_by:
  - skills
""".strip(), encoding="utf-8")
    (root/"runtime/registry/knowledge_registry.yaml").write_text("""
packages:
  - id: kp-security
    path: knowledge/packs/security/package.yaml
""".strip(), encoding="utf-8")
    report = v.run(root)
    assert report["summary"]["yaml_files"] == 2
    assert any(x["validator_id"] == "yaml-package-validator" for x in report["validators"])
