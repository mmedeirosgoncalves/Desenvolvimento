from pathlib import Path

ROOT = Path(__file__).resolve().parents[6]

required = [
    "experiments/MULTI_AI_CONSENSUS_EXPERIMENT.md",
    "runtime/consensus/MULTI_AI_AGENT_PROTOCOL.md",
    "runtime/consensus/CONSENSUS_ANALYZER.md",
    "runtime/consensus/DEVILS_ADVOCATE_PROTOCOL.md",
    "runtime/consensus/HUMAN_REVIEW_PROTOCOL.md",
    "experiments/templates/CONSENSUS_REPORT_TEMPLATE.md",
]

missing = [p for p in required if not (ROOT / p).exists()]
assert not missing, missing

content = (ROOT / "runtime/consensus/CONSENSUS_ANALYZER.md").read_text(encoding="utf-8")
assert "does not choose a winner" in content
assert "does not treat consensus as correctness" in content
