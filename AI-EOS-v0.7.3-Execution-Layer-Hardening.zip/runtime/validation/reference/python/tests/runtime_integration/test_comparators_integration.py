from pathlib import Path
import sys
import ast
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
src = (ROOT / "ai_eos_validate.py").read_text(encoding="utf-8")
tree = ast.parse(src)
imports = []
calls = []
for n in ast.walk(tree):
    if isinstance(n, ast.ImportFrom):
        imports.append(n.module)
    if isinstance(n, ast.Call):
        if isinstance(n.func, ast.Name):
            calls.append(n.func.id)
        elif isinstance(n.func, ast.Attribute):
            calls.append(n.func.attr)
assert "core.comparators" in imports
assert "compare_paths" in calls
