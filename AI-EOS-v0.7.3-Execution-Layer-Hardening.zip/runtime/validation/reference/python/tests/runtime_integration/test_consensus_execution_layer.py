from pathlib import Path
import sys, json, tempfile
ROOT = Path(__file__).resolve().parents[6]
sys.path.insert(0, str(ROOT))
from runtime.consensus.cli import main, run_consensus_payload, run_benchmark_suite

payload = {
    "execution_id": "EXEC-CLI-TEST",
    "task_id": "T-CLI",
    "prompt": "Should the engine have a CLI?",
    "mock_providers": [
        {"provider_id": "mock-a", "response_text": "Add a CLI entry point. Keep JSON reports."},
        {"provider_id": "mock-b", "response_text": "Add a CLI entry point. Keep benchmark reports."},
    ],
    "individual_scores": [8.0, 8.1],
    "consensus_score": 8.4,
}
report = run_consensus_payload(payload)
assert report["version"] == "0.7.3"
assert report["consensus_result"]["provider_count"] == 2
assert report["metrics"]["CGI"] > 0

with tempfile.TemporaryDirectory() as tmp:
    root = Path(tmp)
    input_path = root / "input.json"
    output_path = root / "out" / "report.json"
    input_path.write_text(json.dumps(payload), encoding="utf-8")
    rc = main(["consensus", "--input", str(input_path), "--output", str(output_path)])
    assert rc == 0
    assert output_path.exists()
    assert "Infinity" not in output_path.read_text(encoding="utf-8")
    suite = root / "suite.json"
    suite.write_text(json.dumps({"benchmark_id":"BENCH-CLI", "cases":[payload]}), encoding="utf-8")
    summary = run_benchmark_suite(suite, root / "bench")
    assert summary["case_count"] == 1
    assert (root / "bench" / "benchmark-summary.json").exists()
