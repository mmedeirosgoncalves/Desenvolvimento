from pathlib import Path
import sys, json, tempfile, io, contextlib
ROOT = Path(__file__).resolve().parents[6]
sys.path.insert(0, str(ROOT))
from runtime.consensus.cli import main

with tempfile.TemporaryDirectory() as tmp:
    root = Path(tmp)

    missing = root / "missing.json"
    missing.write_text(json.dumps({"task_id": "T-MISSING"}), encoding="utf-8")
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        rc = main(["consensus", "--input", str(missing), "--output", str(root / "out.json")])
    assert rc == 1
    assert "INVALID_INPUT" in buf.getvalue()

    malformed = root / "malformed.json"
    malformed.write_text("{", encoding="utf-8")
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        rc = main(["consensus", "--input", str(malformed), "--output", str(root / "out.json")])
    assert rc == 1
    assert "INVALID_JSON" in buf.getvalue()

    dup = root / "dup.json"
    dup.write_text(json.dumps({
        "task_id":"T-DUP",
        "responses":[
            {"provider_id":"a", "content":"One."},
            {"provider_id":"a", "content":"Two."}
        ]
    }), encoding="utf-8")
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        rc = main(["consensus", "--input", str(dup), "--output", str(root / "out.json")])
    assert rc == 1
    assert "duplicate provider_id" in buf.getvalue()
