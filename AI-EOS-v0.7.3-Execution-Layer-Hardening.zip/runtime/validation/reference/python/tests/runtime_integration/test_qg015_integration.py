from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[6]
sys.path.insert(0, str(ROOT))
from runtime.validation.reference.python import ai_eos_validate

report = ai_eos_validate.run(ROOT)
validators = {v["validator_id"]: v for v in report["validators"]}
assert validators["consensus-execution-entrypoint-validator"]["status"] == "PASS"
assert validators["strict-json-validator"]["status"] == "PASS"
assert "QG-015" in (ROOT / "runtime/quality-gates/QUALITY_GATES.md").read_text(encoding="utf-8")
assert "QG-015" in (ROOT / "runtime/validation/QUALITY_GATE_MAPPING.md").read_text(encoding="utf-8")
assert "QG-015" in (ROOT / "runtime/validation/VALIDATION_REGISTRY.md").read_text(encoding="utf-8")
