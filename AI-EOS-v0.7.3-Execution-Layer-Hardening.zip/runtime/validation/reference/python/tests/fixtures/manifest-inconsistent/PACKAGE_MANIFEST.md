---
id: package-manifest
version: 0.5.1
status: active
updated: 2026-07-06
review_date: 2026-10-06
depends_on: []
supersedes: null
---

# Package Manifest

## Markdown Files

999

## Top-Level Areas

- missing/
