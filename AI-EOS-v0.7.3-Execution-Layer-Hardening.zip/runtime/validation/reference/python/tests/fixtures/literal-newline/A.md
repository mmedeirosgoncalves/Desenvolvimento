---
id: literal-newline
version: 0.5.1
status: active
updated: 2026-07-06
review_date: 2026-10-06
depends_on: []
supersedes: null
---

# A

This line has a bad sequence \n inside prose.
