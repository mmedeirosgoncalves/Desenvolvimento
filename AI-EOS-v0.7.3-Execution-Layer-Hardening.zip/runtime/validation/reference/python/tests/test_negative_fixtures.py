#!/usr/bin/env python3
"""Negative fixture smoke tests for AI-EOS reference validator."""

from __future__ import annotations

import json
import sys
from pathlib import Path
import importlib.util
import sys

ROOT = Path(__file__).resolve().parent
VALIDATOR_PATH = ROOT.parent / "ai_eos_validate.py"
sys.path.insert(0, str(ROOT.parent))
FIXTURES = ROOT / "fixtures"

spec = importlib.util.spec_from_file_location("ai_eos_validate", VALIDATOR_PATH)
validator = importlib.util.module_from_spec(spec)
spec.loader.exec_module(validator)

EXPECTED = {
    "duplicate-id": "Duplicate ids found",
    "broken-dependency": "Unresolved depends_on references",
    "literal-newline": "Literal escaped newlines found",
    "near-duplicate": "Near-duplicate content",
    "manifest-inconsistent": "Markdown file count mismatch",
    "stale-version": "Unexpected status value",
}

def run_case(name: str):
    data = validator.run(FIXTURES / name)
    findings = json.dumps(data.get("validators", []))
    expected = EXPECTED[name]
    if expected not in findings:
        raise AssertionError(f"{name}: expected finding not detected: {expected}")
    return name

def main():
    passed = [run_case(name) for name in EXPECTED]
    print(json.dumps({"status": "PASS", "fixtures": passed}, indent=2))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
