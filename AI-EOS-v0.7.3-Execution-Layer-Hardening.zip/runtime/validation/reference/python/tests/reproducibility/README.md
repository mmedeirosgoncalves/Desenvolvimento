---
id: validator-reproducibility-tests
version: 0.5.2
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [validation-path-contract]
used_by: []
supersedes: null
---

# Reproducibility Tests

## Purpose

Validate that path-sensitive validators behave consistently across path styles.

## Coverage

- Windows separators
- POSIX separators
- mixed separators
- drive-letter-like paths
- UNC-like paths
- duplicate allow-list matching

## Usage

```bash
python runtime/validation/reference/python/tests/reproducibility/test_path_normalization.py
```
