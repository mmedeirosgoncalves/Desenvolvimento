#!/usr/bin/env python3
"""Cross-platform path normalization tests."""

from __future__ import annotations

import json
import importlib.util
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
VALIDATOR_PATH = ROOT / "ai_eos_validate.py"
sys.path.insert(0, str(ROOT))
PATH_UTILS_PATH = ROOT / "path_utils.py"

spec = importlib.util.spec_from_file_location("ai_eos_validate", VALIDATOR_PATH)
validator = importlib.util.module_from_spec(spec)
spec.loader.exec_module(validator)

spec2 = importlib.util.spec_from_file_location("path_utils", PATH_UTILS_PATH)
path_utils = importlib.util.module_from_spec(spec2)
spec2.loader.exec_module(path_utils)


def main():
    inputs = [
        "canon\\api\\README.md",
        "canon/api/README.md",
        "canon/api\\README.md",
        ".\\canon\\api\\README.md",
        "./canon/api/README.md",
        "C:\\repo\\canon\\api\\README.md",
        "\\\\server\\repo\\canon\\api\\README.md",
    ]
    normalized = [path_utils.normalize_path(x) for x in inputs]
    assert normalized[0] == "canon/api/README.md"
    assert normalized[1] == "canon/api/README.md"
    assert normalized[2] == "canon/api/README.md"

    allow = [
        ["canon\\api\\DECISION_RULES.md", "canon\\security\\DECISION_RULES.md"],
        ["canon/api/DECISION_RULES.md", "canon/security/DECISION_RULES.md"],
        ["canon/api\\ROADMAP.md", "canon\\security/ROADMAP.md"],
    ]
    for group in allow:
        assert validator.allowed_duplicate_group(group), group

    reject = ["canon\\api\\README.md", "canon\\security\\README.md"]
    assert not validator.allowed_duplicate_group(reject)

    print(json.dumps({"status": "PASS", "normalized_samples": normalized[:3]}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
