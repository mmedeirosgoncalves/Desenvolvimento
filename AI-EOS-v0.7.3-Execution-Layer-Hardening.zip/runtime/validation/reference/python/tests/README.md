---
id: validator-negative-fixtures
version: 0.5.1
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [adr-0016]
used_by: []
supersedes: null
---

# Reference Validator Negative Fixtures

## Purpose

These fixtures prove that the reference validator detects known historical defect classes.

## Covered Defects

- duplicate id
- broken dependency
- literal escaped newline
- near-duplicate content
- manifest inconsistency
- stale version / invalid metadata

## Usage

From the AI-EOS root:

```bash
python runtime/validation/reference/python/tests/test_negative_fixtures.py
```
