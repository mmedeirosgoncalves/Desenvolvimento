"""Canonical path utilities for AI-EOS validators."""
from __future__ import annotations
from pathlib import Path

def normalize_path(value: str | Path) -> str:
    raw = str(value).replace("\\", "/").strip()
    while "//" in raw:
        raw = raw.replace("//", "/")
    raw = raw.lstrip("./").strip("/")
    return raw

def relative_path(path: str | Path, root: str | Path) -> str:
    path_s = normalize_path(path)
    root_s = normalize_path(root)
    if path_s.startswith(root_s + "/"):
        return normalize_path(path_s[len(root_s) + 1:])
    try:
        return normalize_path(Path(path).relative_to(Path(root)))
    except Exception:
        return path_s
