#!/usr/bin/env python3
"""Run every in-package validation test; fail if any test fails."""
from __future__ import annotations
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def main() -> int:
    tests = sorted((ROOT / "tests").rglob("test_*.py"))
    failures = []
    for test in tests:
        proc = subprocess.run([sys.executable, str(test)], capture_output=True, text=True, timeout=30)
        rel = test.relative_to(ROOT).as_posix()
        status = "PASS" if proc.returncode == 0 else "FAIL"
        print(f"{rel}: {status}")
        if proc.returncode != 0:
            failures.append(rel)
            print(proc.stdout)
            print(proc.stderr)
    if failures:
        print("FAILED_TESTS=" + ",".join(failures))
        return 1
    print(f"PASSED_TESTS={len(tests)}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
