"""Shared validation core utilities."""
