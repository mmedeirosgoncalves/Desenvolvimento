"""Shared comparators for AI-EOS validators."""
from __future__ import annotations
import re
from pathlib import Path
from difflib import SequenceMatcher

try:
    from path_utils import normalize_path
except ImportError:
    from ..path_utils import normalize_path

def compare_paths(left: str | Path, right: str | Path) -> bool:
    return normalize_path(left) == normalize_path(right)

def normalize_document_body(text: str, remove_h1: bool = True) -> str:
    if text.startswith("---"):
        parts = text.split("---", 2)
        if len(parts) == 3:
            text = parts[2].lstrip()
    lines = text.splitlines()
    if remove_h1:
        lines = [line for line in lines if not line.strip().startswith("# ")]
    return re.sub(r"\s+", " ", "\n".join(lines).strip().lower())

def similarity(left: str, right: str) -> float:
    return SequenceMatcher(None, normalize_document_body(left), normalize_document_body(right)).ratio()
