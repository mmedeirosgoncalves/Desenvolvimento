---
id: validation-engine-contract
version: 0.7.3
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-07
review_date: 2026-10-06
depends_on: [validation-engine]
used_by: []
supersedes: null
---

# Validation Engine Contract

## Purpose

Define a language-agnostic contract for validation engines.

## Inputs

- repository root
- validation registry
- quality gate definitions
- package manifest
- baseline metadata when available

## Outputs

- validation report
- gate results
- findings
- severity
- evidence
- release recommendation

## Required Capabilities

A compliant Validation Engine must:

1. discover artifacts
2. parse front matter
3. execute registered validators
4. map validator results to Quality Gates
5. aggregate results
6. produce a machine-readable report
7. produce a human-readable report

## Result Status

- PASS
- FAIL
- WARNING
- NOT_APPLICABLE
- NOT_VERIFIED

## Severity

- INFO
- LOW
- MEDIUM
- HIGH
- CRITICAL
