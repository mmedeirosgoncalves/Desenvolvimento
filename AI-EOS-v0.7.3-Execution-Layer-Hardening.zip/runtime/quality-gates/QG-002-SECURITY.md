---
id: qg-002-security
version: 0.7.3
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-07
review_date: 2026-10-06
depends_on: []
used_by: []
supersedes: null
---

# QG-002-SECURITY — Security

## Checks

- [ ] Authentication impact assessed.
- [ ] Authorization impact assessed.
- [ ] No secrets exposed.
- [ ] Sensitive data exposure assessed.
- [ ] OWASP risks considered.

## Result Format

```text
Gate: Security
Status: PASS | FAIL | NOT_APPLICABLE | NOT_VERIFIED
Evidence:
Residual Risk:
```
