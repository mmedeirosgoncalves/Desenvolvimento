---
id: qg-006-data-integrity
version: 0.7.3
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-07
review_date: 2026-10-06
depends_on: []
used_by: []
supersedes: null
---

# QG-006-DATA-INTEGRITY — Data Integrity

## Checks

- [ ] Schema impact assessed.
- [ ] Migration plan exists if needed.
- [ ] Rollback/recovery considered.
- [ ] Data loss risk assessed.

## Result Format

```text
Gate: Data Integrity
Status: PASS | FAIL | NOT_APPLICABLE | NOT_VERIFIED
Evidence:
Residual Risk:
```
