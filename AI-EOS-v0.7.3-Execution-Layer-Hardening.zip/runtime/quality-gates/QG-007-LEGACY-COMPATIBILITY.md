---
id: qg-007-legacy-compatibility
version: 0.7.3
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-07
review_date: 2026-10-06
depends_on: []
used_by: []
supersedes: null
---

# QG-007-LEGACY-COMPATIBILITY — Legacy Compatibility

## Checks

- [ ] Backward compatibility assessed.
- [ ] Legacy integration points identified.
- [ ] Existing behavior preserved or change justified.

## Result Format

```text
Gate: Legacy Compatibility
Status: PASS | FAIL | NOT_APPLICABLE | NOT_VERIFIED
Evidence:
Residual Risk:
```
