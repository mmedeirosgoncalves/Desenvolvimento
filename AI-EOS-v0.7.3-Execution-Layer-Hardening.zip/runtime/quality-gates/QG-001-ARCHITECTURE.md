---
id: qg-001-architecture
version: 0.7.3
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-07
review_date: 2026-10-06
depends_on: []
used_by: []
supersedes: null
---

# QG-001-ARCHITECTURE — Architecture

## Checks

- [ ] Architecture respected or deviation explained.
- [ ] Boundaries remain clear.
- [ ] No duplicated source of truth.
- [ ] Significant decision has ADR.

## Result Format

```text
Gate: Architecture
Status: PASS | FAIL | NOT_APPLICABLE | NOT_VERIFIED
Evidence:
Residual Risk:
```

## Automation Level

L0/L1 — Manual to Semi-Automated.

Architecture requires judgment; validators may provide supporting evidence.
