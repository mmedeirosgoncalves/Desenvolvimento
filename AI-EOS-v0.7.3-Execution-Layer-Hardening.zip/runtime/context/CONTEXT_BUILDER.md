---
id: context-builder
version: 0.6.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [context-model, capability-model]
used_by: []
supersedes: null
---

# Context Builder

## Purpose

The Context Builder assembles ordered knowledge for agents and skills.

## Pipeline

```text
Context Request
  -> Capability Resolution
  -> Dependency Graph
  -> Ordered Packs
  -> Context Bundle
```

## Non-Goals for v0.6

The Context Builder does not perform:

- semantic retrieval;
- embeddings;
- RAG;
- LLM reranking;
- personalized context ranking.

## Output

The output is a deterministic Context Bundle.
