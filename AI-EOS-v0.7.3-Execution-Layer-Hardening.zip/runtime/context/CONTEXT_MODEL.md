---
id: context-model
version: 0.6.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [knowledge-runtime-contract]
used_by: []
supersedes: null
---

# Context Model

## Purpose

Define the structure of context assembled from Knowledge Packs.

## Context Bundle

A Context Bundle contains:

- request metadata;
- selected capabilities;
- ordered Knowledge Packs;
- Canon references;
- Skill references;
- validation status;
- residual risks.

## Rule

Context must be minimal but sufficient.

The v0.6 Context Model is deterministic and metadata-driven.
