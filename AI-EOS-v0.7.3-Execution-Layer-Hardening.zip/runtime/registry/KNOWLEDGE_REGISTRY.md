---
id: knowledge-registry
version: 0.6.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [knowledge-pack-spec]
used_by: []
supersedes: null
---

# Knowledge Registry

## Purpose

The Knowledge Registry discovers and indexes Knowledge Packs.

## Responsibilities

- locate Knowledge Packs;
- read `package.yaml`;
- register package ids and versions;
- expose package capabilities;
- provide metadata to the dependency resolver.

## Registry File

```text
runtime/registry/knowledge_registry.yaml
```

## Rule

The registry is an index, not the source of truth.

The source of truth remains each pack's `package.yaml`.
