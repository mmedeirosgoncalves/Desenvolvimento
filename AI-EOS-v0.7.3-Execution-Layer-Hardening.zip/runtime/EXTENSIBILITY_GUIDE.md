---
id: runtime-extensibility-guide
version: 0.6.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [knowledge-runtime-contract]
used_by: []
supersedes: null
---

# Runtime Extensibility Guide

## Purpose

Define extension points for future AI-EOS Runtime components.

## Extension Points

- new Knowledge Pack formats;
- new registry providers;
- new dependency resolvers;
- new capability resolvers;
- new context builders;
- new validators.

## Rule

Extensions must preserve the core contracts.

The reference implementation may evolve, but the specification remains language-agnostic.
