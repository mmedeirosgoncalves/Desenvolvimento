---
id: capability-model
version: 0.6.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [knowledge-pack-spec]
used_by: []
supersedes: null
---

# Capability Model

## Purpose

Capabilities describe what a Knowledge Pack can provide to Skills, Agents and Runtime components.

## Capability Fields

```yaml
capability:
  id:
  version:
  stability:
  provider:
  exports:
  requires:
  optional:
  conflicts:
  visibility:
```

## Stability Values

- experimental
- validated
- stable
- deprecated

## Resolution Rule

Consumers should request capabilities.

The resolver maps capabilities to Knowledge Packs.

## Conflict Rule

If two packs provide conflicting capabilities, the resolver must report the conflict instead of selecting silently.
