---
id: knowledge-runtime-contract
version: 0.6.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [knowledge-pack-spec, knowledge-registry, capability-model]
used_by: []
supersedes: null
---

# Knowledge Runtime Contract

## Purpose

Define the stable contract between Knowledge Packs and Runtime consumers.

## Inputs

- requested capability;
- registry;
- package metadata;
- dependency graph;
- context policy.

## Outputs

- resolved packages;
- ordered dependency list;
- context bundle;
- validation findings.

## Requirements

A compliant Knowledge Runtime must:

1. discover packs;
2. load metadata;
3. validate dependencies;
4. resolve capabilities;
5. assemble context deterministically;
6. report unresolved dependencies and conflicts.
