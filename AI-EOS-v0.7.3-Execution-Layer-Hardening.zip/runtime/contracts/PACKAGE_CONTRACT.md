---
id: package-contract
version: 0.6.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [knowledge-pack-spec]
used_by: []
supersedes: null
---

# Package Contract

## Purpose

Define the minimum contract every Knowledge Pack must satisfy.

## Required

- `package.yaml`
- unique package id
- semantic version
- lifecycle status
- maturity level
- owner
- review date
- exports
- dependencies
- consumers

## Invalid Package Conditions

- missing id;
- missing version;
- unresolved dependency;
- conflicting capability;
- invalid lifecycle status;
- unsupported metadata format.
