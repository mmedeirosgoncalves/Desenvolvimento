---
id: context-contract
version: 0.6.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [context-model]
used_by: []
supersedes: null
---

# Context Contract

## Purpose

Define the contract for Context Bundles.

## Required Fields

```yaml
context_id:
request:
capabilities:
packages:
canon_references:
validation:
risks:
```

## Rule

Context Bundles must be deterministic for the same request and registry state.
