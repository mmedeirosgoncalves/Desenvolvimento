---
id: knowledge-dependency-graph
version: 0.6.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: [capability-model, adr-0020]
used_by: []
supersedes: null
---

# Knowledge Dependency Graph

## Purpose

Define how Knowledge Pack dependencies are represented and resolved.

## Graph Inputs

- `package.yaml`
- `requires`
- `optional`
- `conflicts`
- `depends_on`

## Validation Rules

- package ids must be unique;
- required dependencies must exist;
- cycles are invalid;
- conflicts must be explicit;
- optional dependencies do not block resolution;
- resolution order must be deterministic.

## Resolution Order

```text
Requested Capability
  -> Provider Pack
  -> Required Dependencies
  -> Optional Dependencies
  -> Ordered Context Bundle
```
