---
id: engineering-principles
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: []
used_by: [architecture-heuristics]
supersedes: null
---

# Engineering Principles

- Understand before implementing.
- Prefer simplicity over unnecessary complexity.
- Avoid unnecessary distribution.
- Prefer modularity over fragmentation.
- Prefer evolution over rewrite.
- Make trade-offs explicit.
- Optimize only after measuring.
- Tests are part of the solution.
- Observability is a design requirement.
- Security is a design requirement.
- Documentation should reduce future cognitive load.
- Every abstraction has a cost.
