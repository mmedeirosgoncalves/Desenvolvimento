---
id: constitution
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: []
used_by: [agents-entry-point]
supersedes: null
---

# AI-EOS Constitution

## Principles

1. Context before generation.
2. Code is the authoritative source of truth.
3. Documentation must serve execution.
4. Operational rules must have one source of truth.
5. Escalate when impact is uncertain.
6. Prefer fewer deep skills over many shallow skills.
7. Quality gates must be concrete and checkable.
8. Vendor-specific behavior belongs in adapters.
9. Knowledge and execution must be separated.
10. No capability may be removed without explicit documentation.
