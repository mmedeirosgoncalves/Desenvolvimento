---
id: first-principles
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: []
used_by: []
supersedes: null
---

# First Principles

- Software exists to solve business problems.
- Complexity is a liability unless it buys necessary capability.
- Code difficult to understand is a defect.
- Every dependency has cost.
- Systems should be designed for change.
- Architecture must be explainable.
- Production behavior matters more than theoretical elegance.
