---
id: project-charter
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: []
used_by: [agents-entry-point]
supersedes: null
---

# AI-EOS Project Charter

AI-EOS is a vendor-agnostic engineering operating system for AI agents.

It is not a prompt collection.

It is a modular framework designed to guide agents through professional software engineering work.

## Mission

Transform general AI agents into structured engineering collaborators by combining:

- governance
- knowledge
- reasoning
- runtime protocols
- skills
- playbooks
- quality gates
- review mechanisms

## v0.2 Objective

Refactor the architecture to separate Knowledge from Execution.

## Key Principle

```text
Knowledge + Execution = Skill
```

Knowledge alone is passive.

Execution alone is shallow.

A mature skill combines domain knowledge with operational procedure.
