---
id: glossary
version: 0.2.0
status: active
owner: AI-EOS Chief Architect
created: 2026-07-06
updated: 2026-07-06
review_date: 2026-10-06
depends_on: []
used_by: []
supersedes: null
---

# Glossary

## Knowledge Pack

A domain-specific body of engineering knowledge.

## Skill

A reusable execution capability that applies one or more Knowledge Packs.

## Playbook

A step-by-step procedure for recurring work.

## Runtime

The operational layer that coordinates classification, routing, context loading, skill loading, validation and reporting.

## Harness

The context structure that guides AI work.

## Quality Gate

A concrete validation checkpoint.
